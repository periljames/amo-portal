# Audit Assurance — Phase 1 live inventory (BEFORE reconstruction)

Generated from live authenticated browser against `http://127.0.0.1:5173` · tenant `safarilink`.

Viewport baseline: **1400 × 906**.

## Navigation layers observed (all AA pages)

1. Portal left rail (tenant shell)
2. Quality department top bar (Control Room / Planner / Missions / People / Cases / Intelligence)
3. Assurance context pills (Cases / Audit Assurance / Findings & Actions / Corrective action / Evidence / Tools)
4. AA local rail (Overview / Programme / Calendar / Audits / Findings & Actions + Tools)
5. On audit records: lifecycle stage links (Setup … Archive)

**= 4–5 concurrent navigation systems before content.**

---

## Screen inventory

### A/B — Entry / Overview
- **Route:** `/maintenance/safarilink/quality/audits/dashboard`
- **H1:** Audit Assurance
- **Viewport:** 1400×906 · **doc scrollHeight:** 906 (fits viewport)
- **Header stack:** tenant topbar ~51px + QA workspace nav ~41px + AA related ~36px + AA rail
- **Primary CTAs:** Go to Programme / Planner / Register / CARs; KPI cards link out
- **Secondary:** Refresh, Open Audit Assurance tools
- **Wasted space:** KPI card wall + duplicate “Go to …” strip above cards; title vs rail redundancy
- **Data notes:** “0 Active programmes” with helper “1 revision in 2026” — contradictory presentation
- **Screenshot:** `01-overview-1440.png`

### C — Programme
_(pending capture)_

### D — Calendar / Planner
_(pending)_

### E — Audits workspace
_(pending)_

### F–K — Audit stages (QAR-MO-26-001)
_(pending)_

### L–T — Findings / CAR / Evidence / Checklists / Cases
_(pending)_

---

## Interactive control seed (Overview)

80 visible interactive controls counted (includes portal chrome). AA-specific primary links observed:
- Programme, Planner, Register, CARs
- KPI cards: Active programmes, Due soon, Unscheduled, …

---

## Contract observations (seed)

| Field / UI | Expected? | Observed | Class |
| --- | --- | --- | --- |
| Active programmes count | Clear definition | 0 with “1 revision in 2026” | BROKEN PRESENTATION / definition drift |
| Unscheduled | Programme readiness SoT | “No unscheduled requirements reported” | Likely EXPECTED if readiness present |
| Nav depth | One AA local nav | 4–5 layers | PRODUCT DEFECT (IA) |

