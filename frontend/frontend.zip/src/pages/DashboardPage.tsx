// src/pages/DashboardPage.tsx
import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import DepartmentLayout from "../components/Layout/DepartmentLayout";
import DepartmentLandingScaffold from "../components/dashboard/DepartmentLandingScaffold";
import { getContext, getCachedUser, normalizeDepartmentCode } from "../services/auth";
import { decodeAmoCertFromUrl } from "../utils/amo";
import {
  type DepartmentId,
  DEPARTMENT_LABELS,
  getAllowedDepartments,
  getAssignedDepartment,
  isAdminUser,
  isDepartmentId,
} from "../utils/departmentAccess";
import {
  listDocumentAlerts,
  type AircraftDocument,
} from "../services/fleet";
import { DASHBOARD_WIDGETS, canSeeDashboardWidget, getWidgetStorageKey } from "../utils/dashboardWidgets";
import { isUiShellV2Enabled } from "../utils/featureFlags";

const niceLabel = (dept: string) =>
  DEPARTMENT_LABELS[dept as DepartmentId] || dept;

type Holiday = {
  date: string;
  localName: string;
  name: string;
};

type LeaveEntry = {
  id: string;
  date: string; // YYYY-MM-DD
  reason: string;
};

type ThrottleStore = {
  amo: Record<
    string,
    {
      limit: number;
      perUser: Record<string, number>;
    }
  >;
  cacheHolidays: boolean;
};

const DEFAULT_THROTTLE: ThrottleStore = {
  amo: {},
  cacheHolidays: true,
};

const THROTTLE_STORAGE_KEY = "amo_calendar_throttle_settings";
const DOC_ALERTS_BANNER_STORAGE_KEY = "amo_doc_alerts_banner_dismissed";

type CalendarProvider = "google" | "outlook";
type CalendarConnections = Record<CalendarProvider, boolean>;

type DueSummary = {
  aircraft_serial_number: string;
  next_due_task_code?: string | null;
  due_date?: string | null; // ISO date
  due_status?: string | null;
  days_to_due?: number | null;
};

function getLocalStorageJson<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function setLocalStorageJson<T>(key: string, value: T): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

function getThrottleStore(): ThrottleStore {
  if (typeof window === "undefined") return DEFAULT_THROTTLE;
  try {
    const raw = window.localStorage.getItem(THROTTLE_STORAGE_KEY);
    if (!raw) return DEFAULT_THROTTLE;
    return { ...DEFAULT_THROTTLE, ...(JSON.parse(raw) as ThrottleStore) };
  } catch {
    return DEFAULT_THROTTLE;
  }
}

function formatDate(value: string): string {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

function buildMonthDays(month: Date): Date[] {
  const start = new Date(month.getFullYear(), month.getMonth(), 1);
  const end = new Date(month.getFullYear(), month.getMonth() + 1, 0);
  const days: Date[] = [];
  const startWeekday = start.getDay();
  for (let i = 0; i < startWeekday; i += 1) {
    const filler = new Date(start);
    filler.setDate(start.getDate() - (startWeekday - i));
    days.push(filler);
  }
  for (let d = 1; d <= end.getDate(); d += 1) {
    days.push(new Date(month.getFullYear(), month.getMonth(), d));
  }
  const remaining = 42 - days.length;
  for (let i = 1; i <= remaining; i += 1) {
    days.push(new Date(month.getFullYear(), month.getMonth() + 1, i));
  }
  return days;
}

function safeEnv(key: string): string {
  try {
    const v: unknown = import.meta.env[key];
    return typeof v === "string" ? v : "";
  } catch {
    return "";
  }
}

function getLeaveStorageKey(amoSlug: string, userId: string): string {
  return `amo_leave_${amoSlug}_${userId}`;
}

function getConnectionsStorageKey(amoSlug: string, userId: string): string {
  return `amo_calendar_connections_${amoSlug}_${userId}`;
}

function renderDueStatus(summary: DueSummary): React.ReactElement {
  if (!summary.due_date) return <span className="text-muted">—</span>;
  const label = formatDate(summary.due_date);
  const days =
    typeof summary.days_to_due === "number" ? ` (${summary.days_to_due}d)` : "";
  const status = (summary.due_status || "").toUpperCase();
  const cls =
    status === "OVERDUE"
      ? "badge badge--danger"
      : status === "DUE_SOON"
      ? "badge badge--warning"
      : "badge badge--neutral";
  return <span className={cls}>{label + days}</span>;
}

function makeId(prefix = "ID"): string {
  // Not cryptographic; stable enough for local-only UI ids
  return `${prefix}-${Math.random().toString(36).slice(2, 10).toUpperCase()}`;
}

async function fetchPublicHolidays(year: number, country: string): Promise<Holiday[]> {
  // Uses a public holiday provider. If it ever changes, this remains isolated here.
  const url = `https://date.nager.at/api/v3/PublicHolidays/${year}/${country}`;
  const res = await fetch(url, { method: "GET" });
  if (!res.ok) throw new Error(`Holiday lookup failed (HTTP ${res.status})`);
  const payload: unknown = await res.json();
  if (!Array.isArray(payload)) return [];
  const data = payload as Array<Record<string, unknown>>;
  return data.map((h) => ({
    date: String(h.date),
    localName: String(h.localName || h.name || ""),
    name: String(h.name || h.localName || ""),
  }));
}

const DashboardPage: React.FC = () => {
  const params = useParams<{ amoCode?: string; department?: string }>();
  const navigate = useNavigate();

  const ctx = getContext();

  // IMPORTANT:
  // - URL param "amoCode" is actually the AMO login slug in your routes (e.g. "root").
  // - Auth context stores BOTH: amoCode (e.g. PLATFORM) and amoSlug (e.g. root).
  // Prefer slug, then fall back to code.
  const amoSlug = (params.amoCode ?? ctx.amoSlug ?? ctx.amoCode ?? "UNKNOWN").trim();

  const currentUser = getCachedUser();
  const isAdmin = isAdminUser(currentUser);
  const uiShellV2 = isUiShellV2Enabled();
  const isSuperuser =
    !!currentUser &&
    (currentUser.is_superuser || currentUser.role === "SUPERUSER");

  const [docAlerts, setDocAlerts] = useState<AircraftDocument[]>([]);
  const [docAlertsLoading, setDocAlertsLoading] = useState(false);
  const [docAlertsError, setDocAlertsError] = useState<string | null>(null);
  const [docBannerDismissed, setDocBannerDismissed] = useState(false);

  // ---- FIX: define fleet state used by the metrics block (prevents fleetError undefined) ----
  const [fleetLoading, setFleetLoading] = useState(false);
  const [fleetError, setFleetError] = useState<string | null>(null);
  const fleetCount = useMemo(() => {
    // For a first-time setup you likely have 0 aircraft; keep safe.
    // If doc alerts exist, approximate unique aircraft count from alerts.
    const serials = new Set(
      docAlerts
        .map((a) => a.aircraft_serial_number)
        .filter((v) => typeof v === "string" && v.trim())
        .map((v) => v.trim())
    );
    return serials.size;
  }, [docAlerts]);

  // ---- Planning due schedules (safe defaults; wire backend later) ----
  const [dueSummaries, setDueSummaries] = useState<DueSummary[]>([]);
  const [dueLoading, setDueLoading] = useState(false);
  const [dueError, setDueError] = useState<string | null>(null);

  // ---- Calendar / leave / holidays (local-first, stable) ----
  const [throttleStore, setThrottleStore] = useState<ThrottleStore>(() => getThrottleStore());

  const [calendarConnections, setCalendarConnections] = useState<CalendarConnections>({
    google: false,
    outlook: false,
  });

  const today = new Date();
  const [holidayCountry, setHolidayCountry] = useState<string>("KE");
  const [holidayYear, setHolidayYear] = useState<number>(today.getFullYear());
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [holidayLoading, setHolidayLoading] = useState(false);
  const [holidayError, setHolidayError] = useState<string | null>(null);

  const [leaveEntries, setLeaveEntries] = useState<LeaveEntry[]>([]);
  const [leaveForm, setLeaveForm] = useState<{ date: string; reason: string }>({
    date: "",
    reason: "",
  });
  const [planningSideTab, setPlanningSideTab] = useState<
    "actions" | "calendar" | "leave"
  >("actions");

  const [calendarMonth, setCalendarMonth] = useState<Date>(
    new Date(today.getFullYear(), today.getMonth(), 1)
  );

  // For normal users, this MUST be their assigned department (server-driven context).
  const assignedDept = useMemo(
    () => getAssignedDepartment(currentUser, ctx.department),
    [currentUser, ctx.department]
  );

  const allowedDepartments = useMemo(
    () => getAllowedDepartments(currentUser, assignedDept),
    [currentUser, assignedDept]
  );

  const requestedDeptRaw = (params.department || "").trim();
  const requestedDept: string | null =
    requestedDeptRaw ? normalizeDepartmentCode(requestedDeptRaw) : null;

  // ✅ Guard: normal users can ONLY access their assigned department.
  useEffect(() => {
    if (!currentUser) return;
    if (isAdmin) return;

    if (!assignedDept) {
      // Misconfigured account/session; bounce to AMO login
      navigate(`/maintenance/${amoSlug}/login`, { replace: true });
      return;
    }

    // Non-admins must never land in "admin"
    if (assignedDept === "admin") {
      navigate(`/maintenance/${amoSlug}/login`, { replace: true });
      return;
    }

    // If URL dept differs, hard-correct it (prevents cross-department browsing)
    if (requestedDept && !allowedDepartments.includes(requestedDept as DepartmentId)) {
      navigate(`/maintenance/${amoSlug}/${assignedDept}`, { replace: true });
      return;
    }

    // If URL dept is missing, send them to assigned dept
    if (!requestedDept) {
      navigate(`/maintenance/${amoSlug}/${assignedDept}`, { replace: true });
    }
  }, [
    currentUser,
    isAdmin,
    assignedDept,
    requestedDept,
    allowedDepartments,
    amoSlug,
    navigate,
  ]);

  // While we are correcting routes for non-admins, render nothing to avoid flicker.
  // The decision is applied after all hooks so hook order remains stable.
  const correctingRoute = Boolean(
    currentUser &&
    !isAdmin &&
    assignedDept &&
    (!requestedDept ||
      (requestedDept !== assignedDept &&
        !allowedDepartments.includes(requestedDept as DepartmentId)))
  );

  // Effective department for rendering
  const department: DepartmentId = useMemo(() => {
    if (isAdmin) {
      const d = requestedDept || assignedDept || "planning";
      return (isDepartmentId(d) ? d : "planning") as DepartmentId;
    }

    const d = assignedDept || "planning";
    return (isDepartmentId(d) ? d : "planning") as DepartmentId;
  }, [isAdmin, requestedDept, assignedDept]);

  const amoDisplay =
    amoSlug !== "UNKNOWN" ? decodeAmoCertFromUrl(amoSlug) : "AMO";

  const isCRSDept = department === "planning" || department === "production";
  const isSystemAdminDept = department === "admin";
  const shouldShowComplianceAlerts =
    department === "planning" ||
    department === "production";

  const blockingDocAlerts = useMemo(() => {
    return docAlerts.filter(
      (alert) =>
        alert.is_blocking ||
        alert.status === "OVERDUE" ||
        alert.missing_evidence
    );
  }, [docAlerts]);

  const blockingDocSignature = useMemo(() => {
    if (blockingDocAlerts.length === 0) return "";
    return blockingDocAlerts
      .map((alert) => String(alert.id))
      .sort()
      .join("|");
  }, [blockingDocAlerts]);

  const canManageUsers =
    !!currentUser &&
    (currentUser.is_superuser ||
      currentUser.is_amo_admin ||
      currentUser.role === "SUPERUSER" ||
      currentUser.role === "AMO_ADMIN");

  const handleNewCrs = () => {
    navigate(`/maintenance/${amoSlug}/${department}/crs/new`);
  };

  const handleCreateUser = () => {
    navigate(`/maintenance/${amoSlug}/admin/users/new`);
  };

  const handleFixDocuments = () => {
    navigate(`/maintenance/${amoSlug}/${department}/aircraft-documents`);
  };

  const handleHideDocBanner = () => {
    if (!blockingDocSignature) return;
    const stored = getLocalStorageJson<Record<string, string>>(
      DOC_ALERTS_BANNER_STORAGE_KEY,
      {}
    );
    setLocalStorageJson(DOC_ALERTS_BANNER_STORAGE_KEY, {
      ...stored,
      [amoSlug]: blockingDocSignature,
    });
    setDocBannerDismissed(true);
  };

  const renderMetric = (
    label: string,
    value: number | string,
    target = 0
  ) => (
    <div className="metric-card" key={label}>
      <div className="metric-card__value">{value}</div>
      <div className="metric-card__label">{label}</div>
      <div className="metric-card__bar">
        <span style={{ width: target ? `${Math.min(100, (Number(value) / target) * 100)}%` : "0%" }} />
      </div>
    </div>
  );

  // Fleet metrics are currently derived safely (no backend dependency).
  // Keep hooks here so future API wiring is contained and doesn't break the page.
  useEffect(() => {
    let mounted = true;
    const run = async () => {
      setFleetLoading(false);
      setFleetError(null);
      if (!mounted) return;
    };
    run();
    return () => {
      mounted = false;
    };
  }, [amoSlug]);

  // Planning "due schedules" placeholder (safe). Wire to backend later if needed.
  useEffect(() => {
    let mounted = true;
    const run = async () => {
      if (department !== "planning") return;
      setDueLoading(false);
      setDueError(null);
      if (!mounted) return;
      setDueSummaries([]);
    };
    run();
    return () => {
      mounted = false;
    };
  }, [department, amoSlug]);

  useEffect(() => {
    if (!shouldShowComplianceAlerts) {
      setDocAlerts([]);
      setDocAlertsLoading(false);
      setDocAlertsError(null);
      setDocBannerDismissed(false);
      return;
    }

    let isMounted = true;
    const loadAlerts = async () => {
      setDocAlertsLoading(true);
      setDocAlertsError(null);
      try {
        const data = await listDocumentAlerts({ due_within_days: 45 });
        if (!isMounted) return;
        setDocAlerts(data);
      } catch (err: unknown) {
        if (!isMounted) return;
        setDocAlertsError(
          err instanceof Error
            ? err.message
            : "Unable to load aircraft document alerts."
        );
      } finally {
        if (isMounted) setDocAlertsLoading(false);
      }
    };

    loadAlerts();
    return () => {
      isMounted = false;
    };
  }, [shouldShowComplianceAlerts]);

  useEffect(() => {
    if (!blockingDocSignature) {
      setDocBannerDismissed(false);
      return;
    }
    if (!isSuperuser) {
      setDocBannerDismissed(false);
      return;
    }
    const stored = getLocalStorageJson<Record<string, string>>(
      DOC_ALERTS_BANNER_STORAGE_KEY,
      {}
    );
    setDocBannerDismissed(stored[amoSlug] === blockingDocSignature);
  }, [amoSlug, blockingDocSignature, isSuperuser]);

  // ---- Calendar helpers ----
  useEffect(() => {
    // Load throttle store once, then keep local state in sync with storage updates you may add later.
    setThrottleStore(getThrottleStore());
  }, []);

  useEffect(() => {
    if (!currentUser?.id) return;
    const key = getConnectionsStorageKey(amoSlug, currentUser.id);
    const stored = getLocalStorageJson<CalendarConnections>(key, {
      google: false,
      outlook: false,
    });
    setCalendarConnections(stored);
  }, [amoSlug, currentUser?.id]);

  const handleConnectCalendar = (provider: CalendarProvider) => {
    const url =
      provider === "google"
        ? safeEnv("VITE_CALENDAR_GOOGLE_OAUTH_URL")
        : safeEnv("VITE_CALENDAR_OUTLOOK_OAUTH_URL");

    if (!url) {
      alert(
        `Calendar OAuth URL not configured. Set ${
          provider === "google"
            ? "VITE_CALENDAR_GOOGLE_OAUTH_URL"
            : "VITE_CALENDAR_OUTLOOK_OAUTH_URL"
        } in your frontend environment.`
      );
      return;
    }

    // Open OAuth flow (best-effort; your backend should handle callback)
    window.open(url, "_blank", "noopener,noreferrer");

    if (!currentUser?.id) return;
    const next = { ...calendarConnections, [provider]: true };
    setCalendarConnections(next);
    setLocalStorageJson(getConnectionsStorageKey(amoSlug, currentUser.id), next);
  };

  const handleDisconnectCalendar = (provider: CalendarProvider) => {
    if (!currentUser?.id) return;
    const next = { ...calendarConnections, [provider]: false };
    setCalendarConnections(next);
    setLocalStorageJson(getConnectionsStorageKey(amoSlug, currentUser.id), next);
  };

  // Leave storage
  useEffect(() => {
    if (!currentUser?.id) return;
    const key = getLeaveStorageKey(amoSlug, currentUser.id);
    const stored = getLocalStorageJson<LeaveEntry[]>(key, []);
    setLeaveEntries(
      (stored || []).filter(
        (e) => typeof e?.date === "string" && e.date.length >= 10
      )
    );
  }, [amoSlug, currentUser?.id]);

  const persistLeave = (entries: LeaveEntry[]) => {
    if (!currentUser?.id) return;
    const key = getLeaveStorageKey(amoSlug, currentUser.id);
    setLocalStorageJson(key, entries);
    setLeaveEntries(entries);
  };

  const handleAddLeave = (e: React.FormEvent) => {
    e.preventDefault();
    const date = (leaveForm.date || "").trim();
    if (!date) return;

    const reason = (leaveForm.reason || "").trim() || "Leave";
    const exists = leaveEntries.some((x) => x.date === date);

    const next = exists
      ? leaveEntries.map((x) => (x.date === date ? { ...x, reason } : x))
      : [...leaveEntries, { id: makeId("LV"), date, reason }];

    // Keep ordered by date
    next.sort((a, b) => a.date.localeCompare(b.date));
    persistLeave(next);

    setLeaveForm({ date: "", reason: "" });
  };

  const handleRemoveLeave = (id: string) => {
    const next = leaveEntries.filter((x) => x.id !== id);
    persistLeave(next);
  };

  // Holidays (cached)
  useEffect(() => {
    let mounted = true;

    const run = async () => {
      const country = (holidayCountry || "").trim().toUpperCase();
      const year = Number(holidayYear);

      if (!country || country.length !== 2 || !Number.isFinite(year) || year < 1970) {
        setHolidayError("Enter a valid 2-letter country code and year.");
        setHolidays([]);
        return;
      }

      const cacheKey = `amo_public_holidays_${country}_${year}`;
      setHolidayLoading(true);
      setHolidayError(null);

      try {
        if (throttleStore.cacheHolidays) {
          const cached = getLocalStorageJson<Holiday[] | null>(cacheKey, null);
          if (cached && Array.isArray(cached) && cached.length > 0) {
            if (!mounted) return;
            setHolidays(cached);
            setHolidayLoading(false);
            return;
          }
        }

        const data = await fetchPublicHolidays(year, country);
        if (!mounted) return;
        setHolidays(data);

        if (throttleStore.cacheHolidays) {
          setLocalStorageJson(cacheKey, data);
        }
      } catch (err: unknown) {
        if (!mounted) return;
        setHolidays([]);
        setHolidayError(
          err instanceof Error ? err.message : "Unable to load public holidays."
        );
      } finally {
        if (mounted) setHolidayLoading(false);
      }
    };

    // Only auto-fetch on planning dashboard (keeps noise down)
    if (department === "planning") run();

    return () => {
      mounted = false;
    };
  }, [department, holidayCountry, holidayYear, throttleStore.cacheHolidays]);

  if (correctingRoute) return null;

  return (
    <DepartmentLayout amoCode={amoSlug} activeDepartment={department}>
      {uiShellV2 && department !== "planning" && department !== "production" ? (
        <DepartmentLandingScaffold departmentLabel={niceLabel(department)} />
      ) : (
        <>
          <header className="page-header">
        <h1 className="page-header__title">
          {niceLabel(department)} · {amoDisplay}
        </h1>
        <p className="page-header__subtitle">
          Welcome to the {niceLabel(department).toLowerCase()} dashboard for AMO{" "}
          <strong>{amoDisplay}</strong>.
        </p>
      </header>

      {shouldShowComplianceAlerts &&
        blockingDocAlerts.length > 0 &&
        !docBannerDismissed && (
          <section className="page-section">
            <div className="info-banner info-banner--warning">
              <div>
                <strong>Aircraft document blockers detected</strong>
                <p className="text-muted" style={{ margin: "4px 0 0" }}>
                  Work on affected aircraft is blocked until overdue or missing
                  evidence is resolved. Upload the latest compliance evidence to
                  restore planning and production workflows.
                </p>
                <ul style={{ margin: "8px 0 0", paddingLeft: 18 }}>
                  {blockingDocAlerts.slice(0, 3).map((alert) => (
                    <li key={alert.id}>
                      {alert.aircraft_serial_number} ·{" "}
                      {String(alert.document_type || "").replace(/_/g, " ")} ·{" "}
                      {String(alert.status || "").replace(/_/g, " ")}
                      {alert.days_to_expiry !== null &&
                        alert.days_to_expiry !== undefined &&
                        ` (${alert.days_to_expiry} days)`}
                      {alert.missing_evidence && " · Evidence missing"}
                    </li>
                  ))}
                  {blockingDocAlerts.length > 3 && (
                    <li>
                      +{blockingDocAlerts.length - 3} more blocking documents
                    </li>
                  )}
                </ul>
              </div>
              <div className="page-section__actions">
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleFixDocuments}
                >
                  Fix documents
                </button>
                {isSuperuser && (
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={handleHideDocBanner}
                  >
                    Hide
                  </button>
                )}
              </div>
            </div>
          </section>
        )}

      {isCRSDept && (
        <section className="page-section">
          <h2 className="page-section__title">
            Certificates of Release to Service
          </h2>
          <p className="page-section__body">
            Create, track, and download CRS forms for completed maintenance.
          </p>
          <button
            type="button"
            className="primary-chip-btn"
            onClick={handleNewCrs}
          >
            + New CRS
          </button>
        </section>
      )}

      {!isSystemAdminDept && (
        <section className="page-section">
          <h2 className="page-section__title">Key metrics</h2>
          {fleetError && <p className="error-text">{fleetError}</p>}
          {fleetLoading && <p className="text-muted">Loading metrics…</p>}

          {!fleetLoading && (
            <div className="metric-grid">
              {department === "planning" && (
                <>
                  {renderMetric("Fleet size", fleetCount, Math.max(1, fleetCount))}
                  {renderMetric("Available slots", 0)}
                  {renderMetric("Upcoming checks", 0)}
                </>
              )}
              {department === "production" && (
                <>
                  {renderMetric("Active work orders", 0)}
                  {renderMetric("CRS issued", 0)}
                  {renderMetric("Delays", 0)}
                </>
              )}
              {department === "safety" && (
                <>
                  {renderMetric("Hazard reports", 0)}
                  {renderMetric("Mitigations", 0)}
                  {renderMetric("Safety actions", 0)}
                </>
              )}
              {department === "stores" && (
                <>
                  {renderMetric("Stockouts", 0)}
                  {renderMetric("Reorder lines", 0)}
                  {renderMetric("Inbound shipments", 0)}
                </>
              )}
              {department === "maintenance" && (
                <>
                  {renderMetric("Work packages", 0)}
                  {renderMetric("Tech logs", 0)}
                  {renderMetric("Deferred items", 0)}
                </>
              )}
              {department === "workshops" && (
                <>
                  {renderMetric("Shop orders", 0)}
                  {renderMetric("Components in work", 0)}
                  {renderMetric("Turnaround delays", 0)}
                </>
              )}
            </div>
          )}
        </section>
      )}

      {department === "planning" && (
        <section className="planning-overview">
          <div className="planning-overview__header">
            <div>
              <h2 className="page-section__title">Planning control</h2>
              <p className="page-section__body">
                Maintain upcoming schedules, team availability, and planning inputs.
              </p>
            </div>
            <div className="planning-overview__actions">
              <button
                type="button"
                className="primary-chip-btn"
                onClick={() =>
                  navigate(`/maintenance/${amoSlug}/${department}/aircraft-import`)
                }
              >
                Setup aircraft
              </button>
              <button
                type="button"
                className="text-link"
                onClick={() =>
                  navigate(`/maintenance/${amoSlug}/${department}/component-import`)
                }
              >
                Import components
              </button>
            </div>
          </div>

          <div className="planning-overview__kpis">
            <div className="mini-kpi">
              <span className="mini-kpi__label">Due schedules</span>
              <span className="mini-kpi__value">{dueSummaries.length}</span>
            </div>
            <div className="mini-kpi">
              <span className="mini-kpi__label">Due in 7 days</span>
              <span className="mini-kpi__value">
                {dueSummaries.filter((s) => (s.days_to_due ?? 999) <= 7).length}
              </span>
            </div>
            <div className="mini-kpi">
              <span className="mini-kpi__label">Leave days</span>
              <span className="mini-kpi__value">{leaveEntries.length}</span>
            </div>
            <div className="mini-kpi">
              <span className="mini-kpi__label">Holiday entries</span>
              <span className="mini-kpi__value">{holidays.length}</span>
            </div>
          </div>

          <div className="planning-overview__grid">
            <div className="planning-overview__main">
              <div className="card planning-panel">
                <div className="planning-panel__header">
                  <h3>Upcoming maintenance due</h3>
                  {dueError && <span className="error-text">{dueError}</span>}
                </div>
                {dueLoading && <p className="text-muted">Loading due schedules…</p>}
                {!dueLoading && (
                  <div className="table-responsive">
                    <table className="table table-compact">
                      <thead>
                        <tr>
                          <th>Aircraft</th>
                          <th>Next task</th>
                          <th>Due</th>
                        </tr>
                      </thead>
                      <tbody>
                        {dueSummaries.map((summary) => (
                          <tr key={summary.aircraft_serial_number}>
                            <td>{summary.aircraft_serial_number}</td>
                            <td>{summary.next_due_task_code || "—"}</td>
                            <td>{renderDueStatus(summary)}</td>
                          </tr>
                        ))}
                        {dueSummaries.length === 0 && (
                          <tr>
                            <td colSpan={3} className="text-muted">
                              No due data yet.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              <details className="planning-disclosure">
                <summary>Month view calendar</summary>
                <div className="planning-disclosure__content">
                  <div className="planning-month-header">
                    <h4>{calendarMonth.toLocaleString("en-US", { month: "long", year: "numeric" })}</h4>
                    <div className="planning-month-actions">
                      <button
                        type="button"
                        className="secondary-chip-btn"
                        onClick={() =>
                          setCalendarMonth(
                            new Date(
                              calendarMonth.getFullYear(),
                              calendarMonth.getMonth() - 1,
                              1
                            )
                          )
                        }
                      >
                        ‹ Prev
                      </button>
                      <button
                        type="button"
                        className="secondary-chip-btn"
                        onClick={() =>
                          setCalendarMonth(
                            new Date(
                              calendarMonth.getFullYear(),
                              calendarMonth.getMonth() + 1,
                              1
                            )
                          )
                        }
                      >
                        Next ›
                      </button>
                    </div>
                  </div>
                  <div className="planning-calendar-grid">
                    {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((label) => (
                      <div key={label} className="planning-calendar-weekday">
                        {label}
                      </div>
                    ))}
                    {buildMonthDays(calendarMonth).map((day) => {
                      const iso = day.toISOString().slice(0, 10);
                      const isCurrentMonth = day.getMonth() === calendarMonth.getMonth();
                      const leave = leaveEntries.find((entry) => entry.date === iso);
                      const holiday = holidays.find((entry) => entry.date === iso);
                      return (
                        <div
                          key={iso}
                          className={`planning-calendar-day${
                            isCurrentMonth ? "" : " planning-calendar-day--muted"
                          }`}
                        >
                          <div className="planning-calendar-day__date">{day.getDate()}</div>
                          <div className="planning-calendar-day__badges">
                            {holiday && (
                              <div className="badge planning-calendar-badge planning-calendar-badge--holiday">
                                {holiday.localName}
                              </div>
                            )}
                            {leave && (
                              <div className="badge planning-calendar-badge planning-calendar-badge--leave">
                                {leave.reason}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </details>
            </div>

            <div className="planning-overview__side">
              <div className="card planning-panel">
                <div className="planning-panel__tabs">
                  <button
                    type="button"
                    className={`planning-tab${planningSideTab === "actions" ? " planning-tab--active" : ""}`}
                    onClick={() => setPlanningSideTab("actions")}
                  >
                    Quick actions
                  </button>
                  <button
                    type="button"
                    className={`planning-tab${planningSideTab === "calendar" ? " planning-tab--active" : ""}`}
                    onClick={() => setPlanningSideTab("calendar")}
                  >
                    Calendar
                  </button>
                  <button
                    type="button"
                    className={`planning-tab${planningSideTab === "leave" ? " planning-tab--active" : ""}`}
                    onClick={() => setPlanningSideTab("leave")}
                  >
                    Leave
                  </button>
                </div>

                {planningSideTab === "actions" && (
                  <div className="planning-panel__body">
                    <p className="text-muted">
                      Keep the planning backlog current and route updates to the right teams.
                    </p>
                    <div className="planning-action-list">
                      <button
                        type="button"
                        className="secondary-chip-btn"
                        onClick={() =>
                          navigate(`/maintenance/${amoSlug}/${department}/aircraft-documents`)
                        }
                      >
                        Review aircraft docs
                      </button>
                      <button
                        type="button"
                        className="secondary-chip-btn"
                        onClick={() =>
                          navigate(`/maintenance/${amoSlug}/${department}/work-orders`)
                        }
                      >
                        View work orders
                      </button>
                      <button
                        type="button"
                        className="secondary-chip-btn"
                        onClick={() =>
                          navigate(`/maintenance/${amoSlug}/${department}/component-import`)
                        }
                      >
                        Import components
                      </button>
                    </div>
                    <details className="planning-disclosure planning-disclosure--compact">
                      <summary>Planning context</summary>
                      <div className="planning-disclosure__content">
                        <p className="text-muted">
                          Fleet utilization, inventory readiness, and third-party intake views
                          activate once integrations are enabled.
                        </p>
                      </div>
                    </details>
                  </div>
                )}

                {planningSideTab === "calendar" && (
                  <div className="planning-panel__body">
                    <div className="planning-field">
                      <span className="planning-field__label">Calendar connections</span>
                      <div className="planning-inline-actions">
                        <button
                          type="button"
                          className="secondary-chip-btn"
                          onClick={() =>
                            calendarConnections.google
                              ? handleDisconnectCalendar("google")
                              : handleConnectCalendar("google")
                          }
                        >
                          {calendarConnections.google ? "Disconnect Google" : "Connect Google"}
                        </button>
                        <button
                          type="button"
                          className="secondary-chip-btn"
                          onClick={() =>
                            calendarConnections.outlook
                              ? handleDisconnectCalendar("outlook")
                              : handleConnectCalendar("outlook")
                          }
                        >
                          {calendarConnections.outlook
                            ? "Disconnect Outlook"
                            : "Connect Outlook"}
                        </button>
                      </div>
                    </div>

                    <div className="planning-field">
                      <span className="planning-field__label">Public holidays</span>
                      <div className="form-row" style={{ gap: 8 }}>
                        <label className="form-control">
                          <span>Country</span>
                          <input
                            value={holidayCountry}
                            onChange={(e) =>
                              setHolidayCountry(e.target.value.toUpperCase())
                            }
                            maxLength={2}
                            placeholder="KE"
                          />
                        </label>
                        <label className="form-control">
                          <span>Year</span>
                          <input
                            type="number"
                            value={holidayYear}
                            onChange={(e) => setHolidayYear(Number(e.target.value))}
                          />
                        </label>
                      </div>
                      {holidayLoading && <p className="text-muted">Loading holidays…</p>}
                      {holidayError && <p className="error-text">{holidayError}</p>}
                      {!holidayLoading && holidays.length > 0 && (
                        <ul className="planning-list">
                          {holidays.slice(0, 5).map((holiday) => (
                            <li key={`${holiday.date}-${holiday.name}`}>
                              {formatDate(holiday.date)} · {holiday.localName}
                            </li>
                          ))}
                        </ul>
                      )}
                      {!holidayLoading && !holidayError && holidays.length === 0 && (
                        <p className="text-muted">No holidays found for that selection.</p>
                      )}
                    </div>
                    {currentUser?.amo_id && (
                      <p className="text-muted">
                        Throttle budget:{" "}
                        <strong>
                          {throttleStore.amo[currentUser.amo_id]?.perUser[currentUser.id] ??
                            throttleStore.amo[currentUser.amo_id]?.limit ??
                            70}
                          %
                        </strong>{" "}
                        · Adjust in Admin → Usage Throttling.
                      </p>
                    )}
                  </div>
                )}

                {planningSideTab === "leave" && (
                  <div className="planning-panel__body">
                    <form onSubmit={handleAddLeave} className="form-row" style={{ gap: 8 }}>
                      <label className="form-control">
                        <span>Date</span>
                        <input
                          type="date"
                          value={leaveForm.date}
                          onChange={(e) =>
                            setLeaveForm((prev) => ({ ...prev, date: e.target.value }))
                          }
                          required
                        />
                      </label>
                      <label className="form-control">
                        <span>Reason</span>
                        <input
                          value={leaveForm.reason}
                          onChange={(e) =>
                            setLeaveForm((prev) => ({ ...prev, reason: e.target.value }))
                          }
                          placeholder="Annual leave"
                        />
                      </label>
                      <div style={{ alignSelf: "end" }}>
                        <button type="submit" className="primary-chip-btn">
                          Add leave
                        </button>
                      </div>
                    </form>
                    {leaveEntries.length === 0 ? (
                      <p className="text-muted">No leave days scheduled yet.</p>
                    ) : (
                      <ul className="planning-list">
                        {leaveEntries.slice(0, 6).map((entry) => (
                          <li key={entry.id}>
                            <span>
                              {formatDate(entry.date)} · {entry.reason}
                            </span>
                            <button
                              type="button"
                              className="text-link"
                              onClick={() => handleRemoveLeave(entry.id)}
                            >
                              Remove
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {isSystemAdminDept && (
        <section className="page-section">
          <h2 className="page-section__title">System Administration</h2>
          <p className="page-section__body">
            User account management for this AMO. Access is restricted to AMO
            Administrators and platform Superusers in line with AMO and
            regulatory requirements.
          </p>

          {canManageUsers ? (
            <div className="page-section__actions">
              <button
                type="button"
                className="primary-chip-btn"
                onClick={handleCreateUser}
              >
                + Create new user
              </button>
            </div>
          ) : (
            <p className="page-section__body">
              You are signed in to the System Admin dashboard but do not have
              the required system privileges to manage user accounts. Please
              contact Quality or the AMO System Administrator.
            </p>
          )}
        </section>
      )}

      {shouldShowComplianceAlerts && (
        <section className="page-section">
          <h2 className="page-section__title">Airworthiness document alerts</h2>
          <p className="page-section__body">
            Planning and Production are notified when documents like C
            of A, ARC, or radio licenses are due or missing. Work on an affected
            aircraft is blocked until updated evidence is uploaded.
          </p>

          {docAlertsLoading && (
            <p className="page-section__body">Loading document alerts…</p>
          )}
          {docAlertsError && (
            <p className="page-section__body error-text">{docAlertsError}</p>
          )}
          {!docAlertsLoading && !docAlertsError && (
            <>
              {(docAlerts?.length || 0) === 0 ? (
                <p className="page-section__body">
                  No document alerts found in the next 45 days.
                </p>
              ) : (
                <ul className="card-list">
                  {docAlerts.map((alert) => (
                    <li className="card card--border" key={alert.id}>
                      <h3 className="card__title">
                        {String(alert.document_type || "").replace(/_/g, " ")} ·{" "}
                        {alert.aircraft_serial_number}
                      </h3>
                      <p className="card__subtitle">
                        Authority: {alert.authority} · Status: {alert.status}
                      </p>
                      <p className="card__body">
                        {alert.expires_on
                          ? `Expires on ${alert.expires_on}${
                              alert.days_to_expiry !== null &&
                              alert.days_to_expiry !== undefined
                                ? ` (${alert.days_to_expiry} days)`
                                : ""
                            }`
                          : "Expiry not recorded"}
                        {alert.missing_evidence && " · Evidence missing"}
                      </p>
                    </li>
                  ))}
                </ul>
              )}
            </>
          )}
        </section>
      )}

      {!isSystemAdminDept && currentUser && (
        <section className="page-section">
          <h2 className="page-section__title">Your widgets</h2>
          {(() => {
            const storageKey = getWidgetStorageKey(amoSlug, currentUser.id, department);
            let selected: string[] = [];
            try {
              const raw = localStorage.getItem(storageKey);
              selected = raw ? (JSON.parse(raw) as string[]) : [];
            } catch {
              selected = [];
            }
            const widgets = DASHBOARD_WIDGETS.filter(
              (widget) =>
                selected.includes(widget.id) &&
                widget.departments.some(
                  (widgetDepartment) => widgetDepartment === department
                ) &&
                canSeeDashboardWidget(widget, currentUser, department)
            );
            if (widgets.length === 0) {
              return (
                <p className="text-muted">
                  No widgets added yet. Use Dashboard widgets in your profile menu.
                </p>
              );
            }
            return (
              <div className="metric-grid">
                {widgets.map((widget) => (
                  <div key={widget.id} className="metric-card">
                    <div className="metric-card__value">0</div>
                    <div className="metric-card__label">{widget.label}</div>
                    <div className="text-muted">{widget.description}</div>
                    <div className="metric-card__bar">
                      <span style={{ width: "0%" }} />
                    </div>
                  </div>
                ))}
              </div>
            );
          })()}
        </section>
      )}

          {!isCRSDept && !isSystemAdminDept && (
            <section className="page-section">
              <p className="page-section__body">
                Department widgets for {niceLabel(department)} will appear here.
              </p>
            </section>
          )}
        </>
      )}
    </DepartmentLayout>
  );
};

export default DashboardPage;
