// src/pages/AdminUserNewPage.tsx
import React, { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";

import {
  createAdminUser,
  listAdminAmos,
  listAdminDepartments,
  listStaffCodeSuggestions,
  setActiveAmoId,
  LS_ACTIVE_AMO_ID,
} from "../services/adminUsers";
import type {
  AdminAmoRead,
  AdminDepartmentRead,
  AdminUserCreatePayload,
  AccountRole,
} from "../services/adminUsers";
import { getCachedUser, getContext } from "../services/auth";
import { portalErrorMessage } from "../services/portalError";
import { readCachedAdminProfileState } from "../services/adminProfileMode";
import { getTenantAccessFramework } from "../services/accessProfiles";
import { Button, InlineAlert, PageHeader, Panel } from "../components/UI/Admin";
import DepartmentLayout from "../components/Layout/DepartmentLayout";
import "../styles/admin-user-management.css";

type UrlParams = {
  amoCode?: string;
};

const DEFAULT_ROLE: AccountRole = "USER";

const AdminUserNewPage: React.FC = () => {
  const navigate = useNavigate();
  const { amoCode } = useParams<UrlParams>();

  const ctx = getContext();
  const currentUser = getCachedUser();

  const isAdmin = useMemo(() => {
    if (!currentUser) return false;
    return Boolean(
      currentUser.is_superuser
      || currentUser.is_amo_admin
      || currentUser.role === "SUPERUSER"
      || currentUser.role === "AMO_ADMIN"
      || readCachedAdminProfileState(amoCode ?? ctx.amoCode ?? "UNKNOWN")?.active
    );
  }, [amoCode, ctx.amoCode, currentUser]);

  const isSuperuser = !!currentUser?.is_superuser;

  const backTarget = useMemo(() => {
    const slug = amoCode ?? ctx.amoCode ?? null;
    return slug ? `/maintenance/${slug}/admin/users` : "/login";
  }, [amoCode, ctx.amoCode]);

  const resolvedAmoCode = amoCode ?? ctx.amoCode ?? "UNKNOWN";

  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    role: DEFAULT_ROLE as AccountRole,
    positionTitle: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });
  const [accessProfileId, setAccessProfileId] = useState("");
  const [standingAmoAdmin, setStandingAmoAdmin] = useState(false);
  const [staffCodeOptions, setStaffCodeOptions] = useState<string[]>([]);
  const [staffCodeLoading, setStaffCodeLoading] = useState(false);
  const [staffCodeError, setStaffCodeError] = useState<string | null>(null);
  const [selectedStaffCode, setSelectedStaffCode] = useState<string>("");
  const [staffCodeSeed, setStaffCodeSeed] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [amos, setAmos] = useState<AdminAmoRead[]>([]);
  const [amoLoading, setAmoLoading] = useState(false);
  const [amoError, setAmoError] = useState<string | null>(null);
  const [selectedAmoId, setSelectedAmoId] = useState<string>(() => {
    const stored = localStorage.getItem(LS_ACTIVE_AMO_ID);
    return stored && stored.trim() ? stored.trim() : "";
  });
  const [departments, setDepartments] = useState<AdminDepartmentRead[]>([]);
  const [departmentsLoading, setDepartmentsLoading] = useState(false);
  const [departmentsError, setDepartmentsError] = useState<string | null>(null);
  const [selectedDepartmentId, setSelectedDepartmentId] = useState<string>("");

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const creatingPlatformSuperuser = form.role === "SUPERUSER";
  const platformRootAmo = useMemo(
    () => amos.find((amo) =>
      amo.amo_code.toUpperCase() === "ROOT"
      || ["root", "system"].includes(amo.login_slug.toLowerCase())
    ) ?? null,
    [amos]
  );
  const selectedAmo = useMemo(() => amos.find((amo) => amo.id === selectedAmoId) ?? null, [amos, selectedAmoId]);
  const accountTargetAmoId = isSuperuser
    ? (creatingPlatformSuperuser ? platformRootAmo?.id || "" : selectedAmoId)
    : currentUser?.amo_id || "";
  const accessFrameworkQuery = useQuery({
    queryKey: ["accounts", "access-framework", accountTargetAmoId],
    queryFn: () => getTenantAccessFramework(accountTargetAmoId),
    enabled: Boolean(accountTargetAmoId) && !creatingPlatformSuperuser,
    staleTime: 30_000,
  });
  const activeProfiles = useMemo(
    () => (accessFrameworkQuery.data?.profiles || []).filter(
      (profile) => profile.is_active && !profile.is_regulated,
    ),
    [accessFrameworkQuery.data?.profiles],
  );
  const selectedAccessProfile = useMemo(
    () => activeProfiles.find((profile) => profile.id === accessProfileId) || null,
    [accessProfileId, activeProfiles],
  );

  const pageTitle = useMemo(() => {
    const label = creatingPlatformSuperuser
      ? platformRootAmo?.name || "Platform ROOT"
      : selectedAmo?.name || resolvedAmoCode.toUpperCase();
    return `Create user · ${label}`;
  }, [creatingPlatformSuperuser, platformRootAmo?.name, resolvedAmoCode, selectedAmo]);

  const activeDepartments = useMemo(
    () => departments.filter((dept) => dept.is_active),
    [departments]
  );

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    if (name === "role") {
      const role = value as AccountRole;
      setForm((prev) => ({ ...prev, role }));
      return;
    }
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const validate = (): string | null => {
    const email = form.email.trim();

    if (!email) return "Email is required.";
    if (!form.firstName.trim() || !form.lastName.trim()) {
      return "First name and last name are required.";
    }

    if (!form.password) return "Password is required.";
    if (form.password !== form.confirmPassword) return "Passwords do not match.";

    if (form.password.length < 12) {
      return "Password must be at least 12 characters.";
    }
    const hasUpper = /[A-Z]/.test(form.password);
    const hasLower = /[a-z]/.test(form.password);
    const hasDigit = /\d/.test(form.password);
    if (!(hasUpper && hasLower && hasDigit)) {
      return "Password must include upper/lower case letters and a number.";
    }

    // Only SUPERUSER can create SUPERUSER
    if (form.role === "SUPERUSER" && !isSuperuser) {
      return "Only a platform superuser can create another superuser.";
    }

    if (isSuperuser && creatingPlatformSuperuser && !platformRootAmo) {
      return "The platform ROOT tenant is unavailable. Create or restore it before adding another superuser.";
    }
    if (isSuperuser && !creatingPlatformSuperuser && !selectedAmoId) {
      return "Select an AMO for this user.";
    }
    if (!creatingPlatformSuperuser && activeDepartments.length > 0 && !selectedDepartmentId) {
      return "Select a department for this user.";
    }
    if (!creatingPlatformSuperuser && !accessProfileId) {
      return "Select a tenant access profile for this user.";
    }
    if (!selectedStaffCode) {
      return "Select a staff code suggestion before creating the user.";
    }

    return null;
  };

  const generateSecurePassword = () => {
    const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const lower = "abcdefghijklmnopqrstuvwxyz";
    const digits = "0123456789";
    const symbols = "!@#$%^&*()-_=+[]{}<>?";
    const all = upper + lower + digits + symbols;

    const randomIndex = (length: number) => {
      if (!globalThis.crypto?.getRandomValues) {
        throw new Error("Secure browser randomness is unavailable.");
      }
      const ceiling = 0x1_0000_0000 - (0x1_0000_0000 % length);
      const value = new Uint32Array(1);
      do globalThis.crypto.getRandomValues(value); while (value[0] >= ceiling);
      return value[0] % length;
    };
    const pick = (chars: string) => chars[randomIndex(chars.length)];

    const base = [
      pick(upper),
      pick(lower),
      pick(digits),
      pick(symbols),
    ];

    for (let i = base.length; i < 14; i += 1) {
      base.push(pick(all));
    }

    for (let index = base.length - 1; index > 0; index -= 1) {
      const swapIndex = randomIndex(index + 1);
      [base[index], base[swapIndex]] = [base[swapIndex], base[index]];
    }
    const password = base.join("");
    setForm((prev) => ({ ...prev, password, confirmPassword: password }));
  };

  const copyPassword = async () => {
    if (!form.password) return;
    try {
      if (!navigator.clipboard) {
        throw new Error("Clipboard unavailable");
      }
      await navigator.clipboard.writeText(form.password);
      setSuccess("Temporary password copied to clipboard.");
    } catch (err) {
      console.error("Failed to copy password", err);
      setError("Could not copy password. Please copy it manually.");
    }
  };

  React.useEffect(() => {
    if (!isSuperuser) return;

    const loadAmos = async () => {
      setAmoError(null);
      setAmoLoading(true);
      try {
        const data = await listAdminAmos();
        setAmos(data);
        if (!selectedAmoId && data.length > 0) {
          setSelectedAmoId(data[0].id);
        }
      } catch (err: unknown) {
        console.error("Failed to load AMOs", err);
        setAmoError(portalErrorMessage(err, "Failed to load AMOs."));
      } finally {
        setAmoLoading(false);
      }
    };

    loadAmos();
  }, [isSuperuser, selectedAmoId]);

  React.useEffect(() => {
    const loadDepartments = async () => {
      setDepartmentsError(null);
      if (!currentUser) return;
      if (creatingPlatformSuperuser) {
        setDepartments([]);
        setSelectedDepartmentId("");
        return;
      }
      const targetAmoId = isSuperuser ? selectedAmoId : currentUser.amo_id;
      if (!targetAmoId) {
        setDepartments([]);
        setSelectedDepartmentId("");
        return;
      }
      setDepartmentsLoading(true);
      try {
        const data = await listAdminDepartments(targetAmoId);
        setDepartments(data);
        const active = data.filter((dept) => dept.is_active);
        setSelectedDepartmentId((current) =>
          active.some((department) => department.id === current)
            ? current
            : active[0]?.id || ""
        );
      } catch (err: unknown) {
        console.error("Failed to load departments", err);
        setDepartmentsError(portalErrorMessage(err, "Failed to load departments."));
      } finally {
        setDepartmentsLoading(false);
      }
    };

    loadDepartments();
  }, [creatingPlatformSuperuser, currentUser, isSuperuser, selectedAmoId]);

  React.useEffect(() => {
    if (creatingPlatformSuperuser) {
      setAccessProfileId("");
      return;
    }
    setAccessProfileId((current) => {
      if (activeProfiles.some((profile) => profile.id === current)) return current;
      return activeProfiles.find((profile) => profile.code === "GENERAL_USER")?.id || activeProfiles[0]?.id || "";
    });
  }, [activeProfiles, creatingPlatformSuperuser]);

  React.useEffect(() => {
    if (!selectedAccessProfile) return;
    setForm((current) => ({
      ...current,
      role: selectedAccessProfile.base_role_key,
      positionTitle: selectedAccessProfile.is_regulated ? selectedAccessProfile.display_name : current.positionTitle,
    }));
  }, [selectedAccessProfile]);

  React.useEffect(() => {
    const first = form.firstName.trim();
    const last = form.lastName.trim();
    const targetAmoId = accountTargetAmoId;

    if (!first || !last || !targetAmoId) {
      setStaffCodeOptions([]);
      setSelectedStaffCode("");
      return;
    }

    setStaffCodeLoading(true);
    setStaffCodeError(null);

    const timer = window.setTimeout(() => {
      listStaffCodeSuggestions({
        first_name: first,
        last_name: last,
        amo_id: isSuperuser ? targetAmoId : undefined,
      })
        .then((data) => {
          const suggestions = data.suggestions || [];
          setStaffCodeOptions(suggestions);
          setSelectedStaffCode((prev) =>
            suggestions.includes(prev) ? prev : suggestions[0] || ""
          );
        })
        .catch((err: unknown) => {
          console.error("Failed to load staff code suggestions", err);
          setStaffCodeError(portalErrorMessage(err, "Failed to load staff code suggestions."));
          setStaffCodeOptions([]);
          setSelectedStaffCode("");
        })
        .finally(() => setStaffCodeLoading(false));
    }, 300);

    return () => window.clearTimeout(timer);
  }, [
    form.firstName,
    form.lastName,
    isSuperuser,
    accountTargetAmoId,
    staffCodeSeed,
  ]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!currentUser) {
      setError("No user session found. Please sign in again.");
      return;
    }
    if (!isAdmin) {
      setError("You do not have permission to create users.");
      return;
    }

    const v = validate();
    if (v) {
      setError(v);
      return;
    }

    setSubmitting(true);
    try {
      const first = form.firstName.trim();
      const last = form.lastName.trim();

      const payload: AdminUserCreatePayload = {
        staff_code: selectedStaffCode,
        email: form.email.trim().toLowerCase(),
        first_name: first,
        last_name: last,
        full_name: `${first} ${last}`.trim(),
        role: creatingPlatformSuperuser ? "SUPERUSER" : selectedAccessProfile!.base_role_key,
        access_profile_id: creatingPlatformSuperuser ? undefined : accessProfileId,
        is_amo_admin: isSuperuser && !creatingPlatformSuperuser ? standingAmoAdmin : false,
        position_title: form.positionTitle.trim() || undefined,
        phone: form.phone.trim() || undefined,
        password: form.password,
        amo_id: isSuperuser && !creatingPlatformSuperuser ? selectedAmoId || undefined : undefined,
        department_id: creatingPlatformSuperuser ? undefined : selectedDepartmentId || undefined,
        // NOTE:
        // Do NOT force amo_id here. adminUsers.ts resolves it safely:
        // - SUPERUSER: can target selected/active AMO
        // - others: forced to current user's AMO
      };

      await createAdminUser(payload);

      setSuccess("User created successfully.");
      setTimeout(() => navigate(backTarget), 600);
    } catch (err: unknown) {
      console.error("Failed to create user", err);
      setError(portalErrorMessage(err, "Failed to create user. Please try again."));
    } finally {
      setSubmitting(false);
    }
  };

  if (!currentUser) {
    return (
      <DepartmentLayout amoCode={resolvedAmoCode} activeDepartment="admin-users">
        <div className="admin-users-workspace admin-user-create-page">
          <PageHeader title="Create user" subtitle="Your session has expired or is unavailable." className="aum-brand-page-header admin-page-header--centered" />
          <Panel className="aum-brand-panel">
            <p className="admin-muted">You are not signed in. Please sign in again.</p>
            <Button onClick={() => navigate("/login")}>Go to login</Button>
          </Panel>
        </div>
      </DepartmentLayout>
    );
  }

  if (!isAdmin) {
    return (
      <DepartmentLayout amoCode={resolvedAmoCode} activeDepartment="admin-users">
        <div className="admin-users-workspace admin-user-create-page">
          <PageHeader title="Access denied" subtitle="Only tenant administrators can create users from this workspace." className="aum-brand-page-header admin-page-header--centered" />
          <Panel className="aum-brand-panel">
            <p className="admin-muted">
              You do not have permission to create users. Please contact the AMO
              Administrator or Quality/IT support.
            </p>
            <Button onClick={() => navigate(backTarget)}>Back</Button>
          </Panel>
        </div>
      </DepartmentLayout>
    );
  }

  return (
    <DepartmentLayout amoCode={resolvedAmoCode} activeDepartment="admin-users">
      <div className="admin-users-workspace admin-user-create-page">
        <PageHeader
          title={pageTitle}
          subtitle="Create an AMO user with the active tenant branding, access profile, and initial password policy already aligned."
          className="aum-brand-page-header admin-page-header--centered"
        />

        <Panel className="admin-user-form aum-brand-panel">
        <form onSubmit={handleSubmit} className="form-grid form-grid--two-column">
          {error && (
            <InlineAlert tone="danger" title="Error" className="form-row--span-2">
              <span>{error}</span>
            </InlineAlert>
          )}
          {success && (
            <InlineAlert tone="success" title="Success" className="form-row--span-2">
              <span>{success}</span>
            </InlineAlert>
          )}
          {amoError && (
            <InlineAlert tone="danger" title="Error" className="form-row--span-2">
              <span>{amoError}</span>
            </InlineAlert>
          )}
          {departmentsError && (
            <InlineAlert tone="danger" title="Error" className="form-row--span-2">
              <span>{departmentsError}</span>
            </InlineAlert>
          )}

          {isSuperuser && !creatingPlatformSuperuser && (
            <div className="form-row form-row--span-2">
              <label htmlFor="amoId">Target AMO</label>
              <select
                id="amoId"
                name="amoId"
                value={selectedAmoId}
                onChange={(e) => {
                  const nextId = e.target.value;
                  setSelectedAmoId(nextId);
                  setActiveAmoId(nextId);
                  setSelectedDepartmentId("");
                }}
                disabled={submitting || amoLoading}
                required
              >
                <option value="" disabled>
                  {amoLoading ? "Loading AMOs..." : "Select an AMO"}
                </option>
                {amos.map((amo) => (
                  <option key={amo.id} value={amo.id}>
                    {amo.name} ({amo.amo_code})
                  </option>
                ))}
              </select>
              <p className="form-hint">
                Select which AMO will own this tenant user.
              </p>
            </div>
          )}

          {isSuperuser && creatingPlatformSuperuser && (
            <InlineAlert tone="info" title="Platform ROOT identity" className="form-row--span-2">
              <span>
                Platform superusers are always owned by the ROOT tenant and are not assigned to an AMO department.
              </span>
            </InlineAlert>
          )}

          {!creatingPlatformSuperuser && <div className="form-row form-row--span-2">
            <div className="form-row__header">
              <label htmlFor="departmentId">Department</label>
              <button
                type="button"
                className="admin-link-btn"
                onClick={() => navigate(`/maintenance/${encodeURIComponent(amoCode || ctx.amoSlug || ctx.amoCode || "UNKNOWN")}/admin/amo-assets?section=departments`)}
              >
                Manage departments
              </button>
            </div>
            <select
              id="departmentId"
              name="departmentId"
              value={selectedDepartmentId}
              onChange={(e) => setSelectedDepartmentId(e.target.value)}
              disabled={submitting || departmentsLoading}
              required={activeDepartments.length > 0}
            >
              <option value="" disabled>
                {departmentsLoading ? "Loading departments..." : "Select a department"}
              </option>
              {activeDepartments.map((dept) => (
                <option key={dept.id} value={dept.id}>
                  {dept.name} ({dept.code})
                </option>
              ))}
            </select>
            <p className="form-hint">
              Assign the default department so the user lands in the right dashboard. Only active
              departments are listed.
            </p>
          </div>}
          {!creatingPlatformSuperuser && !departmentsLoading && activeDepartments.length === 0 && (
            <InlineAlert
              tone="warning"
              title="No departments yet"
              className="form-row--span-2"
              actions={(
                <Button
                  type="button"
                  size="sm"
                  variant="secondary"
                  onClick={() => navigate(`/maintenance/${encodeURIComponent(amoCode || ctx.amoSlug || ctx.amoCode || "UNKNOWN")}/admin/amo-assets?section=departments`)}
                >
                  Create department
                </Button>
              )}
            >
              <span>
                No custom departments found. The user will follow default access rules until
                departments are added.
              </span>
            </InlineAlert>
          )}

          <div className="form-row">
            <label htmlFor="firstName">First Name</label>
            <input
              id="firstName"
              name="firstName"
              type="text"
              value={form.firstName}
              onChange={handleChange}
              autoComplete="off"
              required
              disabled={submitting}
            />
          </div>

          <div className="form-row">
            <label htmlFor="lastName">Last Name</label>
            <input
              id="lastName"
              name="lastName"
              type="text"
              value={form.lastName}
              onChange={handleChange}
              autoComplete="off"
              required
              disabled={submitting}
            />
          </div>

          <div className="form-row form-row--span-2">
            <div className="form-row__header">
              <label htmlFor="staffCode">Staff Code (auto)</label>
              <button
                type="button"
                className="admin-link-btn"
                onClick={() => {
                  setStaffCodeSeed((prev) => prev + 1);
                }}
                disabled={staffCodeLoading || !form.firstName.trim() || !form.lastName.trim()}
              >
                Refresh suggestions
              </button>
            </div>
            <select
              id="staffCode"
              name="staffCode"
              value={selectedStaffCode}
              onChange={(e) => setSelectedStaffCode(e.target.value)}
              disabled={staffCodeLoading || staffCodeOptions.length === 0}
              required
            >
              <option value="" disabled>
                {staffCodeLoading ? "Generating staff codes..." : "Select a staff code"}
              </option>
              {staffCodeOptions.map((code) => (
                <option key={code} value={code}>
                  {code}
                </option>
              ))}
            </select>
            {staffCodeError ? (
              <p className="form-hint">{staffCodeError}</p>
            ) : (
              <p className="form-hint">
                Staff codes are generated from first/last name. Choose any suggested code.
              </p>
            )}
          </div>

          <div className="form-row form-row--span-2">
            <label htmlFor="email">Work Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              autoComplete="off"
              required
              disabled={submitting}
            />
          </div>

          {isSuperuser ? <div className="form-row form-row--span-2">
            <label htmlFor="role">Account kind</label>
            <select
              id="role"
              name="role"
              value={form.role}
              onChange={handleChange}
              disabled={submitting}
            >
              <option value="USER">Tenant user</option>
              <option value="SUPERUSER">Platform superuser</option>
            </select>
            <p className="form-hint">
              Platform superusers are ROOT-scoped support identities. Tenant operational access is assigned below.
            </p>
          </div> : null}

          {!creatingPlatformSuperuser ? <div className="form-row form-row--span-2">
            <div className="form-row__header"><label htmlFor="accessProfile">Tenant access profile</label><button type="button" className="admin-link-btn" onClick={() => navigate(`${backTarget}?tab=roles`)}>Manage profiles</button></div>
            <select id="accessProfile" value={accessProfileId} onChange={(event) => setAccessProfileId(event.target.value)} disabled={submitting || accessFrameworkQuery.isPending} required>
              <option value="">{accessFrameworkQuery.isPending ? "Loading profiles…" : "Select an access profile"}</option>
              {activeProfiles.map((profile) => <option key={profile.id} value={profile.id}>{profile.is_regulated ? "KCAR 2025 · " : ""}{profile.display_name}</option>)}
            </select>
            <p className="form-hint">{selectedAccessProfile?.description || "Profiles control module entry. Prescribed management appointments are assigned in Workforce; workflow decisions and personal certifying authorizations remain separate."}</p>
            {accessFrameworkQuery.isError ? <p className="form-hint">{portalErrorMessage(accessFrameworkQuery.error, "Access profiles could not be loaded.")}</p> : null}
            {!accessFrameworkQuery.isPending && !activeProfiles.length ? <InlineAlert tone="warning" title="Access framework required"><span>Open Access profiles and apply the AMO/MRO framework before creating tenant users.</span></InlineAlert> : null}
          </div> : null}

          {isSuperuser && !creatingPlatformSuperuser ? (
            <label className="form-row form-row--span-2 admin-checkbox-row">
              <input
                type="checkbox"
                checked={standingAmoAdmin}
                onChange={(event) => setStandingAmoAdmin(event.target.checked)}
                disabled={submitting}
              />
              <span>
                <strong>Standing AMO Administrator</strong>
                <small>Grants tenant-wide administration and module visibility immediately. It remains active until a platform superuser revokes it; regulated approvals and personal authorizations remain role-governed.</small>
              </span>
            </label>
          ) : !creatingPlatformSuperuser ? (
            <InlineAlert tone="info" title="Delegated tenant administration" className="form-row--span-2"><span>Temporary or task-specific administration is assigned through Administrator governance and requires the prescribed independent approvals.</span></InlineAlert>
          ) : null}

          <div className="form-row">
            <label htmlFor="positionTitle">Employment / display title</label>
            <input
              id="positionTitle"
              name="positionTitle"
              type="text"
              value={form.positionTitle}
              onChange={handleChange}
              placeholder="Descriptive title from Workforce"
              disabled={submitting}
            />
            <p className="form-hint">Changing this text never changes portal authority.</p>
          </div>

          <div className="form-row form-row--span-2">
            <label htmlFor="phone">Phone</label>
            <input
              id="phone"
              name="phone"
              type="tel"
              value={form.phone}
              onChange={handleChange}
              placeholder="+254..."
              disabled={submitting}
            />
          </div>

          <div className="form-row">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              name="password"
              type={showPassword ? "text" : "password"}
              value={form.password}
              onChange={handleChange}
              required
              disabled={submitting}
            />
          </div>

          <div className="form-row">
            <label htmlFor="confirmPassword">Confirm Password</label>
            <input
              id="confirmPassword"
              name="confirmPassword"
              type={showPassword ? "text" : "password"}
              value={form.confirmPassword}
              onChange={handleChange}
              required
              disabled={submitting}
            />
          </div>

          <div className="form-row form-row--span-2">
            <div className="form-actions form-actions--inline">
              <Button
                type="button"
                size="sm"
                variant="secondary"
                onClick={generateSecurePassword}
                disabled={submitting}
              >
                Generate secure password
              </Button>
              <Button
                type="button"
                size="sm"
                variant="secondary"
                onClick={() => setShowPassword((prev) => !prev)}
                disabled={submitting}
              >
                {showPassword ? "Hide password" : "Show password"}
              </Button>
              <Button
                type="button"
                size="sm"
                variant="secondary"
                onClick={copyPassword}
                disabled={submitting || !form.password}
              >
                Copy password
              </Button>
            </div>
            <p className="form-hint">
              Passwords must be at least 12 characters and include upper/lower
              case letters and a number (symbols optional). The user will be
              asked to change this on first login.
            </p>
          </div>

          <div className="form-actions form-row--span-2">
            <Button
              type="button"
              variant="secondary"
              onClick={() => navigate(backTarget)}
              disabled={submitting}
            >
              Cancel
            </Button>

            <Button type="submit" disabled={submitting}>
              {submitting ? "Creating..." : "Create User"}
            </Button>
          </div>
        </form>
        </Panel>
      </div>
    </DepartmentLayout>
  );
};

export default AdminUserNewPage;
