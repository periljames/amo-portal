// src/services/amoAssets.ts

import { getApiBaseUrl } from "./config";
import { authHeaders, getToken, handleAuthFailure } from "./auth";
import { downloadWithXhr, type DownloadedFile } from "../utils/downloads";

const AMO_LOGO_CACHE_TTL_MS = 5 * 60 * 1000;
const AMO_LOGO_FETCH_TIMEOUT_MS = 8000;

type LogoCacheEntry = {
  blob: Blob | null;
  expiresAt: number;
};

const amoLogoCache = new Map<string, LogoCacheEntry>();
const amoLogoInflight = new Map<string, Promise<Blob | null>>();
const amoLogoRequestGeneration = new Map<string, number>();

export type AmoAssetRead = {
  amo_id: string;
  crs_logo_filename?: string | null;
  crs_logo_content_type?: string | null;
  crs_logo_uploaded_at?: string | null;
  crs_template_filename?: string | null;
  crs_template_content_type?: string | null;
  crs_template_uploaded_at?: string | null;
};

export type TransferProgress = {
  loadedBytes: number;
  totalBytes?: number;
  percent?: number;
  megaBytesPerSecond: number;
  megaBitsPerSecond: number;
};

function buildAuthHeader(): Record<string, string> {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function withAmoId(path: string, amoId?: string | null): string {
  if (!amoId) return path;
  const sp = new URLSearchParams({ amo_id: amoId });
  return `${path}?${sp.toString()}`;
}

function isLocalDevSurface(): boolean {
  if (typeof window === "undefined") return false;
  const { hostname, port } = window.location;
  return ["localhost", "127.0.0.1"].includes(hostname) && ["5173", "4173"].includes(port);
}

function logoRequestUrls(amoId?: string | null): string[] {
  const path = withAmoId("/accounts/amo-assets/logo", amoId);
  const proxied = `${getApiBaseUrl()}${path}`;
  const direct = `http://127.0.0.1:8080${path}`;
  if (isLocalDevSurface()) return direct === proxied ? [proxied] : [direct, proxied];
  return [proxied];
}

function buildSpeed(
  loadedBytes: number,
  totalBytes: number | undefined,
  startedAt: number
): TransferProgress {
  const elapsedSeconds = Math.max((performance.now() - startedAt) / 1000, 0.001);
  const megaBytesPerSecond = loadedBytes / (1024 * 1024) / elapsedSeconds;
  const megaBitsPerSecond = megaBytesPerSecond * 8;
  const percent = totalBytes ? Math.min((loadedBytes / totalBytes) * 100, 100) : undefined;
  return {
    loadedBytes,
    totalBytes,
    percent,
    megaBytesPerSecond,
    megaBitsPerSecond,
  };
}

export async function getAmoAssets(amoId?: string | null): Promise<AmoAssetRead> {
  const res = await fetch(
    withAmoId(`${getApiBaseUrl()}/accounts/amo-assets/me`, amoId),
    {
      method: "GET",
      headers: authHeaders(),
    }
  );

  if (res.status === 401) {
    handleAuthFailure("expired");
    throw new Error("Session expired. Please sign in again.");
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `Request failed (${res.status})`);
  }

  return (await res.json()) as AmoAssetRead;
}

function uploadAmoAsset(
  file: File,
  kind: "logo" | "template",
  amoId?: string | null,
  onProgress?: (progress: TransferProgress) => void
): Promise<AmoAssetRead> {
  return new Promise((resolve, reject) => {
    const form = new FormData();
    form.append("file", file);

    const xhr = new XMLHttpRequest();
    const startedAt = performance.now();
    xhr.open("POST", withAmoId(`${getApiBaseUrl()}/accounts/amo-assets/${kind}`, amoId));
    const headers = buildAuthHeader();
    Object.entries(headers).forEach(([key, value]) => {
      xhr.setRequestHeader(key, value);
    });
    xhr.responseType = "json";

    xhr.upload.addEventListener("progress", (event) => {
      if (!onProgress) return;
      const total = event.lengthComputable ? event.total : undefined;
      onProgress(buildSpeed(event.loaded, total, startedAt));
    });

    xhr.addEventListener("load", () => {
      if (xhr.status === 401) {
        handleAuthFailure("expired");
        reject(new Error("Session expired. Please sign in again."));
        return;
      }
      if (xhr.status < 200 || xhr.status >= 300) {
        const message = xhr.responseText || `Request failed (${xhr.status})`;
        reject(new Error(message));
        return;
      }

      if (xhr.response && typeof xhr.response === "object") {
        resolve(xhr.response as AmoAssetRead);
        return;
      }

      try {
        resolve(JSON.parse(xhr.responseText) as AmoAssetRead);
      } catch {
        reject(new Error("Unexpected response from server."));
      }
    });

    xhr.addEventListener("error", () => {
      reject(new Error("Network error while uploading asset."));
    });

    xhr.send(form);
  });
}

export function uploadAmoLogo(
  file: File,
  amoId?: string | null,
  onProgress?: (progress: TransferProgress) => void
): Promise<AmoAssetRead> {
  invalidateAmoLogoBlobCache(amoId);
  return uploadAmoAsset(file, "logo", amoId, onProgress);
}

export function uploadAmoTemplate(
  file: File,
  amoId?: string | null,
  onProgress?: (progress: TransferProgress) => void
): Promise<AmoAssetRead> {
  return uploadAmoAsset(file, "template", amoId, onProgress);
}

export async function downloadAmoAsset(
  kind: "logo" | "template",
  amoId?: string | null,
  onProgress?: (progress: TransferProgress) => void
): Promise<DownloadedFile> {
  const startedAt = performance.now();
  return downloadWithXhr({
    url: withAmoId(`${getApiBaseUrl()}/accounts/amo-assets/${kind}`, amoId),
    headers: buildAuthHeader(),
    fallbackFilename: kind === "logo" ? "amo-logo" : "crs-template.pdf",
    onProgress: onProgress ? (loaded, total) => onProgress(buildSpeed(loaded, total, startedAt)) : undefined,
    retries: 2,
  });
}

function getAmoLogoCacheKey(amoId?: string | null): string {
  return amoId?.trim() || "self";
}

export function invalidateAmoLogoBlobCache(amoId?: string | null) {
  const key = getAmoLogoCacheKey(amoId);
  amoLogoRequestGeneration.set(key, (amoLogoRequestGeneration.get(key) ?? 0) + 1);
  amoLogoCache.delete(key);
  amoLogoInflight.delete(key);
}

export async function fetchAmoLogoBlob(amoId?: string | null): Promise<Blob | null> {
  const key = getAmoLogoCacheKey(amoId);
  const now = Date.now();
  const cached = amoLogoCache.get(key);
  if (cached && cached.expiresAt > now) {
    return cached.blob;
  }

  const existingInflight = amoLogoInflight.get(key);
  if (existingInflight) {
    return existingInflight;
  }

  const requestGeneration = amoLogoRequestGeneration.get(key) ?? 0;

  const request = (async () => {
    const controller = new AbortController();
    const timeoutId = window.setTimeout(() => controller.abort(), AMO_LOGO_FETCH_TIMEOUT_MS);

    try {
      let lastError: unknown = null;
      for (const url of logoRequestUrls(amoId)) {
        try {
          const res = await fetch(url, {
            method: "GET",
            headers: authHeaders(),
            signal: controller.signal,
            cache: "no-store",
          });

          if (res.status === 401) {
            handleAuthFailure("expired");
            throw new Error("Session expired. Please sign in again.");
          }

          if (res.status === 404 || res.status === 204) {
            return null;
          }

          if (!res.ok) {
            const text = await res.text().catch(() => "");
            throw new Error(text || `Request failed (${res.status})`);
          }

          const blob = await res.blob();
          if (!blob || blob.size === 0) return null;
          return blob;
        } catch (error) {
          lastError = error;
          if (controller.signal.aborted) throw error;
        }
      }
      throw lastError instanceof Error ? lastError : new Error("Unable to load AMO logo.");
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") {
        throw new Error("AMO logo request timed out. Retrying without cache.");
      }
      throw error;
    } finally {
      window.clearTimeout(timeoutId);
    }
  })()
    .then((blob) => {
      if ((amoLogoRequestGeneration.get(key) ?? 0) === requestGeneration) {
        amoLogoCache.set(key, {
          blob,
          expiresAt: Date.now() + AMO_LOGO_CACHE_TTL_MS,
        });
      }
      return blob;
    })
    .finally(() => {
      amoLogoInflight.delete(key);
    });

  amoLogoInflight.set(key, request);
  return request;
}
