// src/services/adminUsers.ts
// - Handles admin-only user management.
// - Talks to backend: backend/amodb/apps/accounts/router_admin.py
//   * POST /accounts/admin/users  -> createAdminUser
//   * GET  /accounts/admin/users  -> listAdminUsers (supports amo_id, skip, limit, search)
//   * GET  /accounts/admin/amos   -> listAdminAmos (SUPERUSER only)
// - Uses authHeaders() from auth.ts so only logged-in SUPERUSER/AMO_ADMIN
//   can call these endpoints.

import { apiPost, apiGet, apiPostForm } from "./crs";
import { apiDelete, apiPut } from "./crs";
import { authHeaders, getCachedUser } from "./auth";
import { getApiBaseUrl } from "./config";
import type { AccountRole, RegulatoryAuthority } from "./auth";
import { BRANDING_EVENT } from "./branding";

// Re-export these so pages can `import type { AccountRole } from "../services/adminUsers";`
export type { AccountRole, RegulatoryAuthority };

export interface AdminAccountRoleCatalogueItem {
  key: AccountRole;
  label: string;
  category: "PLATFORM" | "ADMINISTRATION" | "KCAR_2025_MANAGEMENT" | "OPERATIONAL" | "SUPPORT" | "GENERAL";
  description: string;
  aliases: string[];
  regulated: boolean;
  workforce_role_key: string | null;
  can_manage_accounts: boolean;
  can_have_supervisor: boolean;
  permission_summary: string[];
}

export interface AdminAccountRoleCatalogue {
  source: string;
  canonical_storage: boolean;
  roles: AdminAccountRoleCatalogueItem[];
}

export interface AdminUserCreatePayload {
  // BACKEND: schemas.UserCreate
  amo_id?: string; // optional override (superuser only), otherwise resolved from context

  staff_code: string;
  email: string;
  first_name: string;
  last_name: string;
  full_name?: string;
  role: AccountRole;
  position_title?: string;
  phone?: string;
  secondary_phone?: string;
  department_id?: string | null;

  regulatory_authority?: RegulatoryAuthority | null;
  licence_number?: string | null;
  licence_state_or_country?: string | null;
  licence_expires_on?: string | null; // ISO date string (YYYY-MM-DD)

  password: string;
}

/**
 * Shape of the user returned by /accounts/admin/users.
 * Kept in sync with UserRead from the backend.
 */
export interface AdminUserRead {
  id: string;
  amo_id: string;
  department_id: string | null;
  staff_code: string;

  email: string;
  first_name: string;
  last_name: string;
  full_name: string;
  role: AccountRole;
  position_title: string | null;
  phone?: string | null;
  secondary_phone?: string | null;

  regulatory_authority?: RegulatoryAuthority | null;
  licence_number?: string | null;
  licence_state_or_country?: string | null;
  licence_expires_on?: string | null;

  is_active?: boolean;
  is_superuser?: boolean;
  is_amo_admin?: boolean;
  must_change_password?: boolean;
  token_revoked_at?: string | null;
  last_login_at?: string | null;
  last_login_ip?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface AdminUserSummaryRead {
  id: string;
  full_name: string;
  email: string;
  staff_code: string;
  role: AccountRole;
  position_title: string | null;
  is_active: boolean;
}

export interface AdminUserUpdatePayload {
  first_name?: string | null;
  last_name?: string | null;
  full_name?: string | null;
  role?: AccountRole;
  position_title?: string | null;
  phone?: string | null;
  secondary_phone?: string | null;
  department_id?: string | null;
  regulatory_authority?: RegulatoryAuthority | null;
  licence_number?: string | null;
  licence_state_or_country?: string | null;
  licence_expires_on?: string | null;
  is_active?: boolean;
  is_amo_admin?: boolean;
}

/**
 * AMO type returned by GET /accounts/admin/amos (SUPERUSER only).
 * (Matches backend AMORead shape.)
 */
export interface AdminAmoRead {
  id: string;
  amo_code: string;
  name: string;
  login_slug: string;
  icao_code?: string | null;
  country?: string | null;
  contact_email?: string | null;
  contact_phone?: string | null;
  time_zone?: string | null;
  is_demo?: boolean;
  is_active: boolean;
  created_at?: string;
  updated_at?: string;
}


export interface UserCommandResult {
  user_id: string;
  command: string;
  status: string;
  effective_at: string;
  task_id?: string | null;
}

export interface UserNotifyPayload {
  subject: string;
  message: string;
}

export interface UserScheduleReviewPayload {
  title: string;
  description?: string;
  due_at?: string;
  priority?: number;
}

export interface AdminDepartmentRead {
  id: string;
  amo_id: string;
  code: string;
  name: string;
  default_route?: string | null;
  sort_order?: number | null;
  is_active: boolean;
}

export interface AdminDepartmentCreatePayload {
  amo_id: string;
  code: string;
  name: string;
  default_route?: string | null;
  sort_order?: number | null;
}

export interface AdminDepartmentUpdatePayload {
  name?: string | null;
  default_route?: string | null;
  sort_order?: number | null;
  is_active?: boolean | null;
}

export interface StaffCodeSuggestions {
  suggestions: string[];
}

export type AdminAssetKind = "CRS_LOGO" | "CRS_TEMPLATE" | "OTHER";

export interface AdminAssetRead {
  id: string;
  amo_id: string;
  kind: AdminAssetKind;
  name?: string | null;
  description?: string | null;
  original_filename?: string | null;
  storage_path?: string | null;
  content_type?: string | null;
  size_bytes?: number | null;
  sha256?: string | null;
  is_active: boolean;
  uploaded_by_user_id?: string | null;
  created_at: string;
  updated_at: string;
}

export interface AdminAmoCreatePayload {
  amo_code: string;
  name: string;
  login_slug: string;
  icao_code?: string | null;
  country?: string | null;
  contact_email?: string | null;
  contact_phone?: string | null;
  time_zone?: string | null;
  is_demo?: boolean;
}

export interface AdminAmoUpdatePayload {
  name?: string | null;
  icao_code?: string | null;
  country?: string | null;
  contact_email?: string | null;
  contact_phone?: string | null;
  time_zone?: string | null;
  is_demo?: boolean;
  is_active?: boolean;
}

export interface TrialExtendPayload {
  extend_days: number;
}

export type DataMode = "DEMO" | "REAL";

export interface AdminContext {
  user_id: string;
  active_amo_id: string | null;
  data_mode: DataMode;
  last_real_amo_id: string | null;
  updated_at: string;
}

export interface PersonnelImportRowIssue {
  row_number: number;
  person_id?: string | null;
  reason: string;
}

export interface PersonnelImportSummary {
  dry_run: boolean;
  rows_processed: number;
  created_personnel: number;
  updated_personnel: number;
  created_accounts: number;
  updated_accounts: number;
  skipped_accounts: number;
  rejected_rows: number;
  skipped_rows: number;
  issues: PersonnelImportRowIssue[];
  conflicts: PersonnelImportConflict[];
}

export interface PersonnelImportConflict {
  row_number: number;
  person_id?: string | null;
  existing_email?: string | null;
  imported_email?: string | null;
  reason: string;
  options: string[];
}

/**
 * Optional support: store the current "admin context" AMO in localStorage.
 * Useful for SUPERUSER support workflows (switch AMO without re-login).
 *
 * Note: stores amo_id, not amoCode/login_slug.
 */
export const LS_ACTIVE_AMO_ID = "amodb_active_amo_id";

// Optional backward/alternate key support (in case you already used another one elsewhere)
const ACTIVE_AMO_ID_KEY_ALT = "amodb_admin_active_amo_id";

export function setActiveAmoId(amoId: string) {
  const v = (amoId || "").trim();
  if (!v) return;
  localStorage.setItem(LS_ACTIVE_AMO_ID, v);
  // keep alt key in sync if it exists in your app already
  localStorage.setItem(ACTIVE_AMO_ID_KEY_ALT, v);
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event(BRANDING_EVENT));
  }
}

export function getActiveAmoId(): string | null {
  const primary = localStorage.getItem(LS_ACTIVE_AMO_ID);
  if (primary && primary.trim()) return primary.trim();

  const alt = localStorage.getItem(ACTIVE_AMO_ID_KEY_ALT);
  return alt && alt.trim() ? alt.trim() : null;
}

export function clearActiveAmoId() {
  localStorage.removeItem(LS_ACTIVE_AMO_ID);
  localStorage.removeItem(ACTIVE_AMO_ID_KEY_ALT);
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event(BRANDING_EVENT));
  }
}

export async function getAdminContext(): Promise<AdminContext> {
  return apiGet<AdminContext>("/accounts/admin/context", {
    headers: authHeaders(),
  });
}

export async function setAdminContext(payload: {
  active_amo_id?: string | null;
  data_mode?: DataMode;
}): Promise<AdminContext> {
  return apiPost<AdminContext>(
    "/accounts/admin/context",
    JSON.stringify(payload),
    { headers: authHeaders() }
  );
}

export async function importPersonnelFile(params: {
  file: File;
  dryRun?: boolean;
  amoId?: string;
  sheetName?: string;
  decisions?: Record<number, string>;
}): Promise<PersonnelImportSummary> {
  const form = new FormData();
  form.append("file", params.file);
  const search = new URLSearchParams();
  search.set("dry_run", params.dryRun === false ? "false" : "true");
  if (params.amoId) search.set("amo_id", params.amoId);
  if (params.sheetName) search.set("sheet_name", params.sheetName);
  if (params.decisions && Object.keys(params.decisions).length) {
    search.set("decisions_json", JSON.stringify(params.decisions));
  }

  return apiPostForm<PersonnelImportSummary>(
    `/accounts/admin/personnel/import?${search.toString()}`,
    form,
    { headers: authHeaders() }
  );
}

type CreateOptions = {
  /**
   * Target AMO id override (SUPERUSER only).
   * If omitted, falls back to:
   *  - payload.amo_id
   *  - active AMO id from localStorage
   *  - current logged-in user's amo_id
   */
  amoId?: string;
};

function resolveTargetAmoId(
  payload: AdminUserCreatePayload,
  opts?: CreateOptions
): string {
  const current = getCachedUser();

  if (!current) {
    throw new Error("You are not logged in. Please sign in again.");
  }

  const currentAmoId = (current as any).amo_id as string | undefined;
  const isSuperuser = !!(current as any).is_superuser;

  const candidate =
    (payload.amo_id || "").trim() ||
    (opts?.amoId || "").trim() ||
    (getActiveAmoId() || "").trim() ||
    (currentAmoId || "").trim();

  if (!candidate) {
    throw new Error(
      "Could not determine the target AMO. Please sign out and sign in again."
    );
  }

  // Non-superusers must never target another AMO.
  if (!isSuperuser) {
    if (!currentAmoId) {
      throw new Error(
        "Could not determine your AMO. Please sign out and sign in again."
      );
    }
    if (candidate !== currentAmoId) {
      throw new Error("You do not have permission to create users in this AMO.");
    }
  }

  return candidate;
}

/**
 * Create a user via the admin API.
 *
 * Notes:
 * - Backend expects amo_id in schemas.UserCreate.
 * - For normal AMO admins, server enforces amo_id == current user's AMO.
 * - For SUPERUSER, we allow explicit targeting by passing amo_id.
 */
export async function createAdminUser(
  payload: AdminUserCreatePayload,
  opts?: CreateOptions
): Promise<AdminUserRead> {
  const targetAmoId = resolveTargetAmoId(payload, opts);

  const fullName =
    (payload.full_name || "").trim() ||
    `${payload.first_name} ${payload.last_name}`.trim();

  const body: AdminUserCreatePayload = {
    ...payload,
    amo_id: targetAmoId, // force resolved value into the request
    full_name: fullName,
  };

  return apiPost<AdminUserRead>("/accounts/admin/users", JSON.stringify(body), {
    headers: authHeaders(),
  });
}

export async function getAdminAccountRoleCatalogue(): Promise<AdminAccountRoleCatalogue> {
  return apiGet<AdminAccountRoleCatalogue>("/accounts/admin/role-catalogue", {
    headers: authHeaders(),
  });
}

type ListParams = {
  /**
   * For SUPERUSER: you can request users for a specific AMO.
   * If omitted (and SUPERUSER), we fall back to active AMO id or user's own AMO.
   * For non-superusers, this is ignored client-side (not sent).
   */
  amo_id?: string;

  skip?: number;
  limit?: number;
  search?: string;
};

type ListOptions = {
  signal?: AbortSignal;
};

function resolveListAmoId(params?: ListParams): string | undefined {
  const current = getCachedUser();
  if (!current) return undefined;

  const currentAmoId = (current as any).amo_id as string | undefined;
  const isSuperuser = !!(current as any).is_superuser;

  if (!isSuperuser) {
    // Never send amo_id for non-superusers (prevents accidental cross-AMO calls)
    return undefined;
  }

  const candidate =
    (params?.amo_id || "").trim() ||
    (getActiveAmoId() || "").trim() ||
    (currentAmoId || "").trim();

  return candidate || undefined;
}

/**
 * List users in the current AMO (or selected AMO for SUPERUSER).
 * This hits GET /accounts/admin/users and supports:
 * - amo_id (superuser only)
 * - skip / limit / search
 */
export async function listAdminUsers(
  params: ListParams = {},
  options: ListOptions = {}
): Promise<AdminUserRead[]> {
  const sp = new URLSearchParams();

  const amoId = resolveListAmoId(params);
  if (amoId) sp.set("amo_id", amoId);

  if (typeof params.skip === "number") sp.set("skip", String(params.skip));
  if (typeof params.limit === "number") sp.set("limit", String(params.limit));
  if (params.search && params.search.trim()) {
    sp.set("search", params.search.trim());
  }

  const qs = sp.toString();
  const path = qs ? `/accounts/admin/users?${qs}` : "/accounts/admin/users";

  return apiGet<AdminUserRead[]>(path, {
    headers: authHeaders(),
    signal: options.signal,
  });
}

export async function listAdminUserSummaries(
  params: ListParams = {},
  options: ListOptions = {},
): Promise<AdminUserSummaryRead[]> {
  const users = await listAdminUsers(params, options);
  return users.map((user) => ({
    id: user.id,
    full_name: user.full_name,
    email: user.email,
    staff_code: user.staff_code,
    role: user.role,
    position_title: user.position_title,
    is_active: !!user.is_active,
  }));
}

/**
 * SUPERUSER ONLY: list all AMOs for the AMO picker.
 * GET /accounts/admin/amos
 */
export async function listAdminAmos(): Promise<AdminAmoRead[]> {
  return apiGet<AdminAmoRead[]>("/accounts/admin/amos", {
    headers: authHeaders(),
  });
}

export async function listAdminDepartments(amoId?: string): Promise<AdminDepartmentRead[]> {
  const sp = new URLSearchParams();
  if (amoId && amoId.trim()) {
    sp.set("amo_id", amoId.trim());
  }
  const qs = sp.toString();
  const path = qs ? `/accounts/admin/departments?${qs}` : "/accounts/admin/departments";
  return apiGet<AdminDepartmentRead[]>(path, {
    headers: authHeaders(),
  });
}

export async function createAdminDepartment(
  payload: AdminDepartmentCreatePayload
): Promise<AdminDepartmentRead> {
  return apiPost<AdminDepartmentRead>(
    "/accounts/admin/departments",
    JSON.stringify(payload),
    { headers: authHeaders() }
  );
}

export async function updateAdminDepartment(
  departmentId: string,
  payload: AdminDepartmentUpdatePayload
): Promise<AdminDepartmentRead> {
  return apiPut<AdminDepartmentRead>(
    `/accounts/admin/departments/${encodeURIComponent(departmentId)}`,
    JSON.stringify(payload),
    { headers: authHeaders() }
  );
}

export async function listStaffCodeSuggestions(params: {
  first_name: string;
  last_name: string;
  amo_id?: string;
}): Promise<StaffCodeSuggestions> {
  const sp = new URLSearchParams();
  sp.set("first_name", params.first_name);
  sp.set("last_name", params.last_name);
  if (params.amo_id) sp.set("amo_id", params.amo_id);
  const path = `/accounts/admin/staff-code-suggestions?${sp.toString()}`;
  return apiGet<StaffCodeSuggestions>(path, { headers: authHeaders() });
}

type AssetListParams = {
  amo_id?: string;
  kind?: AdminAssetKind;
  only_active?: boolean;
};

export async function listAdminAssets(
  params: AssetListParams = {}
): Promise<AdminAssetRead[]> {
  const sp = new URLSearchParams();
  if (params.amo_id && params.amo_id.trim()) {
    sp.set("amo_id", params.amo_id.trim());
  }
  if (params.kind) {
    sp.set("kind", params.kind);
  }
  if (typeof params.only_active === "boolean") {
    sp.set("only_active", String(params.only_active));
  }
  const qs = sp.toString();
  const path = qs ? `/accounts/admin/assets?${qs}` : "/accounts/admin/assets";
  return apiGet<AdminAssetRead[]>(path, {
    headers: authHeaders(),
  });
}

/**
 * SUPERUSER ONLY: create an AMO.
 * POST /accounts/admin/amos
 */
export async function createAdminAmo(
  payload: AdminAmoCreatePayload
): Promise<AdminAmoRead> {
  return apiPost<AdminAmoRead>("/accounts/admin/amos", JSON.stringify(payload), {
    headers: authHeaders(),
  });
}

export async function updateAdminAmo(
  amoId: string,
  payload: AdminAmoUpdatePayload
): Promise<AdminAmoRead> {
  return apiPut<AdminAmoRead>(
    `/accounts/admin/amos/${encodeURIComponent(amoId)}`,
    JSON.stringify(payload),
    { headers: authHeaders() }
  );
}

export async function deactivateAdminAmo(amoId: string): Promise<void> {
  await apiDelete<void>(`/accounts/admin/amos/${encodeURIComponent(amoId)}`, undefined, {
    headers: authHeaders(),
  });
}

export async function extendAmoTrial(
  amoId: string,
  payload: TrialExtendPayload
): Promise<unknown> {
  return apiPost<unknown>(
    `/accounts/admin/amos/${encodeURIComponent(amoId)}/trial-extend`,
    JSON.stringify(payload),
    { headers: authHeaders() }
  );
}

export async function updateAdminUser(
  userId: string,
  payload: AdminUserUpdatePayload
): Promise<AdminUserRead> {
  return apiPut<AdminUserRead>(
    `/accounts/admin/users/${encodeURIComponent(userId)}`,
    JSON.stringify(payload),
    { headers: authHeaders() }
  );
}


const ADMIN_USER_CACHE_PREFIX = "amoportal:admin-users:";
const adminUserMemoryCache = new Map<string, { expiresAt: number; value: unknown }>();
const adminUserInFlight = new Map<string, Promise<unknown>>();

function cloneAdminCachedValue<T>(value: T): T {
  try {
    return typeof structuredClone === "function" ? structuredClone(value) : JSON.parse(JSON.stringify(value));
  } catch {
    return value;
  }
}

function readAdminUserCache<T>(key: string): T | null {
  const now = Date.now();
  const memory = adminUserMemoryCache.get(key);
  if (memory && memory.expiresAt > now) return cloneAdminCachedValue(memory.value as T);
  if (memory) adminUserMemoryCache.delete(key);
  try {
    const raw = window.sessionStorage.getItem(`${ADMIN_USER_CACHE_PREFIX}${key}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { expiresAt?: number; value?: T };
    if (!parsed || typeof parsed.expiresAt !== "number" || parsed.expiresAt <= now) {
      window.sessionStorage.removeItem(`${ADMIN_USER_CACHE_PREFIX}${key}`);
      return null;
    }
    adminUserMemoryCache.set(key, { expiresAt: parsed.expiresAt, value: parsed.value });
    return cloneAdminCachedValue(parsed.value as T);
  } catch {
    return null;
  }
}

function writeAdminUserCache<T>(key: string, ttlMs: number, value: T): T {
  const expiresAt = Date.now() + ttlMs;
  adminUserMemoryCache.set(key, { expiresAt, value: cloneAdminCachedValue(value) });
  try {
    window.sessionStorage.setItem(`${ADMIN_USER_CACHE_PREFIX}${key}`, JSON.stringify({ expiresAt, value }));
  } catch {
    // ignore storage failures
  }
  return cloneAdminCachedValue(value);
}

async function cachedAdminUserGet<T>(key: string, ttlMs: number, fetcher: () => Promise<T>, force = false): Promise<T> {
  if (!force) {
    const cached = readAdminUserCache<T>(key);
    if (cached != null) return cached;
  }
  const inFlight = adminUserInFlight.get(key) as Promise<T> | undefined;
  if (inFlight) return inFlight.then((value) => cloneAdminCachedValue(value));
  const promise = fetcher()
    .then((value) => writeAdminUserCache(key, ttlMs, value))
    .finally(() => {
      adminUserInFlight.delete(key);
    });
  adminUserInFlight.set(key, promise as Promise<unknown>);
  return promise.then((value) => cloneAdminCachedValue(value));
}

export function invalidateAdminUserCache(match?: string): void {
  for (const key of [...adminUserMemoryCache.keys()]) {
    if (!match || key.includes(match)) adminUserMemoryCache.delete(key);
  }
  try {
    for (let index = window.sessionStorage.length - 1; index >= 0; index -= 1) {
      const storageKey = window.sessionStorage.key(index);
      if (!storageKey || !storageKey.startsWith(ADMIN_USER_CACHE_PREFIX)) continue;
      if (!match || storageKey.includes(match)) window.sessionStorage.removeItem(storageKey);
    }
  } catch {
    // ignore storage failures
  }
}

export async function getAdminUser(userId: string): Promise<AdminUserRead> {
  return cachedAdminUserGet(`user:${userId}`, 3 * 60_000, () => apiGet<AdminUserRead>(`/accounts/admin/users/${encodeURIComponent(userId)}`, {
    headers: authHeaders(),
  }));
}


export async function deactivateAdminUser(userId: string): Promise<void> {
  await apiDelete<void>(`/accounts/admin/users/${encodeURIComponent(userId)}`, undefined, {
    headers: authHeaders(),
  });
}


export async function disableAdminUser(userId: string): Promise<UserCommandResult> {
  return apiPost<UserCommandResult>(
    `/accounts/admin/users/${encodeURIComponent(userId)}/commands/disable`,
    JSON.stringify({}),
    { headers: authHeaders() }
  );
}

export async function enableAdminUser(userId: string): Promise<UserCommandResult> {
  return apiPost<UserCommandResult>(
    `/accounts/admin/users/${encodeURIComponent(userId)}/commands/enable`,
    JSON.stringify({}),
    { headers: authHeaders() }
  );
}

export async function revokeAdminUserAccess(userId: string): Promise<UserCommandResult> {
  return apiPost<UserCommandResult>(
    `/accounts/admin/users/${encodeURIComponent(userId)}/commands/revoke-access`,
    JSON.stringify({}),
    { headers: authHeaders() }
  );
}

export async function forceAdminUserPasswordReset(userId: string): Promise<UserCommandResult> {
  return apiPost<UserCommandResult>(
    `/accounts/admin/users/${encodeURIComponent(userId)}/commands/force-password-reset`,
    JSON.stringify({}),
    { headers: authHeaders() }
  );
}

export async function notifyAdminUser(
  userId: string,
  payload: UserNotifyPayload
): Promise<UserCommandResult> {
  return apiPost<UserCommandResult>(
    `/accounts/admin/users/${encodeURIComponent(userId)}/commands/notify`,
    JSON.stringify(payload),
    { headers: authHeaders() }
  );
}

export async function scheduleAdminUserReview(
  userId: string,
  payload: UserScheduleReviewPayload
): Promise<UserCommandResult> {
  return apiPost<UserCommandResult>(
    `/accounts/admin/users/${encodeURIComponent(userId)}/commands/schedule-review`,
    JSON.stringify(payload),
    { headers: authHeaders() }
  );
}

export interface AdminUserPresence {
  state: string;
  is_online: boolean;
  last_seen_at: string | null;
  source: string | null;
}

export interface AdminUserPresenceDisplay {
  status_label: string;
  last_seen_label: string;
  last_seen_at: string | null;
  last_seen_at_display: string | null;
}

export interface AdminUserDirectoryItem {
  id: string;
  amo_id: string;
  department_id: string | null;
  department_name: string | null;
  staff_code: string;
  email: string;
  first_name: string;
  last_name: string;
  full_name: string;
  role: AccountRole;
  position_title: string | null;
  is_active: boolean;
  is_superuser: boolean;
  is_amo_admin: boolean;
  display_title: string;
  availability_status?: string | null;
  last_login_at: string | null;
  created_at: string;
  updated_at: string;
  presence: AdminUserPresence;
  presence_display: AdminUserPresenceDisplay;
}

export interface AdminUserDirectoryMetrics {
  total_users: number;
  active_users: number;
  inactive_users: number;
  online_users: number;
  away_users: number;
  on_leave_users: number;
  recently_active_users: number;
  departmentless_users: number;
  managers: number;
}

export interface AdminUserDirectoryResponse {
  items: AdminUserDirectoryItem[];
  metrics: AdminUserDirectoryMetrics;
}

export interface AdminUserWorkspaceMetric {
  key: string;
  label: string;
  value: number;
}

export interface AdminUserTaskSummary {
  id: string;
  title: string;
  status: string;
  priority: number;
  due_at: string | null;
  entity_type: string | null;
  entity_id: string | null;
  updated_at: string;
}

export interface AdminUserPermissionSummary {
  id: string;
  code: string;
  label: string;
  maintenance_scope: string | null;
  scope_text: string | null;
  effective_from: string;
  expires_at: string | null;
  is_currently_valid: boolean;
}

export interface AdminUserActivitySummary {
  id: string;
  occurred_at: string;
  action: string;
  entity_type: string;
  entity_id: string;
}

export interface AdminUserLoginRecord {
  last_login_at: string | null;
  last_login_ip: string | null;
  last_login_user_agent: string | null;
  must_change_password: boolean;
  password_changed_at: string | null;
  token_revoked_at: string | null;
}

export interface AdminUserGroupChip {
  kind: string;
  label: string;
  value: string | null;
}

export interface AdminPersonnelProfileSummary {
  id: string;
  person_id: string;
  employment_status: string | null;
  status: string | null;
  hire_date: string | null;
  department: string | null;
  position_title: string | null;
}

export interface AdminUserAvailabilitySummary {
  id: string;
  status: string;
  effective_from: string;
  effective_to: string | null;
  note: string | null;
  updated_at: string;
}

export interface AdminUserGroupRead {
  id: string;
  amo_id: string;
  owner_user_id: string | null;
  code: string;
  name: string;
  description: string | null;
  group_type: string;
  is_system_managed: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  member_count: number;
}

export interface AdminUserGroupCreatePayload {
  amo_id: string;
  code: string;
  name: string;
  description?: string | null;
  group_type?: "POST_HOLDERS" | "DEPARTMENT" | "CUSTOM" | "PERSONAL";
  is_active?: boolean;
}

export interface AdminUserGroupUpdatePayload {
  code?: string | null;
  name?: string | null;
  description?: string | null;
  is_active?: boolean | null;
}

export interface AdminUserGroupMemberRead {
  id: string;
  group_id: string;
  user_id: string;
  full_name: string;
  email: string;
  staff_code: string;
  member_role: string;
  added_at: string;
}

export interface AdminUserGroupMemberCreatePayload {
  user_id: string;
  member_role?: string;
}

export interface AdminAuthorisationTypeRead {
  id: string;
  amo_id: string;
  code: string;
  name: string;
  description: string | null;
  maintenance_scope: string | null;
  regulation_reference: string | null;
  can_issue_crs: boolean;
  requires_dual_sign: boolean;
  requires_valid_licence: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface AdminAuthorisationTypeCreatePayload {
  amo_id: string;
  code: string;
  name: string;
  description?: string | null;
  maintenance_scope?: string | null;
  regulation_reference?: string | null;
  can_issue_crs?: boolean;
  requires_dual_sign?: boolean;
  requires_valid_licence?: boolean;
}

export interface AdminAuthorisationTypeUpdatePayload {
  code?: string | null;
  name?: string | null;
  description?: string | null;
  maintenance_scope?: string | null;
  regulation_reference?: string | null;
  can_issue_crs?: boolean | null;
  requires_dual_sign?: boolean | null;
  requires_valid_licence?: boolean | null;
  is_active?: boolean | null;
}

export interface AdminUserAuthorisationRead {
  id: string;
  user_id: string;
  authorisation_type_id: string;
  scope_text: string | null;
  effective_from: string;
  expires_at: string | null;
  revoked_at: string | null;
  revoked_reason: string | null;
  granted_by_user_id: string | null;
  created_at: string;
  updated_at: string;
  authorisation_type: AdminAuthorisationTypeRead;
}

export interface AdminUserAuthorisationCreatePayload {
  user_id: string;
  authorisation_type_id: string;
  scope_text?: string | null;
  effective_from: string;
  expires_at?: string | null;
}

export interface AdminUserAuthorisationUpdatePayload {
  scope_text?: string | null;
  effective_from?: string | null;
  expires_at?: string | null;
  revoked_at?: string | null;
  revoked_reason?: string | null;
}

export interface BulkUserActionPayload {
  user_ids: string[];
  action:
    | "enable"
    | "disable"
    | "delete"
    | "assign_department"
    | "clear_department"
    | "change_role"
    | "add_group"
    | "remove_group"
    | "schedule_leave"
    | "return_from_leave";
  department_id?: string | null;
  role?: AccountRole | null;
  group_id?: string | null;
  note?: string | null;
  effective_from?: string | null;
  effective_to?: string | null;
}

export interface BulkUserActionResult {
  action: string;
  processed: number;
  affected_user_ids: string[];
  detail: string;
}

export interface UserEmploymentActionPayload {
  action:
    | "new_hire"
    | "promote"
    | "demote"
    | "transfer"
    | "resign"
    | "reinstate"
    | "reemploy"
    | "schedule_leave"
    | "return_from_leave";
  role?: AccountRole | null;
  department_id?: string | null;
  position_title?: string | null;
  note?: string | null;
  effective_from?: string | null;
  effective_to?: string | null;
  employment_status?: string | null;
}

export interface UserEmploymentActionResult {
  user_id: string;
  action: string;
  effective_at: string;
  status: string;
  note: string | null;
}

export interface AdminUserWorkspace {
  user: AdminUserRead;
  department_name: string | null;
  display_title: string;
  presence: AdminUserPresence;
  presence_display: AdminUserPresenceDisplay;
  metrics: AdminUserWorkspaceMetric[];
  tasks: AdminUserTaskSummary[];
  permissions: AdminUserPermissionSummary[];
  activity_log: AdminUserActivitySummary[];
  login_record: AdminUserLoginRecord;
  groups: AdminUserGroupChip[];
  profile: AdminPersonnelProfileSummary | null;
  availability: AdminUserAvailabilitySummary[];
  group_memberships: AdminUserGroupRead[];
}

export async function getAdminUserDirectory(params: {
  amo_id?: string | null;
  search?: string;
  skip?: number;
  limit?: number;
} = {}): Promise<AdminUserDirectoryResponse> {
  const sp = new URLSearchParams();
  if (params.amo_id && params.amo_id.trim()) sp.set("amo_id", params.amo_id.trim());
  if (params.search && params.search.trim()) sp.set("search", params.search.trim());
  if (typeof params.skip === "number") sp.set("skip", String(params.skip));
  if (typeof params.limit === "number") sp.set("limit", String(params.limit));
  const qs = sp.toString();
  return apiGet<AdminUserDirectoryResponse>(`/accounts/admin/user-directory${qs ? `?${qs}` : ""}`, {
    headers: authHeaders(),
  });
}

export async function getAdminUserWorkspace(userId: string): Promise<AdminUserWorkspace> {
  return cachedAdminUserGet(`workspace:${userId}`, 90_000, () => apiGet<AdminUserWorkspace>(`/accounts/admin/users/${encodeURIComponent(userId)}/workspace`, {
    headers: authHeaders(),
  }));
}

export async function prefetchAdminUserProfile(userId: string): Promise<void> {
  await Promise.allSettled([
    getAdminUser(userId),
  ]);
}


function resolveDownloadFilename(disposition: string | null, fallback: string): string {
  const match = disposition?.match(/filename="?([^";]+)"?/i);
  return match?.[1] || fallback;
}

async function downloadBlob(path: string, fallbackFilename: string): Promise<{ filename: string; blob: Blob }> {
  const res = await fetch(`${getApiBaseUrl()}${path}`, {
    method: "GET",
    headers: authHeaders(),
  });
  if (!res.ok) {
    const contentType = res.headers.get("Content-Type") || "";
    const text = await res.text();
    let message = text || `HTTP ${res.status}`;
    if (contentType.toLowerCase().includes("application/json")) {
      try {
        const parsed = JSON.parse(text) as { detail?: string; message?: string };
        message = parsed.detail || parsed.message || message;
      } catch {
        // ignore parse fallback
      }
    }
    throw new Error(message || `HTTP ${res.status}`);
  }
  return {
    filename: resolveDownloadFilename(res.headers.get("Content-Disposition"), fallbackFilename),
    blob: await res.blob(),
  };
}

export async function listAdminAuthorisationTypes(amoId?: string | null): Promise<AdminAuthorisationTypeRead[]> {
  const sp = new URLSearchParams();
  if (amoId && amoId.trim()) sp.set("amo_id", amoId.trim());
  const qs = sp.toString();
  return apiGet<AdminAuthorisationTypeRead[]>(`/accounts/admin/authorisation-types${qs ? `?${qs}` : ""}`, {
    headers: authHeaders(),
  });
}

export async function createAdminAuthorisationType(
  payload: AdminAuthorisationTypeCreatePayload,
): Promise<AdminAuthorisationTypeRead> {
  return apiPost<AdminAuthorisationTypeRead>(`/accounts/admin/authorisation-types`, JSON.stringify(payload), {
    headers: authHeaders(),
  });
}

export async function updateAdminAuthorisationType(
  authorisationTypeId: string,
  payload: AdminAuthorisationTypeUpdatePayload,
): Promise<AdminAuthorisationTypeRead> {
  return apiPut<AdminAuthorisationTypeRead>(
    `/accounts/admin/authorisation-types/${encodeURIComponent(authorisationTypeId)}`,
    JSON.stringify(payload),
    { headers: authHeaders() },
  );
}

export async function deleteAdminAuthorisationType(authorisationTypeId: string): Promise<void> {
  await apiDelete<void>(`/accounts/admin/authorisation-types/${encodeURIComponent(authorisationTypeId)}`, undefined, {
    headers: authHeaders(),
  });
}

export async function listAdminUserAuthorisations(userId?: string | null): Promise<AdminUserAuthorisationRead[]> {
  const sp = new URLSearchParams();
  if (userId && userId.trim()) sp.set("user_id", userId.trim());
  const qs = sp.toString();
  return apiGet<AdminUserAuthorisationRead[]>(`/accounts/admin/user-authorisations${qs ? `?${qs}` : ""}`, {
    headers: authHeaders(),
  });
}

export async function grantAdminUserAuthorisation(
  payload: AdminUserAuthorisationCreatePayload,
): Promise<AdminUserAuthorisationRead> {
  return apiPost<AdminUserAuthorisationRead>(`/accounts/admin/user-authorisations`, JSON.stringify(payload), {
    headers: authHeaders(),
  });
}

export async function updateAdminUserAuthorisation(
  userAuthorisationId: string,
  payload: AdminUserAuthorisationUpdatePayload,
): Promise<AdminUserAuthorisationRead> {
  return apiPut<AdminUserAuthorisationRead>(
    `/accounts/admin/user-authorisations/${encodeURIComponent(userAuthorisationId)}`,
    JSON.stringify(payload),
    { headers: authHeaders() },
  );
}

export async function deleteAdminUserAuthorisation(userAuthorisationId: string): Promise<void> {
  await apiDelete<void>(`/accounts/admin/user-authorisations/${encodeURIComponent(userAuthorisationId)}`, undefined, {
    headers: authHeaders(),
  });
}

export async function listAdminGroups(amoId?: string | null): Promise<AdminUserGroupRead[]> {
  const sp = new URLSearchParams();
  if (amoId && amoId.trim()) sp.set("amo_id", amoId.trim());
  const qs = sp.toString();
  return apiGet<AdminUserGroupRead[]>(`/accounts/admin/groups${qs ? `?${qs}` : ""}`, {
    headers: authHeaders(),
  });
}

export async function createAdminGroup(payload: AdminUserGroupCreatePayload): Promise<AdminUserGroupRead> {
  return apiPost<AdminUserGroupRead>(`/accounts/admin/groups`, JSON.stringify(payload), {
    headers: authHeaders(),
  });
}

export async function updateAdminGroup(groupId: string, payload: AdminUserGroupUpdatePayload): Promise<AdminUserGroupRead> {
  return apiPut<AdminUserGroupRead>(`/accounts/admin/groups/${encodeURIComponent(groupId)}`, JSON.stringify(payload), {
    headers: authHeaders(),
  });
}

export async function deleteAdminGroup(groupId: string): Promise<void> {
  await apiDelete<void>(`/accounts/admin/groups/${encodeURIComponent(groupId)}`, undefined, {
    headers: authHeaders(),
  });
}

export async function listAdminGroupMembers(groupId: string): Promise<AdminUserGroupMemberRead[]> {
  return apiGet<AdminUserGroupMemberRead[]>(`/accounts/admin/groups/${encodeURIComponent(groupId)}/members`, {
    headers: authHeaders(),
  });
}

export async function addAdminGroupMember(
  groupId: string,
  payload: AdminUserGroupMemberCreatePayload,
): Promise<AdminUserGroupMemberRead> {
  return apiPost<AdminUserGroupMemberRead>(
    `/accounts/admin/groups/${encodeURIComponent(groupId)}/members`,
    JSON.stringify(payload),
    { headers: authHeaders() },
  );
}

export async function removeAdminGroupMember(groupId: string, membershipId: string): Promise<void> {
  await apiDelete<void>(
    `/accounts/admin/groups/${encodeURIComponent(groupId)}/members/${encodeURIComponent(membershipId)}`,
    undefined,
    { headers: authHeaders() },
  );
}

export async function bulkAdminUserAction(payload: BulkUserActionPayload): Promise<BulkUserActionResult> {
  return apiPost<BulkUserActionResult>(`/accounts/admin/users/bulk`, JSON.stringify(payload), {
    headers: authHeaders(),
  });
}

export async function applyAdminUserEmploymentAction(
  userId: string,
  payload: UserEmploymentActionPayload,
): Promise<UserEmploymentActionResult> {
  return apiPost<UserEmploymentActionResult>(
    `/accounts/admin/users/${encodeURIComponent(userId)}/employment-actions`,
    JSON.stringify(payload),
    { headers: authHeaders() },
  );
}

export async function permanentDeleteAdminUser(userId: string): Promise<void> {
  await apiDelete<void>(`/accounts/admin/users/${encodeURIComponent(userId)}`, undefined, {
    headers: authHeaders(),
  });
}

export async function downloadAdminUserExport(userId: string): Promise<{ filename: string; blob: Blob }> {
  return downloadBlob(`/accounts/admin/users/${encodeURIComponent(userId)}/export`, `user_${userId}.json`);
}

export async function downloadAdminUsersExport(
  userIds: string[],
  format: "json" | "csv" = "json",
): Promise<{ filename: string; blob: Blob }> {
  const sp = new URLSearchParams();
  sp.set("ids", userIds.join(","));
  sp.set("format", format);
  return downloadBlob(`/accounts/admin/users/export?${sp.toString()}`, `users_export.${format}`);
}
