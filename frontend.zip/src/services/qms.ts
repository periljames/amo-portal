// src/services/qms.ts
// QMS (Quality Management System) API helpers.
//
// This module is intentionally small and uses fetch + the existing auth token.
// Mature workflow helpers still use the legacy backend compatibility API
// while the visible frontend route surface has been consolidated under
// /maintenance/:amoCode/qms. Do not delete these compatibility calls until
// the canonical /api/maintenance/:amoCode/qms endpoints have response-shape
// parity for the detailed document, audit, CAR, AeroDoc, and manpower flows.

import { getToken, handleAuthFailure } from "./auth";
import { getApiBaseUrl } from "./config";
import { beginBackgroundLoading, beginLoading, endBackgroundLoading, endLoading } from "./loading";

export type QMSDocumentStatus = "DRAFT" | "ACTIVE" | "OBSOLETE";
export type QMSAuditStatus = "PLANNED" | "IN_PROGRESS" | "CAP_OPEN" | "CLOSED";
export type QMSAuditScheduleFrequency =
  | "ONE_TIME"
  | "MONTHLY"
  | "QUARTERLY"
  | "BI_ANNUAL"
  | "ANNUAL";
export type QMSChangeRequestStatus =
  | "SUBMITTED"
  | "UNDER_REVIEW"
  | "SUBMITTED_TO_AUTHORITY"
  | "APPROVED"
  | "REJECTED"
  | "CANCELLED";

export type CARProgram = "QUALITY" | "RELIABILITY";
export type CARStatus =
  | "DRAFT"
  | "OPEN"
  | "IN_PROGRESS"
  | "PENDING_VERIFICATION"
  | "CLOSED"
  | "ESCALATED"
  | "CANCELLED";
export type CARPriority = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export interface QMSDocumentOut {
  id: string;
  domain: string;
  doc_type: string;
  doc_code: string;
  title: string;
  status: QMSDocumentStatus;
  current_issue_no: string | null;
  current_rev_no: string | null;
  effective_date: string | null; // YYYY-MM-DD
  current_file_ref: string | null;
  updated_at: string; // ISO datetime
  created_at: string; // ISO datetime
}

export interface QMSDistributionOut {
  id: string;
  doc_id: string;
  recipient_user_id: string;
  requires_ack: boolean;
  acked_at: string | null; // ISO datetime
  created_at: string; // ISO datetime
}

export interface QMSChangeRequestOut {
  id: string;
  domain: string;
  title: string;
  status: QMSChangeRequestStatus;
  reason: string | null;
  requested_at: string; // ISO datetime
  updated_at: string; // ISO datetime
}

export interface QMSAuditOut {
  id: string;
  domain: string;
  kind: string;
  status: QMSAuditStatus;
  audit_ref: string;
  title: string;
  scope?: string | null;
  criteria?: string | null;
  auditee?: string | null;
  auditee_email?: string | null;
  auditee_user_id?: string | null;
  lead_auditor_user_id?: string | null;
  observer_auditor_user_id?: string | null;
  assistant_auditor_user_id?: string | null;
  planned_start: string | null; // YYYY-MM-DD
  planned_end: string | null; // YYYY-MM-DD
  actual_start?: string | null;
  actual_end?: string | null;
  report_file_ref?: string | null;
  checklist_file_ref?: string | null;
  retention_until?: string | null;
  upcoming_notice_sent_at?: string | null;
  day_of_notice_sent_at?: string | null;
  updated_at: string; // ISO datetime
  created_at: string; // ISO datetime
}

export interface QMSAuditScheduleOut {
  id: string;
  domain: string;
  kind: string;
  frequency: QMSAuditScheduleFrequency;
  title: string;
  scope?: string | null;
  criteria?: string | null;
  auditee?: string | null;
  auditee_email?: string | null;
  auditee_user_id?: string | null;
  lead_auditor_user_id?: string | null;
  observer_auditor_user_id?: string | null;
  assistant_auditor_user_id?: string | null;
  duration_days: number;
  next_due_date: string;
  last_run_at?: string | null;
  is_active: boolean;
  created_by_user_id?: string | null;
  created_at: string;
}

export interface QMSAuditParticipantOut {
  role: string;
  user_id: string | null;
  name: string | null;
  email: string | null;
}

export interface QMSAuditWorkspaceSummaryOut {
  audit_id: string;
  audit_ref: string;
  title: string;
  status: string;
  domain: string;
  kind: string;
  planned_start: string | null;
  planned_end: string | null;
  actual_start: string | null;
  actual_end: string | null;
  report_uploaded: boolean;
  checklist_uploaded: boolean;
  findings_total: number;
  findings_open: number;
  cars_total: number;
  cars_open: number;
  evidence_files_total: number;
}

export interface QMSAuditWorkspaceReadinessOut {
  planning_complete: boolean;
  fieldwork_ready: boolean;
  closure_ready: boolean;
  report_ready: boolean;
  public_response_window_open: boolean;
}

export interface QMSAuditWorkspaceActionOut {
  code: string;
  label: string;
  enabled: boolean;
  variant: string;
  count: number | null;
}

export interface QMSAuditNoticeStateOut {
  upcoming_notice_sent_at: string | null;
  day_of_notice_sent_at: string | null;
}

export interface QMSAuditWorkspaceOut {
  audit: QMSAuditOut;
  summary: QMSAuditWorkspaceSummaryOut;
  readiness: QMSAuditWorkspaceReadinessOut;
  actions: QMSAuditWorkspaceActionOut[];
  participants: QMSAuditParticipantOut[];
  notice_state: QMSAuditNoticeStateOut;
}

export interface QMSAuditWorkflowCheckItemOut {
  code: string;
  label: string;
  passed: boolean;
  detail: string;
}

export interface QMSAuditWorkflowCheckOut {
  audit_id: string;
  audit_status: string;
  checks: QMSAuditWorkflowCheckItemOut[];
  passed: boolean;
}

export interface QMSAuditNoticeDispatchOut {
  audit_id: string;
  stage: string;
  notified_user_ids: string[];
  sent_at: string;
}

export interface QMSFindingOut {
  id: string;
  audit_id: string;
  finding_ref?: string | null;
  finding_type: string;
  severity: string;
  level: string;
  requirement_ref?: string | null;
  description: string;
  objective_evidence?: string | null;
  safety_sensitive: boolean;
  target_close_date?: string | null;
  closed_at?: string | null;
  verified_at?: string | null;
  verified_by_user_id?: string | null;
  acknowledged_at?: string | null;
  acknowledged_by_user_id?: string | null;
  acknowledged_by_name?: string | null;
  acknowledged_by_email?: string | null;
  created_at: string;
}

export interface QMSAuditRegisterRowOut {
  audit: QMSAuditOut;
  finding: QMSFindingOut;
  linked_cars: CAROut[];
}

export interface QMSAuditRegisterResponse {
  rows: QMSAuditRegisterRowOut[];
}

export interface CAROut {
  id: string;
  program: CARProgram;
  car_number: string;
  title: string;
  summary: string;
  priority: CARPriority;
  status: CARStatus;
  due_date: string | null; // YYYY-MM-DD
  target_closure_date: string | null; // YYYY-MM-DD
  closed_at: string | null;
  escalated_at: string | null;
  finding_id: string | null;
  requested_by_user_id: string | null;
  assigned_to_user_id: string | null;
  invite_token: string;
  reminder_interval_days: number;
  next_reminder_at: string | null;
  containment_action?: string | null;
  root_cause?: string | null;
  corrective_action?: string | null;
  preventive_action?: string | null;
  evidence_ref?: string | null;
  submitted_by_name?: string | null;
  submitted_by_email?: string | null;
  submitted_at?: string | null;
  root_cause_text?: string | null;
  root_cause_status?: string;
  root_cause_review_note?: string | null;
  capa_text?: string | null;
  capa_status?: string;
  capa_review_note?: string | null;
  evidence_required?: boolean;
  evidence_received_at?: string | null;
  evidence_verified_at?: string | null;
  created_at: string;
  updated_at: string;
}

type QueryVal = string | number | boolean | null | undefined;

const API_BASE = getApiBaseUrl();
const NOTIFICATION_SUMMARY_CACHE_KEY = "amo:qms-notification-summary:data";
const NOTIFICATION_SUMMARY_ETAG_KEY = "amo:qms-notification-summary:etag";

function readStoredNotificationSummary(): QMSNotificationSummaryOut | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(NOTIFICATION_SUMMARY_CACHE_KEY);
    return raw ? (JSON.parse(raw) as QMSNotificationSummaryOut) : null;
  } catch {
    return null;
  }
}

function writeStoredNotificationSummary(summary: QMSNotificationSummaryOut, etag?: string | null): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(NOTIFICATION_SUMMARY_CACHE_KEY, JSON.stringify(summary));
    if (etag) {
      window.localStorage.setItem(NOTIFICATION_SUMMARY_ETAG_KEY, etag);
    }
  } catch {
    // ignore storage failures
  }
}

function readStoredNotificationSummaryEtag(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(NOTIFICATION_SUMMARY_ETAG_KEY);
}


function toQuery(params: Record<string, QueryVal>): string {
  const qs = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v === null || v === undefined) return;
    qs.set(k, String(v));
  });
  const s = qs.toString();
  return s ? `?${s}` : "";
}

function downloadEvidencePack(path: string): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", `${API_BASE}${path}`);
    const token = getToken();
    if (token) {
      xhr.setRequestHeader("Authorization", `Bearer ${token}`);
    }
    xhr.responseType = "blob";

    xhr.addEventListener("load", () => {
      if (xhr.status === 401) {
        handleAuthFailure("expired");
        reject(new Error("Session expired. Please sign in again."));
        return;
      }
      if (xhr.status < 200 || xhr.status >= 300) {
        const message = xhr.responseText || `Request failed (${xhr.status})`;
        reject(new Error(message));
        return;
      }
      resolve(xhr.response as Blob);
    });

    xhr.addEventListener("error", () => {
      reject(new Error("Network error while downloading evidence pack."));
    });

    xhr.timeout = 45000;
    xhr.addEventListener("timeout", () => { reject(new Error("Timed out while downloading evidence pack.")); });
    xhr.send();
  });
}

async function downloadBinary(path: string): Promise<Blob> {
  const token = getToken();
  beginBackgroundLoading();
  try {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort("timeout"), 30000);
  const res = await fetch(`${API_BASE}${path}`, {
    method: "GET",
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    credentials: "include",
    signal: controller.signal,
  });
  window.clearTimeout(timeout);

  if (res.status === 401) {
    handleAuthFailure("expired");
    throw new Error("Session expired. Please sign in again.");
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`QMS API ${res.status}: ${text || res.statusText}`);
  }
  return res.blob();
  } finally {
    endBackgroundLoading();
  }
}

async function fetchJson<T>(path: string): Promise<T> {
  const token = getToken();
  beginBackgroundLoading();
  try {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort("timeout"), 20000);
  const res = await fetch(`${getApiBaseUrl()}${path}`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    credentials: "include",
    signal: controller.signal,
  });
  window.clearTimeout(timeout);

  if (res.status === 401) {
    handleAuthFailure("expired");
    throw new Error("Session expired. Please sign in again.");
  }

  if (res.status === 503) {
    const text = await res.text().catch(() => "");
    throw new Error(text || "Service unavailable. Please retry or contact support.");
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`QMS API ${res.status}: ${text || res.statusText}`);
  }
  return (await res.json()) as T;
  } finally {
    endBackgroundLoading();
  }
}

async function sendJson<T>(
  path: string,
  method: "POST" | "PATCH" | "DELETE",
  body: unknown
): Promise<T> {
  const token = getToken();
  beginLoading();
  try {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort("timeout"), 45000);
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body ?? {}),
    credentials: "include",
    signal: controller.signal,
  });
  window.clearTimeout(timeout);

  if (res.status === 401) {
    handleAuthFailure("expired");
    throw new Error("Session expired. Please sign in again.");
  }

  if (res.status === 503) {
    const text = await res.text().catch(() => "");
    throw new Error(text || "Service unavailable. Please retry or contact support.");
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`QMS API ${res.status}: ${text || res.statusText}`);
  }
  if (res.status === 204) {
    return undefined as T;
  }
  return (await res.json()) as T;
  } finally {
    endLoading();
  }
}


export interface QMSDashboardOut {
  domain: string | null;
  documents_total: number;
  documents_active: number;
  documents_draft: number;
  documents_obsolete: number;
  distributions_pending_ack: number;
  change_requests_total: number;
  change_requests_open: number;
  audits_total: number;
  audits_open: number;
  findings_open_total: number;
  findings_open_level_1: number;
  findings_open_level_2: number;
  findings_open_level_3: number;
  findings_overdue_total: number;
}

export async function qmsGetDashboard(params?: {
  domain?: string;
}): Promise<QMSDashboardOut> {
  return fetchJson<QMSDashboardOut>(`/quality/qms/dashboard${toQuery(params ?? {})}`);
}



export type QMSAvailabilityStatus = "ON_DUTY" | "AWAY" | "ON_LEAVE";

export interface QMSManpowerAvailabilityItem {
  id: string;
  user_id: string;
  status: QMSAvailabilityStatus;
  effective_from: string;
  effective_to: string | null;
  note: string | null;
  updated_by_user_id: string | null;
  updated_at: string;
}

export interface QMSManpowerOut {
  scope: "tenant" | "department";
  total_employees: number;
  by_role: Record<string, number>;
  availability: { on_duty: number; away: number; on_leave: number } | null;
  by_department: Array<{ department: string; count: number }> | null;
  updated_at: string;
}

export interface QMSCockpitActionItemOut {
  id: string;
  kind: string;
  title: string;
  status: string;
  priority: string;
  due_date: string | null;
  assignee_user_id: string | null;
}

export interface QMSCockpitSnapshotOut {
  generated_at: string;
  pending_acknowledgements: number;
  audits_open: number;
  audits_total: number;
  findings_overdue: number;
  findings_open_total: number;
  documents_active: number;
  documents_draft: number;
  documents_obsolete: number;
  change_requests_open: number;
  cars_open_total: number;
  cars_overdue: number;
  training_records_expiring_30d: number;
  training_records_expired: number;
  training_records_unverified: number;
  training_deferrals_pending: number;
  suppliers_active: number;
  suppliers_inactive: number;
  tasks_due_today?: number;
  tasks_overdue?: number;
  change_control_pending_approvals?: number;
  events_hold_count?: number;
  events_new_count?: number;
  compliance_exceptions_open?: number;
  compliance_overdue?: number;
  compliance_unplanned_applicable?: number;
  manpower?: QMSManpowerOut | null;
  audit_closure_trend: {
    period_start: string;
    period_end: string;
    closed_count: number;
    audit_ids: string[];
  }[];
  most_common_finding_trend_12m: {
    period_start: string;
    finding_type: string;
    count: number;
  }[];
  action_queue: QMSCockpitActionItemOut[];
}

export async function qmsGetCockpitSnapshot(params?: {
  domain?: string;
}): Promise<QMSCockpitSnapshotOut> {
  return fetchJson<QMSCockpitSnapshotOut>(`/quality/qms/cockpit-snapshot${toQuery(params ?? {})}`);
}

export async function qmsListManpowerAvailability(params?: { department?: string }): Promise<QMSManpowerAvailabilityItem[]> {
  return fetchJson<QMSManpowerAvailabilityItem[]>(`/quality/qms/manpower/availability${toQuery(params ?? {})}`);
}

export async function qmsSetManpowerAvailability(payload: {
  user_id: string;
  status: QMSAvailabilityStatus;
  effective_from?: string | null;
  effective_to?: string | null;
  note?: string | null;
}): Promise<QMSManpowerAvailabilityItem> {
  return sendJson<QMSManpowerAvailabilityItem>("/quality/qms/manpower/availability", "POST", payload);
}
export async function qmsListDocuments(params?: {
  status_?: QMSDocumentStatus;
  domain?: string;
  doc_type?: string;
  q?: string;
}): Promise<QMSDocumentOut[]> {
  return fetchJson<QMSDocumentOut[]>(
    `/quality/qms/documents${toQuery(params ?? {})}`
  );
}

export async function qmsListDistributions(params?: {
  doc_id?: string;
  outstanding_only?: boolean;
}): Promise<QMSDistributionOut[]> {
  return fetchJson<QMSDistributionOut[]>(
    `/quality/qms/distributions${toQuery(params ?? {})}`
  );
}

export async function qmsCreateDistribution(payload: {
  doc_id: string;
  recipient_user_id: string;
  requires_ack?: boolean;
}): Promise<QMSDistributionOut> {
  return sendJson<QMSDistributionOut>("/quality/qms/distributions", "POST", {
    ...payload,
    requires_ack: payload.requires_ack ?? true,
  });
}

export async function qmsListChangeRequests(params?: {
  domain?: string;
  status_?: QMSChangeRequestStatus;
}): Promise<QMSChangeRequestOut[]> {
  return fetchJson<QMSChangeRequestOut[]>(
    `/quality/qms${"/change-requests"}${toQuery(params ?? {})}`
  );
}

export async function qmsListAudits(params?: {
  domain?: string;
  status_?: QMSAuditStatus;
  kind?: string;
}): Promise<QMSAuditOut[]> {
  return fetchJson<QMSAuditOut[]>(`/quality/audits${toQuery(params ?? {})}`);
}

export async function qmsListAuditSchedules(params?: {
  domain?: string;
  active?: boolean;
}): Promise<QMSAuditScheduleOut[]> {
  return fetchJson<QMSAuditScheduleOut[]>(
    `/quality/audits/schedules${toQuery(params ?? {})}`
  );
}

export async function qmsCreateAuditSchedule(payload: {
  domain: string;
  kind: string;
  frequency: QMSAuditScheduleFrequency;
  title: string;
  scope?: string | null;
  criteria?: string | null;
  auditee?: string | null;
  auditee_email?: string | null;
  auditee_user_id?: string | null;
  lead_auditor_user_id?: string | null;
  observer_auditor_user_id?: string | null;
  assistant_auditor_user_id?: string | null;
  duration_days: number;
  next_due_date: string;
}): Promise<QMSAuditScheduleOut> {
  return sendJson<QMSAuditScheduleOut>(
    "/quality/audits/schedules",
    "POST",
    payload
  );
}

export async function qmsUpdateAuditSchedule(
  scheduleId: string,
  payload: {
    kind?: string | null;
    frequency?: QMSAuditScheduleFrequency | null;
    title?: string | null;
    scope?: string | null;
    criteria?: string | null;
    auditee?: string | null;
    auditee_email?: string | null;
    auditee_user_id?: string | null;
    lead_auditor_user_id?: string | null;
    observer_auditor_user_id?: string | null;
    assistant_auditor_user_id?: string | null;
    duration_days?: number | null;
    next_due_date?: string | null;
    is_active?: boolean | null;
  }
): Promise<QMSAuditScheduleOut> {
  return sendJson<QMSAuditScheduleOut>(`/quality/audits/schedules/${encodeURIComponent(scheduleId)}`, "PATCH", payload);
}

export interface QMSPersonOption {
  id: string;
  full_name: string;
  email: string | null;
  role: string | null;
  department_id: string | null;
  position_title: string | null;
  staff_code?: string | null;
}

export async function qmsListAuditPersonnelOptions(params?: {
  search?: string;
  limit?: number;
}): Promise<QMSPersonOption[]> {
  const suffix = toQuery({ search: params?.search, limit: params?.limit ?? 50 });
  return fetchJson<QMSPersonOption[]>(`/quality/audits/personnel/options${suffix}`);
}

export async function qmsUpdateAudit(
  auditId: string,
  payload: {
    planned_start?: string | null;
    planned_end?: string | null;
  }
): Promise<QMSAuditOut> {
  return sendJson<QMSAuditOut>(`/quality/audits/${auditId}`, "PATCH", payload);
}

export async function qmsDeleteAuditSchedule(scheduleId: string): Promise<void> {
  await sendJson<void>(`/quality/audits/schedules/${scheduleId}`, "DELETE", undefined);
}

export async function qmsRunAuditSchedule(
  scheduleId: string
): Promise<QMSAuditOut> {
  return sendJson<QMSAuditOut>(
    `/quality/audits/schedules/${scheduleId}/run`,
    "POST",
    {}
  );
}

export async function qmsRunAuditReminders(upcomingDays: number): Promise<{
  day_of_sent: number;
  upcoming_sent: number;
}> {
  return sendJson<{ day_of_sent: number; upcoming_sent: number }>(
    `/quality/audits/reminders/run?upcoming_days=${upcomingDays}`,
    "POST",
    {}
  );
}

export async function qmsGetAuditWorkspace(auditId: string): Promise<QMSAuditWorkspaceOut> {
  return fetchJson<QMSAuditWorkspaceOut>(`/quality/audits/${encodeURIComponent(auditId)}/workspace`);
}

export async function qmsGetAuditWorkflowCheck(auditId: string): Promise<QMSAuditWorkflowCheckOut> {
  return fetchJson<QMSAuditWorkflowCheckOut>(`/quality/audits/${encodeURIComponent(auditId)}/workflow-check`);
}

export async function qmsIssueAuditNotice(
  auditId: string,
  payload?: { stage?: "manual" | "upcoming" | "day_of" }
): Promise<QMSAuditNoticeDispatchOut> {
  return sendJson<QMSAuditNoticeDispatchOut>(
    `/quality/audits/${encodeURIComponent(auditId)}/issue-notice`,
    "POST",
    payload ?? {}
  );
}

export async function qmsUploadAuditChecklist(
  auditId: string,
  file: File
): Promise<QMSAuditOut> {
  const formData = new FormData();
  formData.append("file", file);
  const token = getToken();
  const res = await fetch(`${API_BASE}/quality/audits/${auditId}/checklist`, {
    method: "POST",
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: formData,
    credentials: "include",
  });

  if (res.status === 401) {
    handleAuthFailure("expired");
    throw new Error("Session expired. Please sign in again.");
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`QMS API ${res.status}: ${text || res.statusText}`);
  }
  return (await res.json()) as QMSAuditOut;
}

export async function qmsDownloadAuditChecklist(auditId: string): Promise<Blob> {
  return downloadBinary(`/quality/audits/${auditId}/checklist`);
}

export async function qmsUploadAuditReport(
  auditId: string,
  file: File
): Promise<QMSAuditOut> {
  const formData = new FormData();
  formData.append("file", file);
  const token = getToken();
  const res = await fetch(`${API_BASE}/quality/audits/${auditId}/report`, {
    method: "POST",
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: formData,
    credentials: "include",
  });

  if (res.status === 401) {
    handleAuthFailure("expired");
    throw new Error("Session expired. Please sign in again.");
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`QMS API ${res.status}: ${text || res.statusText}`);
  }
  return (await res.json()) as QMSAuditOut;
}

export async function qmsDownloadAuditReport(auditId: string): Promise<Blob> {
  return downloadBinary(`/quality/audits/${auditId}/report`);
}

export async function qmsListFindings(auditId: string): Promise<QMSFindingOut[]> {
  return fetchJson<QMSFindingOut[]>(`/quality/audits/${auditId}/findings`);
}

export async function qmsListFindingsBulk(params?: {
  domain?: string;
  audit_ids?: string[];
}): Promise<QMSFindingOut[]> {
  const qs = new URLSearchParams();
  if (params?.domain) qs.set("domain", params.domain);
  (params?.audit_ids ?? []).forEach((auditId) => qs.append("audit_ids", auditId));
  const suffix = qs.toString() ? `?${qs.toString()}` : "";
  return fetchJson<QMSFindingOut[]>(`/quality/audits/findings${suffix}`);
}

export async function qmsGetAuditRegister(params?: {
  domain?: string;
}): Promise<QMSAuditRegisterResponse> {
  return fetchJson<QMSAuditRegisterResponse>(`/quality/audits/register${toQuery(params ?? {})}`);
}

export async function qmsVerifyFinding(
  findingId: string,
  payload: { objective_evidence?: string | null }
): Promise<QMSFindingOut> {
  return sendJson<QMSFindingOut>(
    `/quality/findings/${findingId}/verify`,
    "POST",
    payload
  );
}

export async function qmsCloseFinding(findingId: string): Promise<QMSFindingOut> {
  return sendJson<QMSFindingOut>(`/quality/findings/${findingId}/close`, "POST", {});
}

export async function qmsAcknowledgeFinding(
  findingId: string,
  payload: { acknowledged_by_name?: string; acknowledged_by_email?: string }
): Promise<QMSFindingOut> {
  return sendJson<QMSFindingOut>(
    `/quality/findings/${findingId}/ack`,
    "POST",
    payload
  );
}

export async function qmsListCars(params?: {
  program?: CARProgram;
  status_?: CARStatus;
  assigned_to_user_id?: string;
}): Promise<CAROut[]> {
  return fetchJson<CAROut[]>(`/quality/cars${toQuery(params ?? {})}`);
}

export type CARAssignee = {
  id: string;
  full_name: string;
  email?: string | null;
  staff_code?: string | null;
  role: string;
  department_id?: string | null;
  department_code?: string | null;
  department_name?: string | null;
};

export async function qmsListCarAssignees(params?: {
  department_id?: string;
  search?: string;
}): Promise<CARAssignee[]> {
  return fetchJson<CARAssignee[]>(
    `/quality/cars/assignees${toQuery(params ?? {})}`
  );
}

export async function qmsCreateCar(payload: {
  program: CARProgram;
  title: string;
  summary: string;
  priority?: CARPriority;
  due_date?: string | null;
  target_closure_date?: string | null;
  assigned_to_user_id?: string | null;
  finding_id: string;
  evidence_required?: boolean;
}): Promise<CAROut> {
  return sendJson<CAROut>("/quality/cars", "POST", payload);
}

export async function qmsUpdateCar(
  carId: string,
  payload: {
    title?: string;
    summary?: string;
    priority?: CARPriority;
    status?: CARStatus;
    due_date?: string | null;
    target_closure_date?: string | null;
    assigned_to_user_id?: string | null;
    reminder_interval_days?: number | null;
  }
): Promise<CAROut> {
  return sendJson<CAROut>(`/quality/cars/${carId}`, "PATCH", payload);
}

export async function qmsReviewCarResponse(
  carId: string,
  payload: {
    root_cause_status?: "ACCEPTED" | "REJECTED";
    root_cause_review_note?: string | null;
    capa_status?: "ACCEPTED" | "REJECTED" | "NEEDS_EVIDENCE";
    capa_review_note?: string | null;
    message?: string | null;
  }
): Promise<CAROut> {
  return sendJson<CAROut>(`/quality/cars/${encodeURIComponent(carId)}/review`, "POST", payload);
}

export async function qmsDeleteCar(carId: string): Promise<void> {
  await sendJson(`/quality/cars/${carId}`, "DELETE", {});
}

export async function qmsGetCarInvite(carId: string): Promise<{
  car_id: string;
  invite_token: string;
  invite_url: string;
  next_reminder_at: string | null;
  car_number: string;
  title: string;
  summary: string;
  priority: CARPriority;
  status: CARStatus;
  due_date: string | null;
  target_closure_date: string | null;
}> {
  return fetchJson(`/quality/cars/${carId}/invite`);
}

export async function qmsRescheduleCarReminder(carId: string, intervalDays: number): Promise<CAROut> {
  return sendJson<CAROut>(`/quality/cars/${carId}/reminders?reminder_interval_days=${intervalDays}`, "POST", {});
}

export async function qmsGetCarInviteByToken(token: string): Promise<{
  car_id: string;
  invite_token: string;
  invite_url: string;
  next_reminder_at: string | null;
  car_number: string;
  title: string;
  summary: string;
  priority: CARPriority;
  status: CARStatus;
  due_date: string | null;
  target_closure_date: string | null;
}> {
  return fetchJson(`/quality/cars/invite/${token}`);
}

export async function qmsSubmitCarInvite(
  token: string,
  payload: {
    submitted_by_name: string;
    submitted_by_email: string;
    containment_action?: string | null;
    root_cause?: string | null;
    corrective_action?: string | null;
    preventive_action?: string | null;
    evidence_ref?: string | null;
    due_date?: string | null;
    target_closure_date?: string | null;
    root_cause_text?: string | null;
    capa_text?: string | null;
  }
): Promise<CAROut> {
  return sendJson<CAROut>(`/quality/cars/invite/${token}`, "PATCH", payload);
}

export interface CARAttachmentOut {
  id: string;
  car_id: string;
  filename: string;
  content_type: string | null;
  size_bytes: number | null;
  sha256: string | null;
  uploaded_at: string;
  download_url: string;
}

export async function qmsListCarInviteAttachments(token: string): Promise<CARAttachmentOut[]> {
  return fetchJson<CARAttachmentOut[]>(`/quality/cars/invite/${token}/attachments`);
}

export async function qmsUploadCarInviteAttachment(
  token: string,
  file: File
): Promise<CARAttachmentOut> {
  const formData = new FormData();
  formData.append("file", file);
  const authToken = getToken();
  const res = await fetch(`${getApiBaseUrl()}/quality/cars/invite/${token}/attachments`, {
    method: "POST",
    headers: {
      ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
    },
    body: formData,
    credentials: "include",
  });

  if (res.status === 401) {
    handleAuthFailure("expired");
    throw new Error("Session expired. Please sign in again.");
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`QMS API ${res.status}: ${text || res.statusText}`);
  }
  return (await res.json()) as CARAttachmentOut;
}



export async function qmsListCarAttachments(carId: string): Promise<CARAttachmentOut[]> {
  return fetchJson<CARAttachmentOut[]>(`/quality/cars/${encodeURIComponent(carId)}/attachments`);
}

export async function qmsListCarAttachmentsBulk(params?: {
  car_ids?: string[];
}): Promise<CARAttachmentOut[]> {
  const qs = new URLSearchParams();
  (params?.car_ids ?? []).forEach((carId) => qs.append("car_ids", carId));
  const suffix = qs.toString() ? `?${qs.toString()}` : "";
  return fetchJson<CARAttachmentOut[]>(`/quality/cars/attachments/bulk${suffix}`);
}

export async function qmsUploadCarAttachment(carId: string, file: File): Promise<CARAttachmentOut> {
  const formData = new FormData();
  formData.append("file", file);
  const authToken = getToken();
  const res = await fetch(`${getApiBaseUrl()}/quality/cars/${encodeURIComponent(carId)}/attachments`, {
    method: "POST",
    headers: {
      ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
    },
    body: formData,
    credentials: "include",
  });
  if (res.status === 401) {
    handleAuthFailure("expired");
    throw new Error("Session expired. Please sign in again.");
  }
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`QMS API ${res.status}: ${text || res.statusText}`);
  }
  return (await res.json()) as CARAttachmentOut;
}

export async function qmsDeleteCarAttachment(carId: string, attachmentId: string): Promise<void> {
  await sendJson<void>(`/quality/cars/${encodeURIComponent(carId)}/attachments/${encodeURIComponent(attachmentId)}`, "DELETE", undefined);
}

export type QMSNotificationSeverity = "INFO" | "ACTION_REQUIRED" | "WARNING";

export interface QMSNotificationOut {
  id: string;
  user_id: string;
  message: string;
  severity: QMSNotificationSeverity;
  created_by_user_id: string | null;
  created_at: string;
  read_at: string | null;
}

export interface QMSNotificationSummaryOut {
  unread_count: number;
  latest_created_at: string | null;
}

export async function qmsListNotifications(params?: {
  include_read?: boolean;
  limit?: number;
}): Promise<QMSNotificationOut[]> {
  const suffix = toQuery({ include_read: params?.include_read ?? false, limit: params?.limit ?? 20 });
  return fetchJson<QMSNotificationOut[]>(`/quality/notifications/me${suffix}`);
}

export async function qmsGetNotificationSummary(): Promise<QMSNotificationSummaryOut> {
  const token = getToken();
  const headers = new Headers({
    Accept: "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  });
  const cachedEtag = readStoredNotificationSummaryEtag();
  if (cachedEtag) {
    headers.set("If-None-Match", cachedEtag);
  }

  const res = await fetch(`${API_BASE}/quality/notifications/me/summary`, {
    method: "GET",
    headers,
    credentials: "include",
  });

  if (res.status === 304) {
    return readStoredNotificationSummary() ?? { unread_count: 0, latest_created_at: null };
  }

  if (res.status === 401) {
    handleAuthFailure("expired");
    throw new Error("Session expired. Please sign in again.");
  }

  if (res.status === 503) {
    const text = await res.text().catch(() => "");
    throw new Error(text || "Service unavailable. Please retry or contact support.");
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    if (res.status === 403 && /subscription is locked|go to billing/i.test(text)) {
      return readStoredNotificationSummary() ?? { unread_count: 0, latest_created_at: null };
    }
    throw new Error(`QMS API ${res.status}: ${text || res.statusText}`);
  }

  const summary = (await res.json()) as QMSNotificationSummaryOut;
  writeStoredNotificationSummary(summary, res.headers.get("ETag"));
  return summary;
}

export async function qmsMarkAllNotificationsRead(): Promise<{ updated: number }> {
  return sendJson<{ updated: number }>("/quality/notifications/me/read-all", "POST", {});
}

export async function qmsMarkNotificationRead(notificationId: string): Promise<QMSNotificationOut> {
  return sendJson<QMSNotificationOut>(`/quality/notifications/${notificationId}/read`, "POST", {});
}

export interface AuditorStatsOut {
  user_id: string;
  audits_total: number;
  audits_open: number;
  audits_closed: number;
  lead_audits: number;
  observer_audits: number;
  assistant_audits: number;
}

export async function qmsGetAuditorStats(userId: string): Promise<AuditorStatsOut> {
  return fetchJson<AuditorStatsOut>(`/quality/auditors/${userId}/stats`);
}

export async function downloadAuditEvidencePack(auditId: string): Promise<Blob> {
  return downloadEvidencePack(`/quality/audits/${encodeURIComponent(auditId)}/evidence-pack`);
}

export async function downloadCarEvidencePack(carId: string): Promise<Blob> {
  return downloadEvidencePack(`/quality/cars/${encodeURIComponent(carId)}/evidence-pack`);
}
