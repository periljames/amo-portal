declare module "react-plotly.js";
declare module "plotly.js-dist-min";

declare module "react-plotly.js/factory";
