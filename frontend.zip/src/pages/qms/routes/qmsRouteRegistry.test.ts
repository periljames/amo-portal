import { describe, expect, it } from "vitest";

import {
  QMS_ROUTE_REGISTRY,
  classifyQmsPath,
  qmsModulePath,
  qmsNavigationItems,
  qmsRecordPath,
} from "./qmsRouteRegistry";

describe("QMS route registry", () => {
  it("keeps route ids and module segments unique", () => {
    expect(new Set(QMS_ROUTE_REGISTRY.map((route) => route.id)).size).toBe(QMS_ROUTE_REGISTRY.length);
    expect(new Set(QMS_ROUTE_REGISTRY.map((route) => route.segment)).size).toBe(QMS_ROUTE_REGISTRY.length);
  });

  it("requires complete navigation and access metadata", () => {
    for (const route of QMS_ROUTE_REGISTRY) {
      expect(route.id.trim()).not.toBe("");
      expect(route.label.trim()).not.toBe("");
      expect(route.navigationLabel.trim()).not.toBe("");
      expect(route.permission).toMatch(/^qms\.[a-z0-9_-]+\.view$/);
      expect(route.validViews.length).toBeGreaterThan(0);
      expect(route.validViews).toContain(route.defaultView);
      expect(new Set(route.validViews).size).toBe(route.validViews.length);
    }
  });

  it("builds canonical module and record links", () => {
    expect(qmsModulePath("SAF", "cars", "overdue")).toBe("/maintenance/SAF/quality/cars/overdue");
    expect(qmsRecordPath("SAF", "audits", "QAR-MO-26-002")).toBe("/maintenance/SAF/quality/audits/QAR-MO-26-002");
    expect(qmsRecordPath("Safari Link/AMO", "cars", "CAR-24+1", "overview")).toBe(
      "/maintenance/Safari%20Link%2FAMO/quality/cars/CAR-24%2B1/overview",
    );
    expect(qmsNavigationItems("SAF").find((item) => item.id === "audits")?.path).toBe("/maintenance/SAF/quality/audits/dashboard");
    expect(qmsNavigationItems("Safari Link/AMO").every((item) => item.path.startsWith("/maintenance/Safari%20Link%2FAMO/quality/"))).toBe(true);
  });

  it("classifies every registered default and child view as known", () => {
    for (const route of QMS_ROUTE_REGISTRY) {
      const defaultPath = `/maintenance/SAF/quality/${route.segment}`;
      expect(classifyQmsPath(defaultPath), defaultPath).toMatchObject({ kind: "known", module: route });

      for (const view of route.validViews) {
        const path = `/maintenance/SAF/quality/${route.segment}/${view}`;
        expect(classifyQmsPath(path), path).toMatchObject({ kind: "known", module: route });
        expect(qmsModulePath("SAF", route.id, view)).toBe(path);
      }
    }
  });

  it("recognises overview and specialist record workspaces", () => {
    expect(classifyQmsPath("/maintenance/SAF/quality").kind).toBe("overview");
    expect(classifyQmsPath("/maintenance/SAF/quality/audits/schedule").kind).toBe("known");
    expect(classifyQmsPath("/maintenance/SAF/quality/cars/91/overview").kind).toBe("known");
    expect(classifyQmsPath("/maintenance/SAF/quality/audits/2ad3f9c2-0bc9-431a-9e68-4b51f4ae5128/fieldwork").kind).toBe("known");
  });

  it("accepts human-readable audit and CAR references", () => {
    expect(classifyQmsPath("/maintenance/safarilink/quality/audits/QAR-MO-26-002?tab=war-room")).toMatchObject({
      kind: "known",
      amoCode: "safarilink",
      module: expect.objectContaining({ id: "audits" }),
    });
    expect(classifyQmsPath("/maintenance/SAF/quality/audits/QAR-MO-26-002/checklist").kind).toBe("known");
    expect(classifyQmsPath("/maintenance/SAF/quality/audits/schedules/AUD-SCH-2026-04").kind).toBe("known");
    expect(classifyQmsPath("/maintenance/SAF/quality/cars/CAR-2026-014/evidence").kind).toBe("known");
  });

  it("recognises controlled document reader routes in the registry", () => {
    expect(classifyQmsPath("/maintenance/SAF/quality/documents/reader/DOC-24/revisions/REV-3/view").kind).toBe("known");
    expect(classifyQmsPath("/maintenance/SAF/quality/documents/7f14b288/revisions/91/view").kind).toBe("known");
  });

  it("does not silently accept misspelled modules or views", () => {
    expect(classifyQmsPath("/maintenance/SAF/quality/carrs/overdue").kind).toBe("unknown");
    expect(classifyQmsPath("/maintenance/SAF/quality/cars/ovverdue").kind).toBe("unknown");
    expect(classifyQmsPath("/maintenance/SAF/quality/audits/schedul").kind).toBe("unknown");
    expect(classifyQmsPath("/maintenance/SAF/quality/findings/register/unexpected-tail").kind).toBe("unknown");
    expect(classifyQmsPath("/maintenance/SAF/quality/audits/QAR-MO-26-002/unregistered-stage").kind).toBe("unknown");
    expect(classifyQmsPath("/maintenance/SAF/quality/audits/%2E%2E?tab=war-room").kind).toBe("unknown");
  });

  it("maps intentional legacy aliases to canonical destinations", () => {
    expect(classifyQmsPath("/maintenance/SAF/qms")).toMatchObject({
      kind: "legacy",
      canonicalTarget: "/maintenance/SAF/quality",
    });
    expect(classifyQmsPath("/maintenance/SAF/quality/tasks")).toMatchObject({
      kind: "legacy",
      canonicalTarget: "/maintenance/SAF/quality/inbox/assigned-to-me",
    });
    expect(classifyQmsPath("/maintenance/SAF/quality/audits/programme")).toMatchObject({
      kind: "legacy",
      canonicalTarget: "/maintenance/SAF/quality/audits/program",
    });
  });
});
