// frontend/src/pages/AircraftImportPage.tsx
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import type {
  CellValueChangedEvent,
  ColDef,
  GridReadyEvent,
  ICellRendererParams,
} from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { authHeaders, getCachedUser } from "../services/auth";
import {
  getActiveAmoId as getAdminActiveAmoId,
  listAdminAmos,
  setActiveAmoId as setAdminActiveAmoId,
  type AdminAmoRead,
} from "../services/adminUsers";

import { getApiBaseUrl } from "../services/config";

const API_BASE = getApiBaseUrl();

type AircraftRowData = {
  serial_number: string;
  registration: string;
  template?: string | null;
  make?: string | null;
  model?: string | null;
  home_base?: string | null;
  owner?: string | null;
  aircraft_model_code?: string | null;
  operator_code?: string | null;
  supplier_code?: string | null;
  company_name?: string | null;
  internal_aircraft_identifier?: string | null;
  status?: string | null;
  is_active?: boolean | null;
  last_log_date?: string | null;
  total_hours?: number | string | null;
  total_cycles?: number | string | null;
};

type AircraftRowField = keyof AircraftRowData;

type PreviewRow = {
  row_number: number;
  data: AircraftRowData;
  errors: string[];
  warnings: string[];
  action: "new" | "update" | "invalid";
  approved: boolean;
  suggested_template?: SuggestedTemplate | null;
  original_data?: AircraftRowData;
  proposed_fields?: AircraftRowField[];
  user_overrides?: AircraftRowField[];
  formula_proposals?: FormulaProposal[];
  formula_decisions?: Partial<Record<AircraftRowField, FormulaDecision>>;
};

type ConfirmedCell = {
  original: any;
  proposed: any;
  final: any;
  decision?: FormulaDecision;
};

type ConfirmedRow = {
  row_number: number;
  cells: Record<string, ConfirmedCell>;
};

type SuggestedTemplate = {
  id: number;
  name: string;
  aircraft_template?: string | null;
  model_code?: string | null;
  operator_code?: string | null;
};

type FormulaProposal = {
  cell_address?: string | null;
  column_name: string;
  current_value: any;
  proposed_value: any;
  confidence?: string | null;
};

type FormulaDecision = "accept" | "keep" | "override";

type AircraftImportTemplate = {
  id: number;
  name: string;
  template_type?: string | null;
  aircraft_template?: string | null;
  model_code?: string | null;
  operator_code?: string | null;
  column_mapping?: Record<string, string | null> | null;
  default_values?: Record<string, any> | null;
};

type OcrPreview = {
  confidence?: number | null;
  samples?: string[];
  text?: string | null;
  file_type?: string | null;
};

type ComponentRowData = {
  position: string;
  ata?: string | null;
  part_number?: string | null;
  serial_number?: string | null;
  description?: string | null;
  installed_date?: string | null;
  installed_hours?: number | string | null;
  installed_cycles?: number | string | null;
  current_hours?: number | string | null;
  current_cycles?: number | string | null;
  notes?: string | null;
  manufacturer_code?: string | null;
  operator_code?: string | null;
};

type ComponentPreviewRow = {
  row_number: number;
  data: ComponentRowData;
  errors: string[];
  warnings: string[];
  action: "new" | "update" | "invalid";
  approved: boolean;
  existing_component?: {
    position?: string | null;
    part_number?: string | null;
    serial_number?: string | null;
  } | null;
  dedupe_suggestions?: {
    source: "file" | "existing" | "fleet";
    part_number: string;
    serial_number: string;
    positions?: string[];
    aircraft_serial_numbers?: string[];
  }[];
};

type ManualAircraftDraft = {
  serial_number: string;
  registration: string;
  template: string;
  make: string;
  model: string;
  home_base: string;
  owner: string;
  aircraft_model_code: string;
  operator_code: string;
  supplier_code: string;
  company_name: string;
  internal_aircraft_identifier: string;
  status: string;
  is_active: "" | "true" | "false";
  last_log_date: string;
  total_hours: string;
  total_cycles: string;
};

type ManualComponentDraft = {
  position: string;
  ata: string;
  part_number: string;
  serial_number: string;
  description: string;
  installed_date: string;
  installed_hours: string;
  installed_cycles: string;
  current_hours: string;
  current_cycles: string;
  notes: string;
  manufacturer_code: string;
  operator_code: string;
};

type ImportSnapshot = {
  id: number;
  batch_id: string;
  import_type: string;
  diff_map: Record<string, any>;
  created_at: string;
  created_by_user_id?: string | null;
};

const MAX_CLIENT_PREVIEW_ROWS = 1500;

const AIRCRAFT_DIFF_FIELDS: AircraftRowField[] = [
  "serial_number",
  "registration",
  "template",
  "make",
  "model",
  "home_base",
  "owner",
  "total_hours",
  "total_cycles",
  "last_log_date",
];

const AIRCRAFT_FIELD_LABELS: Record<AircraftRowField, string> = {
  serial_number: "Serial",
  registration: "Registration",
  template: "Template",
  make: "Make",
  model: "Model",
  home_base: "Base",
  owner: "Owner",
  aircraft_model_code: "Model Code",
  operator_code: "Operator Code",
  supplier_code: "Supplier Code",
  company_name: "Company Name",
  internal_aircraft_identifier: "Internal ID",
  status: "Status",
  is_active: "Active",
  last_log_date: "Last Log Date",
  total_hours: "Hours",
  total_cycles: "Cycles",
};

const FORMULA_TOLERANCE = 0.01;

const normalizeValue = (value: unknown) =>
  value === null || value === undefined ? "" : `${value}`.trim();

const normalizeHeader = (value: string) =>
  value
    .trim()
    .toLowerCase()
    .replace(/[.\-/\s]+/g, "_")
    .replace(/_+/g, "_");

const isSuperuser = (user: any): boolean => {
  if (!user) return false;
  return !!user.is_superuser || user.role === "SUPERUSER";
};

const emptyManualAircraftDraft: ManualAircraftDraft = {
  serial_number: "",
  registration: "",
  template: "",
  make: "",
  model: "",
  home_base: "",
  owner: "",
  aircraft_model_code: "",
  operator_code: "",
  supplier_code: "",
  company_name: "",
  internal_aircraft_identifier: "",
  status: "",
  is_active: "",
  last_log_date: "",
  total_hours: "",
  total_cycles: "",
};

const emptyManualComponentDraft: ManualComponentDraft = {
  position: "",
  ata: "",
  part_number: "",
  serial_number: "",
  description: "",
  installed_date: "",
  installed_hours: "",
  installed_cycles: "",
  current_hours: "",
  current_cycles: "",
  notes: "",
  manufacturer_code: "",
  operator_code: "",
};

type ImportSection = "aircraft" | "components";

type AircraftImportPageProps = {
  initialSection?: ImportSection;
};

const AircraftImportPage: React.FC<AircraftImportPageProps> = ({
  initialSection,
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { amoCode, department } = useParams<{
    amoCode?: string;
    department?: string;
  }>();
  const [aircraftFiles, setAircraftFiles] = useState<File[]>([]);
  const [componentsFiles, setComponentsFiles] = useState<File[]>([]);
  const [componentAircraftSerial, setComponentAircraftSerial] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [amoOptions, setAmoOptions] = useState<AdminAmoRead[]>([]);
  const [amoLoading, setAmoLoading] = useState(false);
  const [amoError, setAmoError] = useState<string | null>(null);
  const [selectedAmoId, setSelectedAmoId] = useState<string>("");
  const [previewLoading, setPreviewLoading] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [aircraftImportComplete, setAircraftImportComplete] = useState(false);
  const [componentImportComplete, setComponentImportComplete] = useState(false);
  const [previewRows, setPreviewRows] = useState<PreviewRow[]>([]);
  const [previewRowOverrides, setPreviewRowOverrides] = useState<
    Record<number, PreviewRow>
  >({});
  const [columnMapping, setColumnMapping] = useState<
    Record<string, string | null> | null
  >(null);
  const [ocrPreview, setOcrPreview] = useState<OcrPreview | null>(null);
  const [ocrTextDraft, setOcrTextDraft] = useState("");
  const [previewSummary, setPreviewSummary] = useState<{
    new: number;
    update: number;
    invalid: number;
  } | null>(null);
  const [templates, setTemplates] = useState<AircraftImportTemplate[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<number | "">("");
  const [templateName, setTemplateName] = useState("");
  const [templateAircraftTemplate, setTemplateAircraftTemplate] = useState("");
  const [templateModelCode, setTemplateModelCode] = useState("");
  const [templateOperatorCode, setTemplateOperatorCode] = useState("");
  const [templateDefaultsJson, setTemplateDefaultsJson] = useState("{}");
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [previewTotalRows, setPreviewTotalRows] = useState(0);
  const [previewMode, setPreviewMode] = useState<"client" | "server">("client");
  const [previewGridApi, setPreviewGridApi] = useState<any>(null);
  const [templateLoading, setTemplateLoading] = useState(false);
  const [componentPreviewLoading, setComponentPreviewLoading] = useState(false);
  const [componentConfirmLoading, setComponentConfirmLoading] = useState(false);
  const [componentPreviewRows, setComponentPreviewRows] = useState<
    ComponentPreviewRow[]
  >([]);
  const [componentPreviewRowOverrides, setComponentPreviewRowOverrides] =
    useState<Record<number, ComponentPreviewRow>>({});
  const [componentColumnMapping, setComponentColumnMapping] = useState<
    Record<string, string | null> | null
  >(null);
  const [componentSummary, setComponentSummary] = useState<{
    new: number;
    update: number;
    invalid: number;
  } | null>(null);
  const [componentTemplates, setComponentTemplates] = useState<
    AircraftImportTemplate[]
  >([]);
  const [componentSelectedTemplateId, setComponentSelectedTemplateId] =
    useState<number | "">("");
  const [componentTemplateName, setComponentTemplateName] = useState("");
  const [componentTemplateAircraftTemplate, setComponentTemplateAircraftTemplate] =
    useState("");
  const [componentTemplateModelCode, setComponentTemplateModelCode] =
    useState("");
  const [componentTemplateOperatorCode, setComponentTemplateOperatorCode] =
    useState("");
  const [componentTemplateDefaultsJson, setComponentTemplateDefaultsJson] =
    useState("{}");
  const [componentTemplateLoading, setComponentTemplateLoading] =
    useState(false);
  const [componentPreviewId, setComponentPreviewId] = useState<string | null>(
    null
  );
  const [componentPreviewTotalRows, setComponentPreviewTotalRows] = useState(0);
  const [componentPreviewMode, setComponentPreviewMode] = useState<
    "client" | "server"
  >("client");
  const [componentPreviewGridApi, setComponentPreviewGridApi] =
    useState<any>(null);
  const [manualAircraftDraft, setManualAircraftDraft] =
    useState<ManualAircraftDraft>(emptyManualAircraftDraft);
  const [manualComponentDraft, setManualComponentDraft] =
    useState<ManualComponentDraft>(emptyManualComponentDraft);
  const [importBatchId, setImportBatchId] = useState<string | null>(null);
  const [snapshots, setSnapshots] = useState<ImportSnapshot[]>([]);
  const [selectedSnapshotId, setSelectedSnapshotId] = useState<number | null>(
    null
  );
  const [snapshotLoading, setSnapshotLoading] = useState(false);
  const [snapshotActionLoading, setSnapshotActionLoading] = useState(false);

  const currentUser = getCachedUser();
  const userIsSuperuser = isSuperuser(currentUser);
  const currentDepartment = department || "planning";
  const sectionFromPath: ImportSection = location.pathname.includes(
    "/component-import"
  )
    ? "components"
    : "aircraft";
  const activeSection = initialSection ?? sectionFromPath;
  const showAircraft = activeSection === "aircraft";
  const showComponents = activeSection === "components";
  const sectionPathSegment =
    activeSection === "components" ? "component-import" : "aircraft-import";
  const aircraftImportUrl = amoCode
    ? `/maintenance/${amoCode}/${currentDepartment}/aircraft-import`
    : "";
  const componentImportUrl = amoCode
    ? `/maintenance/${amoCode}/${currentDepartment}/component-import`
    : "";

  const handleAircraftFileChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const files = Array.from(e.target.files ?? []);
    if (files.length > 10) {
      setMessage("Upload up to 10 aircraft files at a time.");
      setAircraftFiles(files.slice(0, 10));
    } else {
      setAircraftFiles(files);
    }
    setAircraftImportComplete(false);
  };

  const handleComponentsFileChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const files = Array.from(e.target.files ?? []);
    if (files.length > 10) {
      setMessage("Upload up to 10 component files at a time.");
      setComponentsFiles(files.slice(0, 10));
    } else {
      setComponentsFiles(files);
    }
    setComponentImportComplete(false);
  };

  const handleAmoChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const nextId = event.target.value;
    setSelectedAmoId(nextId);
    if (nextId) {
      setAdminActiveAmoId(nextId);
    }
    const amo = amoOptions.find((entry) => entry.id === nextId);
    if (amo?.login_slug) {
      navigate(
        `/maintenance/${amo.login_slug}/${currentDepartment}/${sectionPathSegment}`
      );
    }
  };

  const validateRow = (data: AircraftRowData) => {
    const errors: string[] = [];
    if (!data.serial_number?.trim() && !data.registration?.trim()) {
      errors.push("Missing serial and registration.");
    } else if (!data.serial_number?.trim()) {
      errors.push("Missing serial number.");
    } else if (!data.registration?.trim()) {
      errors.push("Missing registration.");
    }
    return errors;
  };

  const hasErrors = (row: PreviewRow) => row.errors.length > 0;

  const normalizePreviewRow = (row: PreviewRow): PreviewRow => ({
    ...row,
    approved: row.errors.length === 0,
    original_data: { ...row.data },
    proposed_fields: row.proposed_fields ?? [],
    user_overrides: row.user_overrides ?? [],
    formula_proposals: row.formula_proposals ?? [],
    formula_decisions: row.formula_decisions ?? {},
  });

  const mergePreviewOverride = (row: PreviewRow): PreviewRow => {
    const override = previewRowOverrides[row.row_number];
    if (!override) {
      return row;
    }
    return {
      ...row,
      ...override,
      data: { ...row.data, ...override.data },
      errors: override.errors ?? row.errors,
      warnings: override.warnings ?? row.warnings,
      approved: override.approved ?? row.approved,
      original_data: override.original_data ?? row.original_data,
      proposed_fields: override.proposed_fields ?? row.proposed_fields,
      user_overrides: override.user_overrides ?? row.user_overrides,
      formula_decisions: override.formula_decisions ?? row.formula_decisions,
      formula_proposals: override.formula_proposals ?? row.formula_proposals,
    };
  };

  const normalizeComponentPreviewRow = (
    row: ComponentPreviewRow
  ): ComponentPreviewRow => ({
    ...row,
    approved: row.errors.length === 0,
  });

  const mergeComponentPreviewOverride = (
    row: ComponentPreviewRow
  ): ComponentPreviewRow => {
    const override = componentPreviewRowOverrides[row.row_number];
    if (!override) {
      return row;
    }
    return {
      ...row,
      ...override,
      data: { ...row.data, ...override.data },
      errors: override.errors ?? row.errors,
      warnings: override.warnings ?? row.warnings,
      approved: override.approved ?? row.approved,
      existing_component: override.existing_component ?? row.existing_component,
      dedupe_suggestions: override.dedupe_suggestions ?? row.dedupe_suggestions,
    };
  };

  const validateComponentRow = (data: ComponentRowData) => {
    const errors: string[] = [];
    if (!data.position?.trim()) {
      errors.push("Missing component position.");
    }
    return errors;
  };

  const hasComponentErrors = (row: ComponentPreviewRow) =>
    row.errors.length > 0;

  const getNextRowNumber = (rows: { row_number: number }[]) => {
    if (rows.length === 0) return 1;
    return rows.reduce((max, row) => Math.max(max, row.row_number), 0) + 1;
  };

  const loadTemplates = async () => {
    try {
      const res = await fetch(
        `${getApiBaseUrl()}/aircraft/import/templates?template_type=aircraft`,
        { headers: authHeaders() }
      );
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail ?? "Failed to load templates.");
      }
      setTemplates(data ?? []);
    } catch (err: any) {
      setMessage(err.message ?? "Error loading templates.");
    }
  };

  const loadComponentTemplates = async () => {
    try {
      const res = await fetch(
        `${getApiBaseUrl()}/aircraft/import/templates?template_type=components`,
        { headers: authHeaders() }
      );
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail ?? "Failed to load component templates.");
      }
      setComponentTemplates(data ?? []);
    } catch (err: any) {
      setMessage(err.message ?? "Error loading component templates.");
    }
  };

  useEffect(() => {
    void loadTemplates();
    void loadComponentTemplates();
  }, []);

  useEffect(() => {
    if (!userIsSuperuser) return;
    let active = true;

    const loadAmos = async () => {
      setAmoLoading(true);
      setAmoError(null);
      try {
        const data = await listAdminAmos();
        if (!active) return;
        setAmoOptions(data ?? []);
      } catch (err: any) {
        if (!active) return;
        setAmoError(err?.message ?? "Could not load AMO list.");
      } finally {
        if (active) setAmoLoading(false);
      }
    };

    void loadAmos();
    return () => {
      active = false;
    };
  }, [userIsSuperuser]);

  useEffect(() => {
    if (!userIsSuperuser || amoOptions.length === 0) return;
    const storedAmoId = getAdminActiveAmoId();
    const matchBySlug = amoCode
      ? amoOptions.find((amo) => amo.login_slug === amoCode)
      : undefined;
    const nextId = storedAmoId || matchBySlug?.id || amoOptions[0]?.id || "";
    if (nextId && nextId !== selectedAmoId) {
      setSelectedAmoId(nextId);
      setAdminActiveAmoId(nextId);
    }
  }, [userIsSuperuser, amoOptions, amoCode, selectedAmoId]);

  useEffect(() => {
    if (selectedTemplateId === "") {
      setTemplateName("");
      setTemplateAircraftTemplate("");
      setTemplateModelCode("");
      setTemplateOperatorCode("");
      setTemplateDefaultsJson("{}");
      return;
    }
    const selected = templates.find(
      (template) => template.id === selectedTemplateId
    );
    if (!selected) {
      return;
    }
    setTemplateName(selected.name ?? "");
    setTemplateAircraftTemplate(selected.aircraft_template ?? "");
    setTemplateModelCode(selected.model_code ?? "");
    setTemplateOperatorCode(selected.operator_code ?? "");
    setTemplateDefaultsJson(
      JSON.stringify(selected.default_values ?? {}, null, 2)
    );
  }, [selectedTemplateId, templates]);

  useEffect(() => {
    if (componentSelectedTemplateId === "") {
      setComponentTemplateName("");
      setComponentTemplateAircraftTemplate("");
      setComponentTemplateModelCode("");
      setComponentTemplateOperatorCode("");
      setComponentTemplateDefaultsJson("{}");
      return;
    }
    const selected = componentTemplates.find(
      (template) => template.id === componentSelectedTemplateId
    );
    if (!selected) {
      return;
    }
    setComponentTemplateName(selected.name ?? "");
    setComponentTemplateAircraftTemplate(selected.aircraft_template ?? "");
    setComponentTemplateModelCode(selected.model_code ?? "");
    setComponentTemplateOperatorCode(selected.operator_code ?? "");
    setComponentTemplateDefaultsJson(
      JSON.stringify(selected.default_values ?? {}, null, 2)
    );
  }, [componentSelectedTemplateId, componentTemplates]);

  const updatePreviewRowValue = (
    rowNumber: number,
    field: AircraftRowField,
    value: any,
    source: "user" | "system" = "user",
    decision?: FormulaDecision,
    rowContext?: PreviewRow
  ) => {
    const applyUpdate = (row: PreviewRow) => {
      const nextData = {
        ...row.data,
        [field]: value,
      };
      const errors = validateRow(nextData);
      const originalValue = normalizeValue(row.original_data?.[field]);
      const userOverrides = new Set(row.user_overrides ?? []);
      if (source === "user") {
        if (normalizeValue(value) === originalValue) {
          userOverrides.delete(field);
        } else {
          userOverrides.add(field);
        }
      }
      const formulaDecisions = { ...(row.formula_decisions ?? {}) };
      if (decision) {
        formulaDecisions[field] = decision;
      }
      return {
        ...row,
        data: nextData,
        errors,
        approved: errors.length === 0 && row.approved,
        user_overrides: Array.from(userOverrides),
        formula_decisions: formulaDecisions,
      };
    };

    if (previewMode === "client") {
      setPreviewRows((prev) =>
        prev.map((row) => {
          if (row.row_number !== rowNumber) {
            return row;
          }
          return applyUpdate(row);
        })
      );
      return;
    }

    if (!rowContext) {
      return;
    }
    setPreviewRowOverrides((prev) => ({
      ...prev,
      [rowNumber]: applyUpdate(rowContext),
    }));
  };

  const updateComponentPreviewRowValue = (
    rowNumber: number,
    field: keyof ComponentRowData,
    value: any,
    rowContext?: ComponentPreviewRow
  ) => {
    const applyUpdate = (row: ComponentPreviewRow) => {
      const nextData = {
        ...row.data,
        [field]: value,
      };
      const errors = validateComponentRow(nextData);
      return {
        ...row,
        data: nextData,
        errors,
        approved: errors.length === 0 && row.approved,
      };
    };

    if (componentPreviewMode === "client") {
      setComponentPreviewRows((prev) =>
        prev.map((row) => {
          if (row.row_number !== rowNumber) {
            return row;
          }
          return applyUpdate(row);
        })
      );
      return;
    }

    if (!rowContext) {
      return;
    }
    setComponentPreviewRowOverrides((prev) => ({
      ...prev,
      [rowNumber]: applyUpdate(rowContext),
    }));
  };

  const toggleApproval = (row: PreviewRow) => {
    if (hasErrors(row)) {
      return;
    }
    if (previewMode === "client") {
      setPreviewRows((prev) =>
        prev.map((entry) => {
          if (entry.row_number !== row.row_number) {
            return entry;
          }
          return {
            ...entry,
            approved: !entry.approved,
          };
        })
      );
      return;
    }
    setPreviewRowOverrides((prev) => ({
      ...prev,
      [row.row_number]: {
        ...row,
        approved: !row.approved,
      },
    }));
  };

  const toggleComponentApproval = (row: ComponentPreviewRow) => {
    if (hasComponentErrors(row)) {
      return;
    }
    if (componentPreviewMode === "client") {
      setComponentPreviewRows((prev) =>
        prev.map((entry) => {
          if (entry.row_number !== row.row_number) {
            return entry;
          }
          return {
            ...entry,
            approved: !entry.approved,
          };
        })
      );
      return;
    }
    setComponentPreviewRowOverrides((prev) => ({
      ...prev,
      [row.row_number]: {
        ...row,
        approved: !row.approved,
      },
    }));
  };

  const submitPreviewFiles = async (files: File[]) => {
    setPreviewLoading(true);
    setMessage(null);

    const formData = new FormData();
    files.forEach((upload) => {
      formData.append("files", upload);
    });

    try {
      const res = await fetch(`${getApiBaseUrl()}/aircraft/import/preview`, {
        method: "POST",
        headers: authHeaders(),
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail ?? "Preview failed");
      }
      const rows: PreviewRow[] = (data.rows ?? []).map((row: PreviewRow) =>
        normalizePreviewRow(row)
      );
      const totalRows = data.total_rows ?? rows.length;
      const nextMode =
        totalRows > MAX_CLIENT_PREVIEW_ROWS ? "server" : "client";
      setPreviewRows(rows);
      setPreviewRowOverrides({});
      setPreviewId(data.preview_id ?? null);
      setPreviewTotalRows(totalRows);
      setPreviewMode(nextMode);
      const nextBatchId = generateBatchId();
      setImportBatchId(nextBatchId);
      setSnapshots([]);
      setSelectedSnapshotId(null);
      setColumnMapping(data.column_mapping ?? null);
      setPreviewSummary(data.summary ?? null);
      setOcrPreview(data.ocr ?? null);
      setOcrTextDraft(data.ocr?.text ?? "");
      setMessage("Preview ready. Review and confirm import.");
    } catch (err: any) {
      setMessage(err.message ?? "Error previewing aircraft.");
      setPreviewId(null);
      setPreviewTotalRows(0);
      setPreviewMode("client");
      setPreviewRows([]);
      setPreviewRowOverrides({});
    } finally {
      setPreviewLoading(false);
    }
  };

  const createPreviewDatasource = useCallback(
    () => ({
      getRows: async (params: {
        startRow: number;
        endRow: number;
        successCallback: (rows: PreviewRow[], lastRow?: number) => void;
        failCallback: () => void;
      }) => {
        if (!previewId) {
          params.successCallback([], 0);
          return;
        }
        const startRow = params.startRow ?? 0;
        const endRow = params.endRow ?? startRow + 200;
        const limit = Math.max(1, endRow - startRow);
        try {
          const res = await fetch(
            `${API_BASE}/aircraft/import/preview/${encodeURIComponent(
              previewId
            )}/rows?offset=${startRow}&limit=${limit}`
          );
          const data = await res.json();
          if (!res.ok) {
            throw new Error(data.detail ?? "Failed to fetch preview rows.");
          }
          const rows: PreviewRow[] = (data.rows ?? [])
            .map((row: PreviewRow) => normalizePreviewRow(row))
            .map((row: PreviewRow) => mergePreviewOverride(row));
          const totalRows = data.total_rows ?? 0;
          params.successCallback(rows, totalRows);
        } catch (err) {
          params.failCallback();
        }
      },
    }),
    [previewId, previewRowOverrides]
  );

  useEffect(() => {
    if (previewMode === "server" && previewGridApi) {
      const api = previewGridApi as any;
      api.setDatasource?.(createPreviewDatasource());
    }
  }, [previewMode, previewGridApi, createPreviewDatasource]);

  const handlePreviewGridReady = useCallback(
    (params: GridReadyEvent) => {
      setPreviewGridApi(params.api);
      if (previewMode === "server") {
        const api = params.api as any;
        api.setDatasource?.(createPreviewDatasource());
      }
    },
    [previewMode, createPreviewDatasource]
  );

  const createComponentPreviewDatasource = useCallback(
    () => ({
      getRows: async (params: {
        startRow: number;
        endRow: number;
        successCallback: (rows: ComponentPreviewRow[], lastRow?: number) => void;
        failCallback: () => void;
      }) => {
        if (!componentPreviewId) {
          params.successCallback([], 0);
          return;
        }
        const startRow = params.startRow ?? 0;
        const endRow = params.endRow ?? startRow + 200;
        const limit = Math.max(1, endRow - startRow);
        try {
          const res = await fetch(
            `${API_BASE}/aircraft/${encodeURIComponent(
              componentAircraftSerial.trim()
            )}/components/import/preview/${encodeURIComponent(
              componentPreviewId
            )}/rows?offset=${startRow}&limit=${limit}`
          );
          const data = await res.json();
          if (!res.ok) {
            throw new Error(data.detail ?? "Failed to fetch component preview.");
          }
          const rows: ComponentPreviewRow[] = (data.rows ?? [])
            .map((row: ComponentPreviewRow) => normalizeComponentPreviewRow(row))
            .map((row: ComponentPreviewRow) => mergeComponentPreviewOverride(row));
          const totalRows = data.total_rows ?? 0;
          params.successCallback(rows, totalRows);
        } catch (err) {
          params.failCallback();
        }
      },
    }),
    [componentPreviewId, componentPreviewRowOverrides, componentAircraftSerial]
  );

  useEffect(() => {
    if (componentPreviewMode === "server" && componentPreviewGridApi) {
      const api = componentPreviewGridApi as any;
      api.setDatasource?.(createComponentPreviewDatasource());
    }
  }, [
    componentPreviewMode,
    componentPreviewGridApi,
    createComponentPreviewDatasource,
  ]);

  const handleComponentGridReady = useCallback(
    (params: GridReadyEvent) => {
      setComponentPreviewGridApi(params.api);
      if (componentPreviewMode === "server") {
        const api = params.api as any;
        api.setDatasource?.(createComponentPreviewDatasource());
      }
    },
    [componentPreviewMode, createComponentPreviewDatasource]
  );

  const submitComponentPreviewFile = async (uploads: File[]) => {
    if (!componentAircraftSerial.trim()) {
      setMessage("Enter the aircraft serial number for components.");
      return;
    }
    setComponentPreviewLoading(true);
    setMessage(null);

    const formData = new FormData();
    uploads.forEach((upload) => {
      formData.append("files", upload);
    });

    try {
      const res = await fetch(
        `${getApiBaseUrl()}/aircraft/${encodeURIComponent(
          componentAircraftSerial.trim()
        )}/components/import/preview`,
        {
          method: "POST",
          headers: authHeaders(),
          body: formData,
        }
      );

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail ?? "Component preview failed");
      }
      const rows: ComponentPreviewRow[] = (data.rows ?? []).map(
        (row: ComponentPreviewRow) => normalizeComponentPreviewRow(row)
      );
      const totalRows = data.total_rows ?? rows.length;
      const nextMode =
        totalRows > MAX_CLIENT_PREVIEW_ROWS ? "server" : "client";
      setComponentPreviewRows(rows);
      setComponentPreviewRowOverrides({});
      setComponentPreviewId(data.preview_id ?? null);
      setComponentPreviewTotalRows(totalRows);
      setComponentPreviewMode(nextMode);
      setComponentColumnMapping(data.column_mapping ?? null);
      setComponentSummary(data.summary ?? null);
      setMessage("Component preview ready. Review and confirm import.");
    } catch (err: any) {
      setMessage(err.message ?? "Error previewing components.");
      setComponentPreviewId(null);
      setComponentPreviewTotalRows(0);
      setComponentPreviewMode("client");
      setComponentPreviewRows([]);
      setComponentPreviewRowOverrides({});
    } finally {
      setComponentPreviewLoading(false);
    }
  };

  const parseAircraftFile = async () => {
    if (aircraftFiles.length === 0) {
      setMessage("Select up to 10 aircraft files first.");
      return;
    }
    setAircraftImportComplete(false);
    await submitPreviewFiles(aircraftFiles);
  };

  const loadSnapshotHistory = async (batchId: string | null) => {
    if (!batchId) {
      return;
    }
    setSnapshotLoading(true);
    try {
      const res = await fetch(
        `${getApiBaseUrl()}/aircraft/import/snapshots?batch_id=${encodeURIComponent(
          batchId
        )}`,
        { headers: authHeaders() }
      );
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail ?? "Failed to load snapshots.");
      }
      setSnapshots(data ?? []);
      setSelectedSnapshotId((data?.[0]?.id as number | undefined) ?? null);
    } catch (err: any) {
      setMessage(err.message ?? "Error loading snapshots.");
    } finally {
      setSnapshotLoading(false);
    }
  };

  useEffect(() => {
    if (importBatchId) {
      loadSnapshotHistory(importBatchId);
    }
  }, [importBatchId]);

  const parseComponentsFile = async () => {
    if (componentsFiles.length === 0) {
      setMessage("Select up to 10 component files first.");
      return;
    }
    setComponentImportComplete(false);
    await submitComponentPreviewFile(componentsFiles);
  };

  const handleAddManualAircraftRow = () => {
    const nextRowNumber = getNextRowNumber(previewRows);
    const nextData: AircraftRowData = {
      serial_number: manualAircraftDraft.serial_number,
      registration: manualAircraftDraft.registration,
      template: manualAircraftDraft.template || null,
      make: manualAircraftDraft.make || null,
      model: manualAircraftDraft.model || null,
      home_base: manualAircraftDraft.home_base || null,
      owner: manualAircraftDraft.owner || null,
      aircraft_model_code: manualAircraftDraft.aircraft_model_code || null,
      operator_code: manualAircraftDraft.operator_code || null,
      supplier_code: manualAircraftDraft.supplier_code || null,
      company_name: manualAircraftDraft.company_name || null,
      internal_aircraft_identifier:
        manualAircraftDraft.internal_aircraft_identifier || null,
      status: manualAircraftDraft.status || null,
      is_active:
        manualAircraftDraft.is_active === ""
          ? null
          : manualAircraftDraft.is_active === "true",
      last_log_date: manualAircraftDraft.last_log_date || null,
      total_hours: manualAircraftDraft.total_hours || null,
      total_cycles: manualAircraftDraft.total_cycles || null,
    };
    const errors = validateRow(nextData);
    setPreviewRows((prev) => [
      ...prev,
      {
        row_number: nextRowNumber,
        data: nextData,
        errors,
        warnings: [],
        action: "new",
        approved: errors.length === 0,
        original_data: { ...nextData },
        proposed_fields: [],
        user_overrides: [],
      },
    ]);
    setManualAircraftDraft(emptyManualAircraftDraft);
  };

  const handleAddManualComponentRow = () => {
    const nextRowNumber = getNextRowNumber(componentPreviewRows);
    const nextData: ComponentRowData = {
      position: manualComponentDraft.position,
      ata: manualComponentDraft.ata || null,
      part_number: manualComponentDraft.part_number || null,
      serial_number: manualComponentDraft.serial_number || null,
      description: manualComponentDraft.description || null,
      installed_date: manualComponentDraft.installed_date || null,
      installed_hours: manualComponentDraft.installed_hours || null,
      installed_cycles: manualComponentDraft.installed_cycles || null,
      current_hours: manualComponentDraft.current_hours || null,
      current_cycles: manualComponentDraft.current_cycles || null,
      notes: manualComponentDraft.notes || null,
      manufacturer_code: manualComponentDraft.manufacturer_code || null,
      operator_code: manualComponentDraft.operator_code || null,
    };
    const errors = validateComponentRow(nextData);
    setComponentPreviewRows((prev) => [
      ...prev,
      {
        row_number: nextRowNumber,
        data: nextData,
        errors,
        warnings: [],
        action: "new",
        approved: errors.length === 0,
      },
    ]);
    setManualComponentDraft(emptyManualComponentDraft);
  };

  const reparseOcrText = async () => {
    if (!ocrTextDraft.trim()) {
      setMessage("Add corrected OCR text before re-parsing.");
      return;
    }
    setAircraftImportComplete(false);
    const ocrFile = new File([ocrTextDraft], "ocr-corrected.csv", {
      type: "text/csv",
    });
    await submitPreviewFiles([ocrFile]);
  };

  const parseTemplateDefaults = () => {
    const raw = templateDefaultsJson.trim();
    if (!raw) {
      return null;
    }
    try {
      return JSON.parse(raw);
    } catch (err) {
      throw new Error("Default values JSON is invalid.");
    }
  };

  const parseComponentTemplateDefaults = () => {
    const raw = componentTemplateDefaultsJson.trim();
    if (!raw) {
      return null;
    }
    try {
      return JSON.parse(raw);
    } catch (err) {
      throw new Error("Component default values JSON is invalid.");
    }
  };

  const generateBatchId = () => {
    if (typeof crypto !== "undefined" && crypto.randomUUID) {
      return crypto.randomUUID();
    }
    return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  };

  const saveMappingTemplate = async () => {
    if (!columnMapping) {
      setMessage("Parse a file to generate a column mapping before saving.");
      return;
    }
    const name =
      templateName.trim() ||
      templates.find((template) => template.id === selectedTemplateId)?.name ||
      "";
    if (!name) {
      setMessage("Enter a template name.");
      return;
    }

    setTemplateLoading(true);
    setMessage(null);
    try {
      const defaultValues = parseTemplateDefaults();
      const payload = {
        name,
        template_type: "aircraft",
        aircraft_template: templateAircraftTemplate.trim() || null,
        model_code: templateModelCode.trim() || null,
        operator_code: templateOperatorCode.trim() || null,
        column_mapping: columnMapping,
        default_values: defaultValues,
      };
      const method = selectedTemplateId ? "PUT" : "POST";
      const url = selectedTemplateId
        ? `${getApiBaseUrl()}/aircraft/import/templates/${selectedTemplateId}`
        : `${getApiBaseUrl()}/aircraft/import/templates`;
      const res = await fetch(url, {
        method,
        headers: authHeaders({ "Content-Type": "application/json" }),
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail ?? "Failed to save template.");
      }
      await loadTemplates();
      setSelectedTemplateId(data.id ?? selectedTemplateId);
      setMessage("Template saved.");
    } catch (err: any) {
      setMessage(err.message ?? "Error saving template.");
    } finally {
      setTemplateLoading(false);
    }
  };

  const saveComponentTemplate = async () => {
    if (!componentColumnMapping) {
      setMessage(
        "Parse a file to generate a component column mapping before saving."
      );
      return;
    }
    const name =
      componentTemplateName.trim() ||
      componentTemplates.find(
        (template) => template.id === componentSelectedTemplateId
      )?.name ||
      "";
    if (!name) {
      setMessage("Enter a template name for components.");
      return;
    }

    setComponentTemplateLoading(true);
    setMessage(null);
    try {
      const defaultValues = parseComponentTemplateDefaults();
      const payload = {
        name,
        template_type: "components",
        aircraft_template: componentTemplateAircraftTemplate.trim() || null,
        model_code: componentTemplateModelCode.trim() || null,
        operator_code: componentTemplateOperatorCode.trim() || null,
        column_mapping: componentColumnMapping,
        default_values: defaultValues,
      };
      const method = componentSelectedTemplateId ? "PUT" : "POST";
      const url = componentSelectedTemplateId
        ? `${getApiBaseUrl()}/aircraft/import/templates/${componentSelectedTemplateId}`
        : `${getApiBaseUrl()}/aircraft/import/templates`;
      const res = await fetch(url, {
        method,
        headers: authHeaders({ "Content-Type": "application/json" }),
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail ?? "Failed to save component template.");
      }
      await loadComponentTemplates();
      setComponentSelectedTemplateId(data.id ?? componentSelectedTemplateId);
      setMessage("Component template saved.");
    } catch (err: any) {
      setMessage(err.message ?? "Error saving component template.");
    } finally {
      setComponentTemplateLoading(false);
    }
  };

  const formulaFieldMapping = useMemo(() => {
    const mapping = new Map<string, AircraftRowField>();
    if (!columnMapping) {
      return mapping;
    }
    (Object.entries(columnMapping) as [AircraftRowField, string | null][]).forEach(
      ([field, columnName]) => {
        if (!columnName) {
          return;
        }
        mapping.set(normalizeHeader(columnName), field);
      }
    );
    return mapping;
  }, [columnMapping]);

  const getFormulaProposalForField = (
    row: PreviewRow,
    field: AircraftRowField
  ) => {
    const proposals = row.formula_proposals ?? [];
    return proposals.find(
      (proposal) => {
        const normalized = normalizeHeader(proposal.column_name);
        const mappedField = formulaFieldMapping.get(normalized);
        if (mappedField) {
          return mappedField === field;
        }
        return normalized === normalizeHeader(field);
      }
    );
  };

  const applyFormulaDecision = (
    rowNumber: number,
    field: AircraftRowField,
    decision: FormulaDecision,
    value: any,
    rowContext?: PreviewRow
  ) => {
    updatePreviewRowValue(
      rowNumber,
      field,
      value ?? "",
      "user",
      decision,
      rowContext
    );
  };

  const buildFormulaDecision = (
    row: PreviewRow,
    field: AircraftRowField
  ): FormulaDecision | undefined => {
    const proposal = getFormulaProposalForField(row, field);
    if (!proposal) {
      return undefined;
    }
    const existing = row.formula_decisions?.[field];
    if (existing) {
      return existing;
    }
    const original = normalizeValue(row.original_data?.[field]);
    const proposed = normalizeValue(proposal.proposed_value);
    const finalValue = normalizeValue(row.data[field]);
    if (finalValue === proposed) {
      return "accept";
    }
    if (finalValue === original) {
      return "keep";
    }
    return "override";
  };

  const renderFormulaCell =
    (field: AircraftRowField) =>
    (params: ICellRendererParams<PreviewRow>) => {
      const row = params.data;
      if (!row) {
        return null;
      }
      const proposal = getFormulaProposalForField(row, field);
      if (!proposal) {
        return <span>{normalizeValue(row.data[field])}</span>;
      }
      const uploadedValue = row.original_data?.[field];
      const currentValue = row.data[field];
      const proposedValue = proposal.proposed_value;
      const delta =
        typeof uploadedValue === "number" && typeof proposedValue === "number"
          ? proposedValue - uploadedValue
          : Number.isFinite(Number(proposedValue)) &&
            Number.isFinite(Number(uploadedValue))
          ? Number(proposedValue) - Number(uploadedValue)
          : null;
      const decision = buildFormulaDecision(row, field);
      const withinTolerance =
        delta !== null && Math.abs(delta) <= FORMULA_TOLERANCE;
      return (
        <div className="flex flex-col gap-1 text-xs">
          <div className="flex flex-wrap items-center gap-1">
            <span className="rounded-full bg-amber-500/20 px-2 py-0.5 text-amber-200">
              Formula mismatch
            </span>
            {decision && (
              <span className="rounded-full bg-slate-700 px-2 py-0.5 text-slate-200">
                Decision: {decision}
              </span>
            )}
          </div>
          <div className="text-slate-100">
            Uploaded: {normalizeValue(uploadedValue) || "—"}
          </div>
          <div className="text-sky-300">
            Recalc: {normalizeValue(proposedValue) || "—"}
          </div>
          {normalizeValue(currentValue) !== normalizeValue(uploadedValue) &&
            normalizeValue(currentValue) !== normalizeValue(proposedValue) && (
              <div className="text-fuchsia-200">
                Final: {normalizeValue(currentValue) || "—"}
              </div>
            )}
          <div
            className={`text-xs ${
              withinTolerance ? "text-amber-200" : "text-rose-200"
            }`}
          >
            Δ{" "}
            {delta === null
              ? "n/a"
              : `${delta > 0 ? "+" : ""}${delta.toFixed(2)}`}{" "}
            <span className="text-slate-400">(tol ±{FORMULA_TOLERANCE})</span>
          </div>
          <div className="flex flex-wrap gap-2 text-xs">
            <button
              type="button"
              className="rounded-full bg-sky-500/20 px-2 py-0.5 text-sky-200"
              onClick={() =>
                applyFormulaDecision(
                  row.row_number,
                  field,
                  "accept",
                  proposedValue,
                  params.data ?? undefined
                )
              }
            >
              Accept
            </button>
            <button
              type="button"
              className="rounded-full bg-slate-700 px-2 py-0.5 text-slate-200"
              onClick={() =>
                applyFormulaDecision(
                  row.row_number,
                  field,
                  "keep",
                  row.original_data?.[field] ?? "",
                  params.data ?? undefined
                )
              }
            >
              Keep
            </button>
            <button
              type="button"
              className="rounded-full bg-fuchsia-500/20 px-2 py-0.5 text-fuchsia-200"
              onClick={() => {
                const colId = params.column?.getColId();
                if (!colId) {
                  return;
                }
                params.api.startEditingCell({
                  rowIndex: params.node?.rowIndex ?? 0,
                  colKey: colId,
                });
              }}
            >
              Override
            </button>
          </div>
        </div>
      );
    };

  const applyTemplateToPreview = () => {
    if (previewMode === "server") {
      setMessage(
        "Template defaults are disabled in large preview mode. Apply defaults in the source file instead."
      );
      return;
    }
    const selected = templates.find(
      (template) => template.id === selectedTemplateId
    );
    if (!selected) {
      setMessage("Select a template to apply.");
      return;
    }
    setPreviewRows((prev) =>
      prev.map((row) => {
        const nextData = { ...row.data };
        const defaults =
          (selected.default_values ?? {}) as Partial<AircraftRowData>;
        const proposedFields = new Set(row.proposed_fields ?? []);

        if (selected.aircraft_template && !nextData.template?.trim()) {
          nextData.template = selected.aircraft_template;
        }
        if (selected.model_code && !nextData.aircraft_model_code?.trim()) {
          nextData.aircraft_model_code = selected.model_code;
        }
        if (selected.operator_code && !nextData.operator_code?.trim()) {
          nextData.operator_code = selected.operator_code;
        }

        const applyDefault = <K extends AircraftRowField,>(
          key: K,
          value: AircraftRowData[K]
        ) => {
          if (value === null || value === undefined) {
            return;
          }
          const currentValue = nextData[key];
          if (
            currentValue === null ||
            currentValue === undefined ||
            `${currentValue}`.trim() === ""
          ) {
            nextData[key] = value;
          }
        };

        (
          Object.entries(defaults) as Array<
            [AircraftRowField, AircraftRowData[AircraftRowField]]
          >
        ).forEach(([key, value]) => {
          applyDefault(key, value);
        });

        AIRCRAFT_DIFF_FIELDS.forEach((field) => {
          if (
            normalizeValue(row.data[field]) === "" &&
            normalizeValue(nextData[field]) !== ""
          ) {
            proposedFields.add(field);
          }
        });

        const errors = validateRow(nextData);
        return {
          ...row,
          data: nextData,
          errors,
          approved: errors.length === 0 && row.approved,
          proposed_fields: Array.from(proposedFields),
        };
      })
    );
    setMessage("Template defaults applied to preview rows.");
  };

  const applyComponentTemplateToPreview = () => {
    if (componentPreviewMode === "server") {
      setMessage(
        "Template defaults are disabled in large preview mode. Apply defaults in the source file instead."
      );
      return;
    }
    const selected = componentTemplates.find(
      (template) => template.id === componentSelectedTemplateId
    );
    if (!selected) {
      setMessage("Select a component template to apply.");
      return;
    }
    setComponentPreviewRows((prev) =>
      prev.map((row) => {
        const nextData = { ...row.data };
        const defaults = selected.default_values ?? {};

        (Object.entries(defaults) as [keyof ComponentRowData, any][]).forEach(
          ([key, value]) => {
            if (value === null || value === undefined) {
              return;
            }
            const currentValue = nextData[key];
            if (
              currentValue === null ||
              currentValue === undefined ||
              `${currentValue}`.trim() === ""
            ) {
              nextData[key] = value;
            }
          }
        );

        const errors = validateComponentRow(nextData);
        return {
          ...row,
          data: nextData,
          errors,
          approved: errors.length === 0 && row.approved,
        };
      })
    );
    setMessage("Component template defaults applied.");
  };

  const aircraftGridColumns = useMemo<ColDef<PreviewRow>[]>(
    () => [
      {
        headerName: "Approve",
        colId: "approved",
        width: 110,
        pinned: "left",
        suppressMovable: true,
        cellRenderer: (params: ICellRendererParams<PreviewRow>) => {
          if (!params.data) {
            return null;
          }
          return (
            <input
              type="checkbox"
              checked={params.data.approved}
              disabled={hasErrors(params.data)}
              onChange={() => {
                const currentRow = params.data!;
                const nextRow = {
                  ...currentRow,
                  approved: !currentRow.approved,
                };
                if (previewMode === "server") {
                  params.node?.setData(nextRow);
                }
                toggleApproval(currentRow);
              }}
            />
          );
        },
      },
      {
        headerName: "Row",
        field: "row_number",
        width: 80,
        pinned: "left",
      },
      {
        headerName: "Action",
        colId: "action",
        minWidth: 200,
        cellRenderer: (params: ICellRendererParams<PreviewRow>) => {
          const row = params.data;
          if (!row) {
            return null;
          }
          const action = row.errors.length > 0 ? "invalid" : row.action;
          return (
            <div className="flex flex-col gap-1 text-xs">
              <span
                className={`inline-flex w-fit items-center rounded-full px-2 py-1 text-xs font-semibold ${
                  action === "new"
                    ? "bg-emerald-500/20 text-emerald-200"
                    : action === "update"
                    ? "bg-sky-500/20 text-sky-200"
                    : "bg-rose-500/20 text-rose-200"
                }`}
              >
                {action}
              </span>
              {row.errors.length > 0 && (
                <div className="text-rose-300">{row.errors.join(" ")}</div>
              )}
              {row.warnings.length > 0 && (
                <div className="text-amber-200">{row.warnings.join(" ")}</div>
              )}
            </div>
          );
        },
      },
      {
        headerName: "Diff",
        colId: "diff",
        minWidth: 220,
        cellRenderer: (params: ICellRendererParams<PreviewRow>) => {
          const row = params.data;
          if (!row) {
            return null;
          }
          const overrides = row.user_overrides ?? [];
          const proposed = (row.proposed_fields ?? []).filter(
            (field) =>
              !overrides.includes(field) &&
              normalizeValue(row.data[field]) !==
                normalizeValue(row.original_data?.[field])
          );
          const formatLabels = (fields: AircraftRowField[]) =>
            fields
              .map((field) => AIRCRAFT_FIELD_LABELS[field] ?? field)
              .join(", ");
          return (
            <div className="flex flex-col gap-1 text-xs">
              {proposed.length > 0 && (
                <div className="text-sky-300">
                  Proposed: {formatLabels(proposed)}
                </div>
              )}
              {overrides.length > 0 && (
                <div className="text-fuchsia-300">
                  Overrides: {formatLabels(overrides)}
                </div>
              )}
              {proposed.length === 0 && overrides.length === 0 && (
                <span className="text-slate-500">—</span>
              )}
            </div>
          );
        },
      },
      {
        headerName: "Serial",
        colId: "serial_number",
        editable: true,
        width: 150,
        cellRenderer: renderFormulaCell("serial_number"),
        valueGetter: (params) => params.data?.data.serial_number ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            serial_number: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Registration",
        colId: "registration",
        editable: true,
        width: 150,
        cellRenderer: renderFormulaCell("registration"),
        valueGetter: (params) => params.data?.data.registration ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            registration: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Template",
        colId: "template",
        editable: true,
        width: 160,
        cellRenderer: renderFormulaCell("template"),
        valueGetter: (params) => params.data?.data.template ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            template: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Suggested Template",
        colId: "suggested_template",
        minWidth: 220,
        valueGetter: (params) => params.data?.suggested_template?.name ?? "—",
        cellRenderer: (params: ICellRendererParams<PreviewRow>) => {
          const suggested = params.data?.suggested_template;
          if (!suggested) {
            return <span className="text-slate-500">—</span>;
          }
          return (
            <div className="text-xs">
              <div className="font-semibold text-slate-100">
                {suggested.name}
              </div>
              {(suggested.aircraft_template ||
                suggested.model_code ||
                suggested.operator_code) && (
                <div className="text-slate-400">
                  {[
                    suggested.aircraft_template,
                    suggested.model_code,
                    suggested.operator_code,
                  ]
                    .filter(Boolean)
                    .join(" · ")}
                </div>
              )}
            </div>
          );
        },
      },
      {
        headerName: "Make",
        colId: "make",
        editable: true,
        width: 140,
        cellRenderer: renderFormulaCell("make"),
        valueGetter: (params) => params.data?.data.make ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            make: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Model",
        colId: "model",
        editable: true,
        width: 140,
        cellRenderer: renderFormulaCell("model"),
        valueGetter: (params) => params.data?.data.model ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            model: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Base",
        colId: "home_base",
        editable: true,
        width: 140,
        cellRenderer: renderFormulaCell("home_base"),
        valueGetter: (params) => params.data?.data.home_base ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            home_base: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Owner",
        colId: "owner",
        editable: true,
        width: 160,
        cellRenderer: renderFormulaCell("owner"),
        valueGetter: (params) => params.data?.data.owner ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            owner: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Hours",
        colId: "total_hours",
        editable: true,
        width: 120,
        cellRenderer: renderFormulaCell("total_hours"),
        valueGetter: (params) => params.data?.data.total_hours ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            total_hours: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Cycles",
        colId: "total_cycles",
        editable: true,
        width: 120,
        cellRenderer: renderFormulaCell("total_cycles"),
        valueGetter: (params) => params.data?.data.total_cycles ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            total_cycles: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Last Log Date",
        colId: "last_log_date",
        editable: true,
        width: 160,
        cellRenderer: renderFormulaCell("last_log_date"),
        valueGetter: (params) => params.data?.data.last_log_date ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            last_log_date: params.newValue ?? "",
          };
          return true;
        },
      },
    ],
    [
      previewMode,
      renderFormulaCell,
      toggleApproval,
      hasErrors,
    ]
  );

  const aircraftGridDefaultColDef = useMemo<ColDef<PreviewRow>>(
    () => ({
      editable: false,
      resizable: true,
      sortable: true,
      suppressMovable: false,
      filter: true,
    }),
    []
  );

  const handleAircraftCellValueChanged = (
    event: CellValueChangedEvent<PreviewRow>
  ) => {
    if (!event.data) {
      return;
    }
    const field = event.colDef.colId as AircraftRowField | undefined;
    if (!field || !AIRCRAFT_DIFF_FIELDS.includes(field)) {
      return;
    }
    const decision = getFormulaProposalForField(event.data, field)
      ? "override"
      : undefined;
    updatePreviewRowValue(
      event.data.row_number,
      field,
      event.newValue ?? "",
      "user",
      decision,
      event.data
    );
  };

  const componentGridColumns = useMemo<ColDef<ComponentPreviewRow>[]>(
    () => [
      {
        headerName: "Approve",
        colId: "approved",
        width: 110,
        pinned: "left",
        suppressMovable: true,
        cellRenderer: (params: ICellRendererParams<ComponentPreviewRow>) => {
          if (!params.data) {
            return null;
          }
          return (
            <input
              type="checkbox"
              checked={params.data.approved}
              disabled={hasComponentErrors(params.data)}
              onChange={() => {
                const currentRow = params.data!;
                const nextRow = {
                  ...currentRow,
                  approved: !currentRow.approved,
                };
                if (componentPreviewMode === "server") {
                  params.node?.setData(nextRow);
                }
                toggleComponentApproval(currentRow);
              }}
            />
          );
        },
      },
      {
        headerName: "Row",
        field: "row_number",
        width: 80,
        pinned: "left",
      },
      {
        headerName: "Action",
        colId: "action",
        minWidth: 200,
        cellRenderer: (params: ICellRendererParams<ComponentPreviewRow>) => {
          const row = params.data;
          if (!row) {
            return null;
          }
          const action = row.errors.length > 0 ? "invalid" : row.action;
          return (
            <div className="flex flex-col gap-1 text-xs">
              <span
                className={`inline-flex w-fit items-center rounded-full px-2 py-1 text-xs font-semibold ${
                  action === "new"
                    ? "bg-emerald-500/20 text-emerald-200"
                    : action === "update"
                    ? "bg-sky-500/20 text-sky-200"
                    : "bg-rose-500/20 text-rose-200"
                }`}
              >
                {action}
              </span>
              {row.errors.length > 0 && (
                <div className="text-rose-300">{row.errors.join(" ")}</div>
              )}
              {row.warnings.length > 0 && (
                <div className="text-amber-200">{row.warnings.join(" ")}</div>
              )}
              {row.dedupe_suggestions &&
                row.dedupe_suggestions.length > 0 && (
                  <div className="text-amber-200">
                    {row.dedupe_suggestions.map((suggestion, idx) => (
                      <div key={`${row.row_number}-dedupe-${idx}`}>
                        {suggestion.source === "existing" ? "Existing" : "File"}{" "}
                        match for {suggestion.part_number}/
                        {suggestion.serial_number}:{" "}
                        {(suggestion.positions ?? []).join(", ")}
                      </div>
                    ))}
                  </div>
                )}
            </div>
          );
        },
      },
      {
        headerName: "Position",
        colId: "position",
        editable: true,
        width: 140,
        valueGetter: (params) => params.data?.data.position ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            position: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Part Number",
        colId: "part_number",
        editable: true,
        width: 160,
        valueGetter: (params) => params.data?.data.part_number ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            part_number: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Serial Number",
        colId: "serial_number",
        editable: true,
        width: 160,
        valueGetter: (params) => params.data?.data.serial_number ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            serial_number: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Existing PN/SN",
        colId: "existing_component",
        minWidth: 200,
        cellRenderer: (params: ICellRendererParams<ComponentPreviewRow>) => {
          const existing = params.data?.existing_component;
          if (!existing?.part_number && !existing?.serial_number) {
            return <span className="text-slate-500">—</span>;
          }
          return (
            <div className="text-xs text-slate-300">
              <div>{existing.part_number ?? "—"}</div>
              <div className="text-slate-400">
                {existing.serial_number ?? "—"}
              </div>
            </div>
          );
        },
      },
      {
        headerName: "ATA",
        colId: "ata",
        editable: true,
        width: 100,
        valueGetter: (params) => params.data?.data.ata ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            ata: params.newValue ?? "",
          };
          return true;
        },
      },
      {
        headerName: "Notes",
        colId: "notes",
        editable: true,
        minWidth: 200,
        valueGetter: (params) => params.data?.data.notes ?? "",
        valueSetter: (params) => {
          if (!params.data) {
            return false;
          }
          params.data.data = {
            ...params.data.data,
            notes: params.newValue ?? "",
          };
          return true;
        },
      },
    ],
    [componentPreviewMode, toggleComponentApproval, hasComponentErrors]
  );

  const componentGridDefaultColDef = useMemo<ColDef<ComponentPreviewRow>>(
    () => ({
      editable: false,
      resizable: true,
      sortable: true,
      suppressMovable: false,
      filter: true,
    }),
    []
  );

  const handleComponentCellValueChanged = (
    event: CellValueChangedEvent<ComponentPreviewRow>
  ) => {
    if (!event.data) {
      return;
    }
    const field = event.colDef.colId as keyof ComponentRowData | undefined;
    if (!field) {
      return;
    }
    const editableFields: (keyof ComponentRowData)[] = [
      "position",
      "part_number",
      "serial_number",
      "ata",
      "notes",
    ];
    if (!editableFields.includes(field)) {
      return;
    }
    updateComponentPreviewRowValue(
      event.data.row_number,
      field,
      event.newValue ?? "",
      event.data
    );
  };

  const buildConfirmedRows = (rows: PreviewRow[]): ConfirmedRow[] => {
    return rows.map((row) => {
      const cells: Record<string, ConfirmedCell> = {};
      (Object.keys(row.data) as AircraftRowField[]).forEach((field) => {
        const original = row.original_data?.[field] ?? null;
        const proposal = getFormulaProposalForField(row, field);
        const proposed = proposal
          ? proposal.proposed_value
          : row.proposed_fields?.includes(field)
          ? row.data[field]
          : original;
        cells[field] = {
          original,
          proposed,
          final: row.data[field],
          decision: buildFormulaDecision(row, field),
        };
      });
      return { row_number: row.row_number, cells };
    });
  };

  const confirmImport = async () => {
    const approvedRows =
      previewMode === "client"
        ? previewRows.filter((row) => row.approved && row.errors.length === 0)
        : [];
    const overrideRows = Object.values(previewRowOverrides);
    const approvedOverrideRows = overrideRows.filter(
      (row) => row.approved && row.errors.length === 0
    );
    const rejectedOverrideRows = overrideRows.filter((row) => !row.approved);
    if (
      previewMode === "client" &&
      approvedRows.length === 0 &&
      approvedOverrideRows.length === 0
    ) {
      setMessage("Select at least one valid row to import.");
      return;
    }
    if (
      previewMode === "server" &&
      !previewSummary?.new &&
      !previewSummary?.update &&
      approvedOverrideRows.length === 0
    ) {
      setMessage("Select at least one valid row to import.");
      return;
    }
    setConfirmLoading(true);
    setMessage(null);

    try {
      const approvedRowNumbers =
        previewMode === "client"
          ? approvedRows.map((row) => row.row_number)
          : approvedOverrideRows.map((row) => row.row_number);
      const rejectedRowNumbers =
        previewMode === "server"
          ? rejectedOverrideRows.map((row) => row.row_number)
          : [];
      const res = await fetch(`${API_BASE}/aircraft/import`, {
        method: "POST",
        headers: authHeaders({ "Content-Type": "application/json" }),
        body: JSON.stringify({
          rows:
            previewMode === "client"
              ? approvedRows.map((row) => ({
                  row_number: row.row_number,
                  ...row.data,
                }))
              : [],
          preview_id: previewId,
          approved_row_numbers:
            previewMode === "server" ? approvedRowNumbers : undefined,
          rejected_row_numbers:
            previewMode === "server" ? rejectedRowNumbers : undefined,
          confirmed_rows:
            previewMode === "client"
              ? buildConfirmedRows(approvedRows)
              : buildConfirmedRows(approvedOverrideRows),
          batch_id: importBatchId,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail ?? "Import failed");
      }
      setImportBatchId(data.batch_id ?? importBatchId);
      await loadSnapshotHistory(data.batch_id ?? importBatchId);
      setMessage(
        `Aircraft import OK. Created: ${data.created}, Updated: ${data.updated}`
      );
      setAircraftImportComplete(true);
    } catch (err: any) {
      setMessage(err.message ?? "Error importing aircraft.");
    } finally {
      setConfirmLoading(false);
    }
  };

  const confirmComponentImport = async () => {
    if (!componentAircraftSerial.trim()) {
      setMessage("Enter the aircraft serial number for components.");
      return;
    }
    const approvedRows =
      componentPreviewMode === "client"
        ? componentPreviewRows.filter(
            (row) => row.approved && row.errors.length === 0
          )
        : [];
    const overrideRows = Object.values(componentPreviewRowOverrides);
    const approvedOverrideRows = overrideRows.filter(
      (row) => row.approved && row.errors.length === 0
    );
    const rejectedOverrideRows = overrideRows.filter((row) => !row.approved);
    if (
      componentPreviewMode === "client" &&
      approvedRows.length === 0 &&
      approvedOverrideRows.length === 0
    ) {
      setMessage("Select at least one valid component row to import.");
      return;
    }
    if (
      componentPreviewMode === "server" &&
      !componentSummary?.new &&
      !componentSummary?.update &&
      approvedOverrideRows.length === 0
    ) {
      setMessage("Select at least one valid component row to import.");
      return;
    }
    setComponentConfirmLoading(true);
    setMessage(null);

    try {
      const approvedRowNumbers =
        componentPreviewMode === "client"
          ? approvedRows.map((row) => row.row_number)
          : approvedOverrideRows.map((row) => row.row_number);
      const rejectedRowNumbers =
        componentPreviewMode === "server"
          ? rejectedOverrideRows.map((row) => row.row_number)
          : [];
      const res = await fetch(
        `${getApiBaseUrl()}/aircraft/${encodeURIComponent(
          componentAircraftSerial.trim()
        )}/components/import/confirm`,
        {
          method: "POST",
          headers: authHeaders({ "Content-Type": "application/json" }),
          body: JSON.stringify({
            rows:
              componentPreviewMode === "client"
                ? approvedRows.map((row) => ({
                    row_number: row.row_number,
                    ...row.data,
                  }))
                : approvedOverrideRows.map((row) => ({
                    row_number: row.row_number,
                    ...row.data,
                  })),
            preview_id: componentPreviewId,
            approved_row_numbers:
              componentPreviewMode === "server" ? approvedRowNumbers : undefined,
            rejected_row_numbers:
              componentPreviewMode === "server" ? rejectedRowNumbers : undefined,
          }),
        }
      );

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail ?? "Component import failed");
      }
      setMessage(
        `Components import OK for aircraft ${data.aircraft_serial_number}. ` +
          `Created: ${data.components_created}, Updated: ${data.components_updated}`
      );
      setComponentImportComplete(true);
    } catch (err: any) {
      setMessage(err.message ?? "Error importing components.");
    } finally {
      setComponentConfirmLoading(false);
    }
  };

  const approvedCount = useMemo(() => {
    if (previewMode === "client") {
      return previewRows.filter((row) => row.approved && !hasErrors(row))
        .length;
    }
    const baseApproved =
      (previewSummary?.new ?? 0) + (previewSummary?.update ?? 0);
    const overrides = Object.values(previewRowOverrides);
    const rejected = overrides.filter(
      (row) => !row.approved && row.errors.length === 0
    ).length;
    const added = overrides.filter(
      (row) => row.approved && row.errors.length === 0 && row.action === "invalid"
    ).length;
    return Math.max(0, baseApproved - rejected + added);
  }, [previewMode, previewRows, previewSummary, previewRowOverrides]);

  const componentApprovedCount = useMemo(() => {
    if (componentPreviewMode === "client") {
      return componentPreviewRows.filter(
        (row) => row.approved && !hasComponentErrors(row)
      ).length;
    }
    const baseApproved =
      (componentSummary?.new ?? 0) + (componentSummary?.update ?? 0);
    const overrides = Object.values(componentPreviewRowOverrides);
    const rejected = overrides.filter(
      (row) => !row.approved && row.errors.length === 0
    ).length;
    const added = overrides.filter(
      (row) => row.approved && row.errors.length === 0 && row.action === "invalid"
    ).length;
    return Math.max(0, baseApproved - rejected + added);
  }, [componentPreviewMode, componentPreviewRows, componentSummary, componentPreviewRowOverrides]);

  const aircraftHasPreview =
    previewRows.length > 0 || previewTotalRows > 0 || !!previewId;
  const componentHasPreview = componentPreviewRows.length > 0;

  const aircraftStep = aircraftImportComplete
    ? 3
    : aircraftHasPreview
    ? 2
    : aircraftFiles.length > 0
    ? 1
    : 0;
  const componentStep = componentImportComplete
    ? 3
    : componentHasPreview
    ? 2
    : componentsFiles.length > 0
    ? 1
    : 0;

  const aircraftProgress = Math.round((aircraftStep / 3) * 100);
  const componentProgress = Math.round((componentStep / 3) * 100);
  const maxAircraftStage = Math.max(0, Math.min(aircraftStep, 3) - 1);
  const maxComponentStage = Math.max(0, Math.min(componentStep, 3) - 1);
  const [aircraftStageIndex, setAircraftStageIndex] = useState(0);
  const [componentStageIndex, setComponentStageIndex] = useState(0);
  const prevAircraftMaxRef = useRef(maxAircraftStage);
  const prevComponentMaxRef = useRef(maxComponentStage);

  useEffect(() => {
    if (maxAircraftStage > prevAircraftMaxRef.current) {
      setAircraftStageIndex(maxAircraftStage);
    } else if (aircraftStageIndex > maxAircraftStage) {
      setAircraftStageIndex(maxAircraftStage);
    }
    prevAircraftMaxRef.current = maxAircraftStage;
  }, [maxAircraftStage, aircraftStageIndex]);

  useEffect(() => {
    if (maxComponentStage > prevComponentMaxRef.current) {
      setComponentStageIndex(maxComponentStage);
    } else if (componentStageIndex > maxComponentStage) {
      setComponentStageIndex(maxComponentStage);
    }
    prevComponentMaxRef.current = maxComponentStage;
  }, [maxComponentStage, componentStageIndex]);

  const handleUndoSnapshot = async () => {
    if (!selectedSnapshotId) {
      setMessage("Select a snapshot to undo.");
      return;
    }
    setSnapshotActionLoading(true);
    setMessage(null);
    try {
      const res = await fetch(
        `${getApiBaseUrl()}/aircraft/import/snapshots/${selectedSnapshotId}/restore`,
        { method: "POST", headers: authHeaders() }
      );
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail ?? "Failed to restore snapshot.");
      }
      await loadSnapshotHistory(data.batch_id ?? importBatchId);
      setMessage(`Snapshot restored. Rows updated: ${data.restored ?? 0}.`);
    } catch (err: any) {
      setMessage(err.message ?? "Error restoring snapshot.");
    } finally {
      setSnapshotActionLoading(false);
    }
  };

  const handleRedoSnapshot = async () => {
    if (!selectedSnapshotId) {
      setMessage("Select a snapshot to reapply.");
      return;
    }
    setSnapshotActionLoading(true);
    setMessage(null);
    try {
      const res = await fetch(
        `${getApiBaseUrl()}/aircraft/import/snapshots/${selectedSnapshotId}/reapply`,
        { method: "POST", headers: authHeaders() }
      );
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail ?? "Failed to reapply snapshot.");
      }
      await loadSnapshotHistory(data.batch_id ?? importBatchId);
      setMessage(`Snapshot reapplied. Rows updated: ${data.reapplied ?? 0}.`);
    } catch (err: any) {
      setMessage(err.message ?? "Error reapplying snapshot.");
    } finally {
      setSnapshotActionLoading(false);
    }
  };

  void saveComponentTemplate;
  void confirmImport;
  void confirmComponentImport;
  void handleUndoSnapshot;
  void handleRedoSnapshot;

  return (
    <div className="page-layout">
      <div className="page-header">
        <h1 className="page-header__title">Aircraft Loader / Setup</h1>
        <p className="page-header__subtitle">
          Follow the guided steps to upload aircraft masters, review the preview,
          and confirm updates. The progress bar shows where you are in the
          process.
        </p>
      </div>

      <div className="import-section-nav" role="tablist" aria-label="Import type">
        <button
          type="button"
          role="tab"
          aria-selected={showAircraft}
          aria-current={showAircraft ? "page" : undefined}
          className={
            "import-section-nav__tab" + (showAircraft ? " is-active" : "")
          }
          onClick={() => aircraftImportUrl && navigate(aircraftImportUrl)}
          disabled={!aircraftImportUrl}
        >
          Aircraft import
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={showComponents}
          aria-current={showComponents ? "page" : undefined}
          className={
            "import-section-nav__tab" + (showComponents ? " is-active" : "")
          }
          onClick={() => componentImportUrl && navigate(componentImportUrl)}
          disabled={!componentImportUrl}
        >
          Component import
        </button>
      </div>

      {userIsSuperuser && (
        <section className="page-section">
          <h2 className="page-section__title">Target AMO</h2>
          <p className="page-section__body">
            Select the AMO you are configuring. This is only available to
            platform superusers.
          </p>
          <div className="page-section__grid">
            <div className="form-row">
              <label htmlFor="amo-target">AMO</label>
              <select
                id="amo-target"
                className="input"
                value={selectedAmoId}
                onChange={handleAmoChange}
                disabled={amoLoading || amoOptions.length === 0}
              >
                <option value="">
                  {amoLoading ? "Loading AMOs..." : "Select AMO"}
                </option>
                {amoOptions.map((amo) => (
                  <option key={amo.id} value={amo.id}>
                    {amo.amo_code} · {amo.name}
                  </option>
                ))}
              </select>
              {amoError && <div className="alert alert-error">{amoError}</div>}
            </div>
          </div>
        </section>
      )}

      {/* AIRCRAFT MASTER IMPORT */}
      {showAircraft && (
        <section className="page-section">
          <h2 className="page-section__title">
            1. Import Aircraft Master List
          </h2>
          <p className="page-section__body">
            Upload a CSV/Excel file containing aircraft serials, registration,
            type, base, hours, and cycles. iSpec 2000 headers (A/C REG, AIN,
            OPR, SPL, WHO, TTAF) are recognized alongside standard labels.
          </p>

          <div className="import-progress">
            <div className="import-progress__summary">
              <span>Aircraft master progress</span>
              <span>{aircraftProgress}%</span>
            </div>
            <div
              className={`import-progress__bar ${
                previewLoading || confirmLoading ? "is-loading" : ""
              }`}
            >
              <span style={{ width: `${aircraftProgress}%` }} />
            </div>
            <ol className="import-stepper">
              <li
                className={`import-stepper__item ${
                  aircraftStep >= 1 ? "is-complete" : ""
                } ${aircraftStageIndex === 0 ? "is-active" : ""}`}
              >
                <button
                  type="button"
                  className="import-stepper__button"
                  onClick={() => setAircraftStageIndex(0)}
                  disabled={maxAircraftStage < 0}
                >
                  Upload file
                </button>
              </li>
              <li
                className={`import-stepper__item ${
                  aircraftStep >= 2 ? "is-complete" : ""
                } ${aircraftStageIndex === 1 ? "is-active" : ""}`}
              >
                <button
                  onClick={applyTemplateToPreview}
                  disabled={
                    previewMode === "server" ||
                    !previewRows.length ||
                    !selectedTemplateId
                  }
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50"
                >
                  Review preview
                </button>
              </li>
              <li
                className={`import-stepper__item ${
                  aircraftStep >= 3 ? "is-complete" : ""
                } ${aircraftStageIndex === 2 ? "is-active" : ""}`}
              >
                <button
                  type="button"
                  className="import-stepper__button"
                  onClick={() => setAircraftStageIndex(2)}
                  disabled={maxAircraftStage < 2}
                >
                  Confirm import
                </button>
              </li>
            </ol>
          </div>

          <div className="import-stage">
            <div
              className="import-stage__track"
              style={{ transform: `translateX(-${aircraftStageIndex * 100}%)` }}
            >
              <div className="import-stage__panel">
                <div className="page-section__grid">
                  <div className="card card--form">
                    <div className="card-header">
                      <div>
                        <div className="import-step__eyebrow">Step 1</div>
                        <h3 className="import-step__title">Upload aircraft file</h3>
                      </div>
                      <span className="import-step__status">
                        {aircraftStep >= 1 ? "Ready" : "Waiting"}
                      </span>
                    </div>

                    <div className="form-row">
                      <label htmlFor="aircraft-file">Aircraft master files</label>
                      <input
                        id="aircraft-file"
                        type="file"
                        multiple
                        accept=".csv,.txt,.xlsx,.xlsm,.xls,.pdf,.png,.jpg,.jpeg,.tif,.tiff,.bmp,.webp"
                        onChange={handleAircraftFileChange}
                        className="input"
                      />
                      <p className="form-hint">
                        Accepted formats: CSV, XLSX, PDF, or image scans (OCR supported).
                        iSpec 2000 headers (A/C REG, AIN, OPR, SPL, WHO, TTAF) are
                        supported. Upload up to 10 files with identical column headers.
                      </p>
                      {aircraftFiles.length > 0 && (
                        <p className="form-hint">
                          Selected {aircraftFiles.length} file
                          {aircraftFiles.length === 1 ? "" : "s"}:{" "}
                          {aircraftFiles.map((file) => file.name).join(", ")}
                        </p>
                      )}
                    </div>

                    <div className="form-actions form-actions--inline">
                      <button
                        onClick={parseAircraftFile}
                        disabled={previewLoading}
                        className="btn"
                      >
                        {previewLoading ? "Parsing..." : "Parse & Preview"}
                      </button>
                    </div>
                  </div>

                  <div className="card card--form">
                    <div className="card-header">
                      <div>
                        <div className="import-step__eyebrow">Optional</div>
                        <h3 className="import-step__title">Manual aircraft entry</h3>
                      </div>
                      <span className="import-step__status">Available</span>
                    </div>
                    <p className="form-hint">
                      Add a single aircraft row without a file upload. The row will
                      appear in the preview table for review.
                    </p>
                    <div className="import-template-grid">
                      <div className="form-row">
                        <label>Serial number</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.serial_number}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              serial_number: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Registration</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.registration}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              registration: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Template</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.template}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              template: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Make</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.make}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              make: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Model</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.model}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              model: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Base</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.home_base}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              home_base: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Owner</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.owner}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              owner: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Model code</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.aircraft_model_code}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              aircraft_model_code: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Operator code</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.operator_code}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              operator_code: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Supplier code</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.supplier_code}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              supplier_code: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Company name</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.company_name}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              company_name: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Internal ID</label>
                        <input
                          type="text"
                          value={manualAircraftDraft.internal_aircraft_identifier}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              internal_aircraft_identifier: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Last log date</label>
                        <input
                          type="date"
                          value={manualAircraftDraft.last_log_date}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              last_log_date: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Total hours</label>
                        <input
                          type="number"
                          step="0.01"
                          value={manualAircraftDraft.total_hours}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              total_hours: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Total cycles</label>
                        <input
                          type="number"
                          step="1"
                          value={manualAircraftDraft.total_cycles}
                          onChange={(e) =>
                            setManualAircraftDraft((prev) => ({
                              ...prev,
                              total_cycles: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                    </div>

                    <div className="form-actions form-actions--inline">
                      <button onClick={handleAddManualAircraftRow} className="btn">
                        Add aircraft row
                      </button>
                      <button
                        onClick={() =>
                          setManualAircraftDraft(emptyManualAircraftDraft)
                        }
                        className="btn-secondary"
                        type="button"
                      >
                        Clear fields
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="import-stage__panel">
                <div className="page-section__grid">
                  <div className="card card--form">
                    <div className="card-header">
                      <div>
                        <div className="import-step__eyebrow">Step 2</div>
                        <h3 className="import-step__title">Review & map data</h3>
                      </div>
                      <span className="import-step__status">
                        {aircraftStep >= 2 ? "Ready" : "Waiting"}
                      </span>
                    </div>

                    {previewSummary && (
                      <div className="import-summary-grid">
                        <div className="card card--success">
                          <div className="import-summary__label">New</div>
                          <div className="import-summary__value">
                            {previewSummary.new}
                          </div>
                        </div>
                        <div className="card card--info">
                          <div className="import-summary__label">Update</div>
                          <div className="import-summary__value">
                            {previewSummary.update}
                          </div>
                        </div>
                        <div className="card card--warning">
                          <div className="import-summary__label">Invalid</div>
                          <div className="import-summary__value">
                            {previewSummary.invalid}
                          </div>
                        </div>
                        <div className="card card--info">
                          <div className="import-summary__label">Approved</div>
                          <div className="import-summary__value">{approvedCount}</div>
                        </div>
                      </div>
                    )}

                    <div className="form-hint" style={{ marginTop: 8 }}>
                      {snapshotLoading
                        ? "Loading snapshot history…"
                        : `Snapshots available: ${snapshots.length}`}
                      {snapshotActionLoading ? " • Updating snapshots…" : ""}
                    </div>

                    {(previewRows.length > 0 || previewTotalRows > 0) && (
                      <div className="table-wrapper import-grid">
                        <div
                          className="ag-theme-alpine"
                          style={{ height: 520, minWidth: 720 }}
                        >
                          <AgGridReact<PreviewRow>
                            key={previewMode}
                            rowData={
                              previewMode === "client" ? previewRows : undefined
                            }
                            columnDefs={aircraftGridColumns}
                            defaultColDef={aircraftGridDefaultColDef}
                            rowSelection="multiple"
                            suppressRowClickSelection
                            rowBuffer={12}
                            rowModelType={
                              previewMode === "server" ? "infinite" : "clientSide"
                            }
                            cacheBlockSize={200}
                            maxBlocksInCache={5}
                            suppressColumnVirtualisation={false}
                            suppressRowVirtualisation={false}
                            enableCellTextSelection
                            enableRangeSelection
                            getRowId={(params) => `${params.data.row_number}`}
                            onGridReady={handlePreviewGridReady}
                            onCellValueChanged={handleAircraftCellValueChanged}
                          />
                        </div>
                      </div>
                    )}

                    {columnMapping && (
                      <div className="form-hint">
                        Detected mapping:{" "}
                        {Object.entries(columnMapping)
                          .filter(([, value]) => value)
                          .map(([key, value]) => `${key} → ${value}`)
                          .join(", ")}
                      </div>
                    )}

                    <details className="import-advanced" open={false}>
                      <summary>Templates & defaults</summary>
                      <div className="import-advanced__body">
                        <div className="form-row">
                          <label>Template</label>
                          <select
                            value={selectedTemplateId}
                            onChange={(e) =>
                              setSelectedTemplateId(
                                e.target.value ? Number(e.target.value) : ""
                              )
                            }
                            className="input"
                          >
                            <option value="">Select template</option>
                            {templates.map((template) => (
                              <option key={template.id} value={template.id}>
                                {template.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="form-actions form-actions--inline">
                          <button
                            onClick={applyTemplateToPreview}
                            disabled={
                              previewMode === "server" ||
                              !previewRows.length ||
                              !selectedTemplateId
                            }
                            className="btn"
                          >
                            Apply template to preview
                          </button>
                          <button
                            onClick={saveMappingTemplate}
                            disabled={templateLoading || !columnMapping}
                            className="btn-secondary"
                          >
                            {templateLoading
                              ? "Saving..."
                              : "Save mapping template"}
                          </button>
                        </div>

                        <div className="import-template-grid">
                          <div className="form-row">
                            <label>Template name</label>
                            <input
                              type="text"
                              value={templateName}
                              onChange={(e) => setTemplateName(e.target.value)}
                              className="input"
                            />
                          </div>
                          <div className="form-row">
                            <label>Aircraft template</label>
                            <input
                              type="text"
                              value={templateAircraftTemplate}
                              onChange={(e) =>
                                setTemplateAircraftTemplate(e.target.value)
                              }
                              className="input"
                            />
                          </div>
                          <div className="form-row">
                            <label>Model code</label>
                            <input
                              type="text"
                              value={templateModelCode}
                              onChange={(e) => setTemplateModelCode(e.target.value)}
                              className="input"
                            />
                          </div>
                          <div className="form-row">
                            <label>Operator code</label>
                            <input
                              type="text"
                              value={templateOperatorCode}
                              onChange={(e) =>
                                setTemplateOperatorCode(e.target.value)
                              }
                              className="input"
                            />
                          </div>
                        </div>

                        <div className="form-row">
                          <label>Default values (JSON)</label>
                          <textarea
                            value={templateDefaultsJson}
                            onChange={(e) => setTemplateDefaultsJson(e.target.value)}
                            rows={4}
                            className="input"
                          />
                        </div>
                      </div>
                    </details>

                    {ocrPreview && (
                      <details className="import-advanced" open={false}>
                        <summary>OCR preview details</summary>
                        <div className="import-advanced__body">
                          <div className="import-ocr__header">
                            <div>
                              <div className="import-ocr__title">OCR Preview</div>
                              <div className="form-hint">
                                {ocrPreview.file_type
                                  ? `Detected ${ocrPreview.file_type.toUpperCase()}`
                                  : "Detected OCR content"}
                              </div>
                            </div>
                            <div className="import-ocr__confidence">
                              Confidence:{" "}
                              <strong>
                                {ocrPreview.confidence !== null &&
                                ocrPreview.confidence !== undefined
                                  ? `${ocrPreview.confidence.toFixed(1)}%`
                                  : "n/a"}
                              </strong>
                            </div>
                          </div>

                          {ocrPreview.samples && ocrPreview.samples.length > 0 && (
                            <div className="import-ocr__samples">
                              <div className="import-ocr__label">
                                Extracted samples
                              </div>
                              <ul>
                                {ocrPreview.samples.map((sample, index) => (
                                  <li key={`${sample}-${index}`}>{sample}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          <div className="form-row">
                            <label>OCR text (edit before re-parsing)</label>
                            <textarea
                              value={ocrTextDraft}
                              onChange={(e) => setOcrTextDraft(e.target.value)}
                              rows={6}
                              className="input import-ocr__textarea"
                            />
                            <p className="form-hint">
                              Re-parsing expects CSV/TSV-style rows with a header line.
                            </p>
                          </div>

                          <div className="form-actions form-actions--inline">
                            <button
                              onClick={reparseOcrText}
                              disabled={previewLoading}
                              className="btn"
                            >
                              {previewLoading
                                ? "Re-parsing..."
                                : "Rebuild Preview from OCR"}
                            </button>
                          </div>
                        </div>
                      </details>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {(previewRows.length > 0 || previewTotalRows > 0) && (
            <div className="mt-6">
              <div
                className="ag-theme-alpine-dark border border-slate-800 rounded-2xl overflow-hidden"
                style={{ height: 560 }}
              >
                <AgGridReact<PreviewRow>
                  key={previewMode}
                  rowData={previewMode === "client" ? previewRows : undefined}
                  columnDefs={aircraftGridColumns}
                  defaultColDef={aircraftGridDefaultColDef}
                  rowSelection="multiple"
                  suppressRowClickSelection
                  rowBuffer={12}
                  rowModelType={
                    previewMode === "server" ? "infinite" : "clientSide"
                  }
                  cacheBlockSize={200}
                  maxBlocksInCache={5}
                  suppressColumnVirtualisation={false}
                  suppressRowVirtualisation={false}
                  enableCellTextSelection
                  enableRangeSelection
                  getRowId={(params) => `${params.data.row_number}`}
                  onGridReady={handlePreviewGridReady}
                  onCellValueChanged={handleAircraftCellValueChanged}
                />
              </div>
            </div>
          )}
        </section>
      )}

      {/* COMPONENT IMPORT */}
      {showComponents && (
        <section className="page-section">
          <h2 className="page-section__title">
            2. Import Components for One Aircraft
          </h2>
          <p className="page-section__body">
            Upload components for one aircraft at a time, then review and confirm
            before committing. iSpec 2000 columns (ATA, PN, SN, MFR, OPR) are
            supported.
          </p>

          <div className="import-progress">
            <div className="import-progress__summary">
              <span>Component import progress</span>
              <span>{componentProgress}%</span>
            </div>
            <div
              className={`import-progress__bar ${
                componentPreviewLoading || componentConfirmLoading
                  ? "is-loading"
                  : ""
              }`}
            >
              <span style={{ width: `${componentProgress}%` }} />
            </div>
            <ol className="import-stepper">
              <li
                className={`import-stepper__item ${
                  componentStep >= 1 ? "is-complete" : ""
                } ${componentStageIndex === 0 ? "is-active" : ""}`}
              >
                <button
                  type="button"
                  className="import-stepper__button"
                  onClick={() => setComponentStageIndex(0)}
                  disabled={maxComponentStage < 0}
                >
                  Upload file
                </button>
              </li>
              <li
                className={`import-stepper__item ${
                  componentStep >= 2 ? "is-complete" : ""
                } ${componentStageIndex === 1 ? "is-active" : ""}`}
              >
                <button
                  onClick={applyComponentTemplateToPreview}
                  disabled={
                    componentPreviewMode === "server" ||
                    !componentPreviewRows.length ||
                    !componentSelectedTemplateId ||
                    componentTemplateLoading
                  }
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50"
                >
                  Review preview
                </button>
              </li>
              <li
                className={`import-stepper__item ${
                  componentStep >= 3 ? "is-complete" : ""
                } ${componentStageIndex === 2 ? "is-active" : ""}`}
              >
                <button
                  type="button"
                  className="import-stepper__button"
                  onClick={() => setComponentStageIndex(2)}
                  disabled={maxComponentStage < 2}
                >
                  Confirm import
                </button>
              </li>
            </ol>
          </div>

          <div className="import-stage">
            <div
              className="import-stage__track"
              style={{ transform: `translateX(-${componentStageIndex * 100}%)` }}
            >
              <div className="import-stage__panel">
                <div className="page-section__grid">
                  <div className="card card--form">
                    <div className="card-header">
                      <div>
                        <div className="import-step__eyebrow">Step 1</div>
                        <h3 className="import-step__title">
                          Identify the aircraft & upload
                        </h3>
                      </div>
                      <span className="import-step__status">
                        {componentStep >= 1 ? "Ready" : "Waiting"}
                      </span>
                    </div>

                    <div className="import-template-grid">
                      <div className="form-row">
                        <label>Aircraft serial number</label>
                        <input
                          type="text"
                          value={componentAircraftSerial}
                          onChange={(e) => setComponentAircraftSerial(e.target.value)}
                          className="input"
                          placeholder="e.g. 574, 510, 331"
                        />
                      </div>
                      <div className="form-row">
                        <label>Components files</label>
                        <input
                          type="file"
                          multiple
                          accept=".csv,.txt,.xlsx,.xlsm,.xls"
                          onChange={handleComponentsFileChange}
                          className="input"
                        />
                        <p className="form-hint">
                          Use component positions (L ENGINE, R ENGINE, APU) with iSpec
                          2000 columns for ATA, PN, SN, MFR, and OPR. Upload up to 10
                          files with identical headers.
                        </p>
                        {componentsFiles.length > 0 && (
                          <p className="form-hint">
                            Selected {componentsFiles.length} file
                            {componentsFiles.length === 1 ? "" : "s"}:{" "}
                            {componentsFiles.map((file) => file.name).join(", ")}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="form-actions form-actions--inline">
                      <button
                        onClick={parseComponentsFile}
                        disabled={componentPreviewLoading}
                        className="btn"
                      >
                        {componentPreviewLoading ? "Parsing..." : "Parse & Preview"}
                      </button>
                    </div>
                  </div>

                  <div className="card card--form">
                    <div className="card-header">
                      <div>
                        <div className="import-step__eyebrow">Optional</div>
                        <h3 className="import-step__title">Manual component entry</h3>
                      </div>
                      <span className="import-step__status">Available</span>
                    </div>
                    <p className="form-hint">
                      Add component rows manually when no files are available. Rows will
                      appear in the preview table for final review.
                    </p>
                    <div className="import-template-grid">
                      <div className="form-row">
                        <label>Position</label>
                        <input
                          type="text"
                          value={manualComponentDraft.position}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              position: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Part number</label>
                        <input
                          type="text"
                          value={manualComponentDraft.part_number}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              part_number: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Serial number</label>
                        <input
                          type="text"
                          value={manualComponentDraft.serial_number}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              serial_number: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>ATA</label>
                        <input
                          type="text"
                          value={manualComponentDraft.ata}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              ata: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Description</label>
                        <input
                          type="text"
                          value={manualComponentDraft.description}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              description: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Installed date</label>
                        <input
                          type="date"
                          value={manualComponentDraft.installed_date}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              installed_date: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Installed hours</label>
                        <input
                          type="number"
                          step="0.01"
                          value={manualComponentDraft.installed_hours}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              installed_hours: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Installed cycles</label>
                        <input
                          type="number"
                          step="1"
                          value={manualComponentDraft.installed_cycles}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              installed_cycles: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Current hours</label>
                        <input
                          type="number"
                          step="0.01"
                          value={manualComponentDraft.current_hours}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              current_hours: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Current cycles</label>
                        <input
                          type="number"
                          step="1"
                          value={manualComponentDraft.current_cycles}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              current_cycles: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Manufacturer code</label>
                        <input
                          type="text"
                          value={manualComponentDraft.manufacturer_code}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              manufacturer_code: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                      <div className="form-row">
                        <label>Operator code</label>
                        <input
                          type="text"
                          value={manualComponentDraft.operator_code}
                          onChange={(e) =>
                            setManualComponentDraft((prev) => ({
                              ...prev,
                              operator_code: e.target.value,
                            }))
                          }
                          className="input"
                        />
                      </div>
                    </div>
                    <div className="form-row">
                      <label>Notes</label>
                      <textarea
                        value={manualComponentDraft.notes}
                        onChange={(e) =>
                          setManualComponentDraft((prev) => ({
                            ...prev,
                            notes: e.target.value,
                          }))
                        }
                        rows={3}
                        className="input"
                      />
                    </div>

                    <div className="form-actions form-actions--inline">
                      <button onClick={handleAddManualComponentRow} className="btn">
                        Add component row
                      </button>
                      <button
                        onClick={() =>
                          setManualComponentDraft(emptyManualComponentDraft)
                        }
                        className="btn-secondary"
                        type="button"
                      >
                        Clear fields
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {componentSummary && (
            <div className="import-summary-grid" style={{ marginBottom: 16 }}>
              <div className="card card--success">
                <div className="import-summary__label">New</div>
                <div className="import-summary__value">{componentSummary.new}</div>
              </div>
              <div className="card card--info">
                <div className="import-summary__label">Update</div>
                <div className="import-summary__value">{componentSummary.update}</div>
              </div>
              <div className="card card--warning">
                <div className="import-summary__label">Invalid</div>
                <div className="import-summary__value">{componentSummary.invalid}</div>
              </div>
              <div className="card card--info">
                <div className="import-summary__label">Approved</div>
                <div className="import-summary__value">{componentApprovedCount}</div>
              </div>
            </div>
          )}

          {(componentPreviewRows.length > 0 || componentPreviewTotalRows > 0) && (
            <div className="mt-6">
              <div
                className="ag-theme-alpine-dark border border-slate-800 rounded-2xl overflow-hidden"
                style={{ height: 520 }}
              >
                <AgGridReact<ComponentPreviewRow>
                  key={componentPreviewMode}
                  rowData={
                    componentPreviewMode === "client"
                      ? componentPreviewRows
                      : undefined
                  }
                  columnDefs={componentGridColumns}
                  defaultColDef={componentGridDefaultColDef}
                  rowSelection="multiple"
                  suppressRowClickSelection
                  rowBuffer={12}
                  rowModelType={
                    componentPreviewMode === "server" ? "infinite" : "clientSide"
                  }
                  cacheBlockSize={200}
                  maxBlocksInCache={5}
                  suppressColumnVirtualisation={false}
                  suppressRowVirtualisation={false}
                  enableCellTextSelection
                  enableRangeSelection
                  getRowId={(params) => `${params.data.row_number}`}
                  onGridReady={handleComponentGridReady}
                  onCellValueChanged={handleComponentCellValueChanged}
                />
              </div>
            </div>
          )}

          {componentColumnMapping && (
            <div className="mt-4 text-xs text-slate-400">
              Detected mapping:{" "}
              {Object.entries(componentColumnMapping)
                .filter(([, value]) => value)
                .map(([key, value]) => `${key} → ${value}`)
                .join(", ")}
            </div>
          )}
        </section>
      )}

      {message && <div className="alert">{message}</div>}
    </div>
  );
};

export default AircraftImportPage;
