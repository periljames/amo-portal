// src/pages/AdminUserNewPage.tsx
import React, { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
  createAdminUser,
  listAdminAmos,
  listAdminDepartments,
  listStaffCodeSuggestions,
  setActiveAmoId,
  LS_ACTIVE_AMO_ID,
} from "../services/adminUsers";
import type {
  AdminAmoRead,
  AdminDepartmentRead,
  AdminUserCreatePayload,
  AccountRole,
} from "../services/adminUsers";
import { getCachedUser, getContext } from "../services/auth";
import { Button, InlineAlert, PageHeader, Panel } from "../components/UI/Admin";
import DepartmentLayout from "../components/Layout/DepartmentLayout";
import "../styles/admin-user-management.css";

type UrlParams = {
  amoCode?: string;
};

const DEFAULT_ROLE: AccountRole = "AMO_ADMIN";

const ROLE_OPTIONS: Array<{ value: AccountRole; label: string }> = [
  { value: "AMO_ADMIN", label: "AMO Admin" },
  { value: "QUALITY_MANAGER", label: "Quality Manager" },
  { value: "AUDITOR", label: "Auditor" },
  { value: "SAFETY_MANAGER", label: "Safety Manager" },
  { value: "PLANNING_ENGINEER", label: "Planning Engineer" },
  { value: "PRODUCTION_ENGINEER", label: "Production Engineer" },
  { value: "CERTIFYING_ENGINEER", label: "Certifying Engineer" },
  { value: "CERTIFYING_TECHNICIAN", label: "Certifying Technician" },
  { value: "TECHNICIAN", label: "Technician" },
  { value: "STORES", label: "Stores" },
  { value: "VIEW_ONLY", label: "View Only" },
  { value: "SUPERUSER", label: "Platform Superuser" },
];

const AdminUserNewPage: React.FC = () => {
  const navigate = useNavigate();
  const { amoCode } = useParams<UrlParams>();

  const ctx = getContext();
  const currentUser = getCachedUser();

  const isAdmin = useMemo(() => {
    if (!currentUser) return false;
    return currentUser.role === "SUPERUSER" || currentUser.role === "AMO_ADMIN";
  }, [currentUser]);

  const isSuperuser = !!currentUser?.is_superuser;

  const backTarget = useMemo(() => {
    const slug = amoCode ?? ctx.amoCode ?? null;
    return slug ? `/maintenance/${slug}/admin/users` : "/login";
  }, [amoCode, ctx.amoCode]);

  const resolvedAmoCode = amoCode ?? ctx.amoCode ?? "UNKNOWN";

  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    role: DEFAULT_ROLE as AccountRole,
    positionTitle: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });
  const [staffCodeOptions, setStaffCodeOptions] = useState<string[]>([]);
  const [staffCodeLoading, setStaffCodeLoading] = useState(false);
  const [staffCodeError, setStaffCodeError] = useState<string | null>(null);
  const [selectedStaffCode, setSelectedStaffCode] = useState<string>("");
  const [staffCodeSeed, setStaffCodeSeed] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [amos, setAmos] = useState<AdminAmoRead[]>([]);
  const [amoLoading, setAmoLoading] = useState(false);
  const [amoError, setAmoError] = useState<string | null>(null);
  const [selectedAmoId, setSelectedAmoId] = useState<string>(() => {
    const stored = localStorage.getItem(LS_ACTIVE_AMO_ID);
    return stored && stored.trim() ? stored.trim() : "";
  });
  const [departments, setDepartments] = useState<AdminDepartmentRead[]>([]);
  const [departmentsLoading, setDepartmentsLoading] = useState(false);
  const [departmentsError, setDepartmentsError] = useState<string | null>(null);
  const [selectedDepartmentId, setSelectedDepartmentId] = useState<string>("");

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const selectedAmo = useMemo(() => amos.find((amo) => amo.id === selectedAmoId) ?? null, [amos, selectedAmoId]);

  const pageTitle = useMemo(() => {
    const label = selectedAmo?.name || resolvedAmoCode.toUpperCase();
    return `Create user · ${label}`;
  }, [resolvedAmoCode, selectedAmo]);

  const activeDepartments = useMemo(
    () => departments.filter((dept) => dept.is_active),
    [departments]
  );

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const validate = (): string | null => {
    const email = form.email.trim();

    if (!email) return "Email is required.";
    if (!form.firstName.trim() || !form.lastName.trim()) {
      return "First name and last name are required.";
    }

    if (!form.password) return "Password is required.";
    if (form.password !== form.confirmPassword) return "Passwords do not match.";

    if (form.password.length < 12) {
      return "Password must be at least 12 characters.";
    }
    const hasUpper = /[A-Z]/.test(form.password);
    const hasLower = /[a-z]/.test(form.password);
    const hasDigit = /\d/.test(form.password);
    if (!(hasUpper && hasLower && hasDigit)) {
      return "Password must include upper/lower case letters and a number.";
    }

    // Only SUPERUSER can create SUPERUSER
    if (form.role === "SUPERUSER" && !isSuperuser) {
      return "Only a platform superuser can create another superuser.";
    }

    if (isSuperuser && !selectedAmoId) {
      return "Select an AMO for this user.";
    }
    if (activeDepartments.length > 0 && !selectedDepartmentId) {
      return "Select a department for this user.";
    }
    if (!selectedStaffCode) {
      return "Select a staff code suggestion before creating the user.";
    }

    return null;
  };

  const generateSecurePassword = () => {
    const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const lower = "abcdefghijklmnopqrstuvwxyz";
    const digits = "0123456789";
    const symbols = "!@#$%^&*()-_=+[]{}<>?";
    const all = upper + lower + digits + symbols;

    const pick = (chars: string) =>
      chars[Math.floor(Math.random() * chars.length)];

    const base = [
      pick(upper),
      pick(lower),
      pick(digits),
      pick(symbols),
    ];

    for (let i = base.length; i < 14; i += 1) {
      base.push(pick(all));
    }

    const shuffled = base.sort(() => Math.random() - 0.5).join("");
    setForm((prev) => ({
      ...prev,
      password: shuffled,
      confirmPassword: shuffled,
    }));
  };

  const copyPassword = async () => {
    if (!form.password) return;
    try {
      if (!navigator.clipboard) {
        throw new Error("Clipboard unavailable");
      }
      await navigator.clipboard.writeText(form.password);
      setSuccess("Temporary password copied to clipboard.");
    } catch (err) {
      console.error("Failed to copy password", err);
      setError("Could not copy password. Please copy it manually.");
    }
  };

  React.useEffect(() => {
    if (!isSuperuser) return;

    const loadAmos = async () => {
      setAmoError(null);
      setAmoLoading(true);
      try {
        const data = await listAdminAmos();
        setAmos(data);
        if (!selectedAmoId && data.length > 0) {
          setSelectedAmoId(data[0].id);
        }
      } catch (err: any) {
        console.error("Failed to load AMOs", err);
        setAmoError(err?.message || "Failed to load AMOs.");
      } finally {
        setAmoLoading(false);
      }
    };

    loadAmos();
  }, [isSuperuser, selectedAmoId]);

  React.useEffect(() => {
    const loadDepartments = async () => {
      setDepartmentsError(null);
      if (!currentUser) return;
      const targetAmoId = isSuperuser ? selectedAmoId : currentUser.amo_id;
      if (!targetAmoId) {
        setDepartments([]);
        setSelectedDepartmentId("");
        return;
      }
      setDepartmentsLoading(true);
      try {
        const data = await listAdminDepartments(targetAmoId);
        setDepartments(data);
        const active = data.filter((dept) => dept.is_active);
        if (!selectedDepartmentId && active.length > 0) {
          setSelectedDepartmentId(active[0].id);
        }
      } catch (err: any) {
        console.error("Failed to load departments", err);
        setDepartmentsError(err?.message || "Failed to load departments.");
      } finally {
        setDepartmentsLoading(false);
      }
    };

    loadDepartments();
  }, [currentUser, isSuperuser, selectedAmoId]);

  React.useEffect(() => {
    const first = form.firstName.trim();
    const last = form.lastName.trim();
    const targetAmoId = isSuperuser ? selectedAmoId : currentUser?.amo_id;

    if (!first || !last || !targetAmoId) {
      setStaffCodeOptions([]);
      setSelectedStaffCode("");
      return;
    }

    setStaffCodeLoading(true);
    setStaffCodeError(null);

    const timer = window.setTimeout(() => {
      listStaffCodeSuggestions({
        first_name: first,
        last_name: last,
        amo_id: isSuperuser ? targetAmoId : undefined,
      })
        .then((data) => {
          const suggestions = data.suggestions || [];
          setStaffCodeOptions(suggestions);
          setSelectedStaffCode((prev) =>
            suggestions.includes(prev) ? prev : suggestions[0] || ""
          );
        })
        .catch((err: any) => {
          console.error("Failed to load staff code suggestions", err);
          setStaffCodeError(err?.message || "Failed to load staff code suggestions.");
          setStaffCodeOptions([]);
          setSelectedStaffCode("");
        })
        .finally(() => setStaffCodeLoading(false));
    }, 300);

    return () => window.clearTimeout(timer);
  }, [
    form.firstName,
    form.lastName,
    isSuperuser,
    selectedAmoId,
    currentUser?.amo_id,
    staffCodeSeed,
  ]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!currentUser) {
      setError("No user session found. Please sign in again.");
      return;
    }
    if (!isAdmin) {
      setError("You do not have permission to create users.");
      return;
    }

    const v = validate();
    if (v) {
      setError(v);
      return;
    }

    setSubmitting(true);
    try {
      const first = form.firstName.trim();
      const last = form.lastName.trim();

      const payload: AdminUserCreatePayload = {
        staff_code: selectedStaffCode,
        email: form.email.trim().toLowerCase(),
        first_name: first,
        last_name: last,
        full_name: `${first} ${last}`.trim(),
        role: form.role,
        position_title: form.positionTitle.trim() || undefined,
        phone: form.phone.trim() || undefined,
        password: form.password,
        amo_id: isSuperuser ? selectedAmoId || undefined : undefined,
        department_id: selectedDepartmentId || undefined,
        // NOTE:
        // Do NOT force amo_id here. adminUsers.ts resolves it safely:
        // - SUPERUSER: can target selected/active AMO
        // - others: forced to current user's AMO
      };

      await createAdminUser(payload);

      setSuccess("User created successfully.");
      setTimeout(() => navigate(backTarget), 600);
    } catch (err: any) {
      console.error("Failed to create user", err);

      const msg =
        err?.response?.data?.detail ||
        err?.detail ||
        err?.message ||
        "Failed to create user. Please try again.";
      setError(
        typeof msg === "string" ? msg : "Failed to create user. Please try again."
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (!currentUser) {
    return (
      <DepartmentLayout amoCode={resolvedAmoCode} activeDepartment="admin-users">
        <div className="admin-users-workspace admin-user-create-page">
          <PageHeader title="Create user" subtitle="Your session has expired or is unavailable." className="aum-brand-page-header admin-page-header--centered" />
          <Panel className="aum-brand-panel">
            <p className="admin-muted">You are not signed in. Please sign in again.</p>
            <Button onClick={() => navigate("/login")}>Go to login</Button>
          </Panel>
        </div>
      </DepartmentLayout>
    );
  }

  if (!isAdmin) {
    return (
      <DepartmentLayout amoCode={resolvedAmoCode} activeDepartment="admin-users">
        <div className="admin-users-workspace admin-user-create-page">
          <PageHeader title="Access denied" subtitle="Only tenant administrators can create users from this workspace." className="aum-brand-page-header admin-page-header--centered" />
          <Panel className="aum-brand-panel">
            <p className="admin-muted">
              You do not have permission to create users. Please contact the AMO
              Administrator or Quality/IT support.
            </p>
            <Button onClick={() => navigate(backTarget)}>Back</Button>
          </Panel>
        </div>
      </DepartmentLayout>
    );
  }

  return (
    <DepartmentLayout amoCode={resolvedAmoCode} activeDepartment="admin-users">
      <div className="admin-users-workspace admin-user-create-page">
        <PageHeader
          title={pageTitle}
          subtitle="Create an AMO user with the active tenant branding, access profile, and initial password policy already aligned."
          className="aum-brand-page-header admin-page-header--centered"
        />

        <Panel className="admin-user-form aum-brand-panel">
        <form onSubmit={handleSubmit} className="form-grid form-grid--two-column">
          {error && (
            <InlineAlert tone="danger" title="Error" className="form-row--span-2">
              <span>{error}</span>
            </InlineAlert>
          )}
          {success && (
            <InlineAlert tone="success" title="Success" className="form-row--span-2">
              <span>{success}</span>
            </InlineAlert>
          )}
          {amoError && (
            <InlineAlert tone="danger" title="Error" className="form-row--span-2">
              <span>{amoError}</span>
            </InlineAlert>
          )}
          {departmentsError && (
            <InlineAlert tone="danger" title="Error" className="form-row--span-2">
              <span>{departmentsError}</span>
            </InlineAlert>
          )}

          {isSuperuser && (
            <div className="form-row form-row--span-2">
              <label htmlFor="amoId">Target AMO</label>
              <select
                id="amoId"
                name="amoId"
                value={selectedAmoId}
                onChange={(e) => {
                  const nextId = e.target.value;
                  setSelectedAmoId(nextId);
                  setActiveAmoId(nextId);
                  setSelectedDepartmentId("");
                }}
                disabled={submitting || amoLoading}
                required
              >
                <option value="" disabled>
                  {amoLoading ? "Loading AMOs..." : "Select an AMO"}
                </option>
                {amos.map((amo) => (
                  <option key={amo.id} value={amo.id}>
                    {amo.name} ({amo.amo_code})
                  </option>
                ))}
              </select>
              <p className="form-hint">
                Superusers must select which AMO will own this user.
              </p>
            </div>
          )}

          <div className="form-row form-row--span-2">
            <div className="form-row__header">
              <label htmlFor="departmentId">Department</label>
              <button
                type="button"
                className="admin-link-btn"
                onClick={() => navigate(`${backTarget}#departments-panel`)}
              >
                Manage departments
              </button>
            </div>
            <select
              id="departmentId"
              name="departmentId"
              value={selectedDepartmentId}
              onChange={(e) => setSelectedDepartmentId(e.target.value)}
              disabled={submitting || departmentsLoading}
              required={activeDepartments.length > 0}
            >
              <option value="" disabled>
                {departmentsLoading ? "Loading departments..." : "Select a department"}
              </option>
              {activeDepartments.map((dept) => (
                <option key={dept.id} value={dept.id}>
                  {dept.name} ({dept.code})
                </option>
              ))}
            </select>
            <p className="form-hint">
              Assign the default department so the user lands in the right dashboard. Only active
              departments are listed.
            </p>
          </div>
          {!departmentsLoading && activeDepartments.length === 0 && (
            <InlineAlert
              tone="warning"
              title="No departments yet"
              className="form-row--span-2"
              actions={(
                <Button
                  type="button"
                  size="sm"
                  variant="secondary"
                  onClick={() => navigate(`${backTarget}#departments-panel`)}
                >
                  Create department
                </Button>
              )}
            >
              <span>
                No custom departments found. The user will follow default access rules until
                departments are added.
              </span>
            </InlineAlert>
          )}

          <div className="form-row">
            <label htmlFor="firstName">First Name</label>
            <input
              id="firstName"
              name="firstName"
              type="text"
              value={form.firstName}
              onChange={handleChange}
              autoComplete="off"
              required
              disabled={submitting}
            />
          </div>

          <div className="form-row">
            <label htmlFor="lastName">Last Name</label>
            <input
              id="lastName"
              name="lastName"
              type="text"
              value={form.lastName}
              onChange={handleChange}
              autoComplete="off"
              required
              disabled={submitting}
            />
          </div>

          <div className="form-row form-row--span-2">
            <div className="form-row__header">
              <label htmlFor="staffCode">Staff Code (auto)</label>
              <button
                type="button"
                className="admin-link-btn"
                onClick={() => {
                  setStaffCodeSeed((prev) => prev + 1);
                }}
                disabled={staffCodeLoading || !form.firstName.trim() || !form.lastName.trim()}
              >
                Refresh suggestions
              </button>
            </div>
            <select
              id="staffCode"
              name="staffCode"
              value={selectedStaffCode}
              onChange={(e) => setSelectedStaffCode(e.target.value)}
              disabled={staffCodeLoading || staffCodeOptions.length === 0}
              required
            >
              <option value="" disabled>
                {staffCodeLoading ? "Generating staff codes..." : "Select a staff code"}
              </option>
              {staffCodeOptions.map((code) => (
                <option key={code} value={code}>
                  {code}
                </option>
              ))}
            </select>
            {staffCodeError ? (
              <p className="form-hint">{staffCodeError}</p>
            ) : (
              <p className="form-hint">
                Staff codes are generated from first/last name. Choose any suggested code.
              </p>
            )}
          </div>

          <div className="form-row form-row--span-2">
            <label htmlFor="email">Work Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              autoComplete="off"
              required
              disabled={submitting}
            />
          </div>

          <div className="form-row form-row--span-2">
            <label htmlFor="role">Role</label>
            <select
              id="role"
              name="role"
              value={form.role}
              onChange={handleChange}
              disabled={submitting}
            >
              {ROLE_OPTIONS.filter((r) => isSuperuser || r.value !== "SUPERUSER").map(
                (r) => (
                  <option key={r.value} value={r.value}>
                    {r.label}
                  </option>
                )
              )}
            </select>
            <p className="form-hint">
              Choose the closest operational role. Role controls permissions while department
              controls the dashboard landing page.
            </p>
          </div>

          <div className="form-row">
            <label htmlFor="positionTitle">Position Title</label>
            <input
              id="positionTitle"
              name="positionTitle"
              type="text"
              value={form.positionTitle}
              onChange={handleChange}
              placeholder="e.g. Maintenance Manager"
              disabled={submitting}
            />
          </div>

          <div className="form-row form-row--span-2">
            <label htmlFor="phone">Phone</label>
            <input
              id="phone"
              name="phone"
              type="tel"
              value={form.phone}
              onChange={handleChange}
              placeholder="+254..."
              disabled={submitting}
            />
          </div>

          <div className="form-row">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              name="password"
              type={showPassword ? "text" : "password"}
              value={form.password}
              onChange={handleChange}
              required
              disabled={submitting}
            />
          </div>

          <div className="form-row">
            <label htmlFor="confirmPassword">Confirm Password</label>
            <input
              id="confirmPassword"
              name="confirmPassword"
              type={showPassword ? "text" : "password"}
              value={form.confirmPassword}
              onChange={handleChange}
              required
              disabled={submitting}
            />
          </div>

          <div className="form-row form-row--span-2">
            <div className="form-actions form-actions--inline">
              <Button
                type="button"
                size="sm"
                variant="secondary"
                onClick={generateSecurePassword}
                disabled={submitting}
              >
                Generate secure password
              </Button>
              <Button
                type="button"
                size="sm"
                variant="secondary"
                onClick={() => setShowPassword((prev) => !prev)}
                disabled={submitting}
              >
                {showPassword ? "Hide password" : "Show password"}
              </Button>
              <Button
                type="button"
                size="sm"
                variant="secondary"
                onClick={copyPassword}
                disabled={submitting || !form.password}
              >
                Copy password
              </Button>
            </div>
            <p className="form-hint">
              Passwords must be at least 12 characters and include upper/lower
              case letters and a number (symbols optional). The user will be
              asked to change this on first login.
            </p>
          </div>

          <div className="form-actions form-row--span-2">
            <Button
              type="button"
              variant="secondary"
              onClick={() => navigate(backTarget)}
              disabled={submitting}
            >
              Cancel
            </Button>

            <Button type="submit" disabled={submitting}>
              {submitting ? "Creating..." : "Create User"}
            </Button>
          </div>
        </form>
        </Panel>
      </div>
    </DepartmentLayout>
  );
};

export default AdminUserNewPage;
