export { default } from "./AdminSetupCentrePage";
