/// <reference types="node" />

import { readFileSync } from "node:fs";

import { describe, expect, it } from "vitest";

function readSource(relativePath: string): string {
  return readFileSync(new URL(relativePath, import.meta.url), "utf8");
}

const plannerHookSource = readSource("./hooks/useRosterPlannerDataV2.ts");
const rosterShellSource = readSource("./components/RosterShell.tsx");
const rosterLayoutSource = readSource("../../styles/rostering-workforce-layout.css");
const rosterPeopleSource = readSource("../../services/rosterPeople.ts");
const workOrdersSource = readSource("../../services/workOrders.ts");
const fleetSource = readSource("../../services/fleet.ts");
const offlineHttpSource = readSource("../../services/offlineHttp.ts");
const offlinePersistenceSource = readSource("../../services/offlinePersistence.ts");
const queryPersisterSource = readSource("../../services/queryPersister.ts");
const offlineIndicatorSource = readSource("../../components/offline/OfflineSyncIndicator.tsx");
const mainSource = readSource("../../main.tsx");
const themeContractSource = readSource("../../styles/theme-contract.css");
const themeRepairsSource = readSource("../../styles/theme-module-repairs.css");

describe("rostering architecture regressions", () => {
  it("keeps every rostering page inside the global department shell", () => {
    expect(rosterShellSource).toContain("<DepartmentLayout");
    expect(rosterShellSource).toContain('activeDepartment="rostering"');
    expect(rosterShellSource).toContain("</DepartmentLayout>");
  });

  it("uses a fluid viewport contract in both production shell modes", () => {
    expect(rosterShellSource).toContain('rostering-workforce-layout.css');
    expect(rosterLayoutSource).toContain('.app-shell__content:has(> .wr-page)');
    expect(rosterLayoutSource).toContain('.app-shell:not(.app-shell--v2):has(.wr-page)');
    expect(rosterLayoutSource).toContain('.app-shell__main-inner');
    expect(rosterLayoutSource).toContain('max-width: none');
    expect(rosterLayoutSource).toContain('--sidebar-width: clamp(204px, 12.5vw, 226px)');
    expect(rosterLayoutSource).toContain('--wr-page-viewport-offset: 98px');
    expect(rosterLayoutSource).toContain('min-height: calc(100dvh - var(--wr-page-viewport-offset, 58px))');
    expect(rosterLayoutSource).not.toContain('min-height: 100dvh;');
    expect(rosterLayoutSource).toContain('@media (min-width: 1680px)');
    expect(rosterLayoutSource).toContain('.wr-dashboard > .wr-panel:last-child');
  });

  it("uses stable query resources instead of a recursive load-all effect", () => {
    expect(plannerHookSource).toContain("useQuery({");
    expect(plannerHookSource).toContain("useInfiniteQuery({");
    expect(plannerHookSource).toContain('"eligible-people"');
    expect(plannerHookSource).toContain('"version-workspace"');
    expect(plannerHookSource).not.toContain("loadAll");
    expect(plannerHookSource).not.toContain("useEffect(() => void");
  });

  it("loads roster personnel through the paginated planner contract", () => {
    expect(rosterPeopleSource).toContain("/workforce/roster-people");
    expect(plannerHookSource).toContain("PEOPLE_PAGE_SIZE = 100");
    expect(plannerHookSource).toContain("getNextPageParam");
    expect(plannerHookSource).not.toContain("limit: 1000");
  });

  it("persists and reapplies optimistic assignment rows over stale cached snapshots", () => {
    expect(plannerHookSource).toContain("setQueryData<VersionWorkspace>");
    expect(plannerHookSource).toContain("assignments: next");
    expect(plannerHookSource).toContain("mergePendingRosterOutbox");
    expect(plannerHookSource).toContain("listOfflineMutations().catch");
    expect(plannerHookSource).toContain("PENDING_OUTBOX_STATUSES");
    expect(plannerHookSource).not.toContain("useState<RosterAssignmentRead[]>([])");
  });

  it("passes bearer authentication while keeping unsafe work-order replay disabled", () => {
    expect(workOrdersSource).toContain('import { authHeaders } from "./auth"');
    expect(workOrdersSource).toContain("headers: authHeaders()");
    expect(workOrdersSource.match(/headers: authHeaders\(\)/g)?.length).toBeGreaterThanOrEqual(11);
    expect(workOrdersSource.match(/queueMutation: true/g)?.length).toBe(1);
    expect(workOrdersSource).toContain("Work-order updates have no backend revision/idempotency contract yet");
  });

  it("keeps non-versioned compliance document edits live-only", () => {
    expect(fleetSource).toContain("Compliance records currently have no backend revision precondition");
    expect(fleetSource).not.toContain("queueMutation: true");
  });

  it("binds network reads, cache writes and queued mutations to their originating AMO", () => {
    expect(offlineHttpSource).toContain("const requestScope = currentOfflineScope()");
    expect(offlineHttpSource).toContain("assertRequestScope(requestScope)");
    expect(offlineHttpSource).toContain("scope: requestScope");
    expect(offlineHttpSource).toContain("requestScope,");
    expect(offlinePersistenceSource).toContain("scope = currentOfflineScope()");
    expect(offlinePersistenceSource).toContain("if (currentOfflineScope() !== scope) return null");
    expect(offlinePersistenceSource).toContain("currentOfflineScope() !== entry.scope");
  });

  it("rejects late query hydration after an AMO switch", () => {
    expect(queryPersisterSource).toContain("type ScopedPersistedClient");
    expect(queryPersisterSource).toContain("scope !== boundScope");
    expect(queryPersisterSource.match(/currentOfflineScope\(\) !== scope/g)?.length).toBeGreaterThanOrEqual(3);
  });

  it("isolates persisted queries for every same-tab and cross-tab AMO change", () => {
    expect(mainSource).toContain("clearTenantScopedRuntimeState");
    expect(mainSource).toContain("installActiveAmoStorageGuard");
    expect(mainSource).toContain("Storage.prototype.setItem");
    expect(mainSource).toContain("Storage.prototype.removeItem");
    expect(mainSource).toContain("ACTIVE_AMO_STORAGE_KEYS");
    expect(mainSource).toContain("BRANDING_EVENT");
  });

  it("never destroys encrypted unsynced work as a side effect of logout", () => {
    expect(mainSource).toContain('detail.type === "expired" || detail.type === "idle-logout"');
    expect(mainSource).toContain("clearAllPortalApiCaches()");
    expect(mainSource).toContain('detail.type === "manual-logout"');
    expect(mainSource).not.toContain("clearAllPortalOfflineData()");
    expect(mainSource).toContain("never silently destroy an encrypted unsynced");
  });

  it("provides retry and discard controls for conflicted offline changes", () => {
    expect(offlinePersistenceSource).toContain("export async function retryOfflineMutation");
    expect(offlinePersistenceSource).toContain("export async function discardOfflineMutation");
    expect(offlineIndicatorSource).toContain("retryOfflineMutation");
    expect(offlineIndicatorSource).toContain("discardOfflineMutation");
    expect(offlineIndicatorSource).toContain("Offline changes need review");
    expect(themeContractSource).toContain(".portal-offline-recovery");
  });

  it("treats an empty IndexedDB outbox as authoritative", () => {
    expect(offlinePersistenceSource).toContain("const storedIds = new Set");
    expect(offlinePersistenceSource).toContain("entry.scope === scope && !storedIds.has(id)");
    expect(offlinePersistenceSource).not.toContain("if (!stored.length && memoryOutbox.size)");
    expect(offlinePersistenceSource).toContain("if (!result.available)");
  });

  it("rebases concurrency tokens before explicit conflict retries", () => {
    expect(offlinePersistenceSource).toContain("export function currentConflictRevision");
    expect(offlinePersistenceSource).toContain("body.expected_state_revision = revision");
    expect(offlinePersistenceSource).toContain("body.last_known_updated_at = await currentTaskUpdatedAt(entry)");
    expect(offlinePersistenceSource).toContain("const body = await rebaseConflictBody(entry)");
  });

  it("serializes replay ownership with an IndexedDB lease and fenced outbox writes", () => {
    expect(offlinePersistenceSource).toContain('database.transaction(LEASE_STORE, "readwrite")');
    expect(offlinePersistenceSource).toContain("await acquireReplayLease(scope)");
    expect(offlinePersistenceSource).toContain("await renewReplayLease(leaseOwner, scope)");
    expect(offlinePersistenceSource).toContain("current.updatedAt !== expected.updatedAt");
    expect(offlinePersistenceSource).not.toContain("window.localStorage.setItem(REPLAY_LEASE_KEY");
  });

  it("repairs legacy light surfaces after module CSS is loaded", () => {
    expect(themeContractSource).toContain(".admin-user-create-page");
    expect(themeContractSource).toContain("--portal-control-bg");
    expect(themeRepairsSource).toContain(".tc-hero");
    expect(themeRepairsSource).toContain(".manuals-hero-card");
    expect(themeRepairsSource).toContain(".platform-shell");
  });
});
