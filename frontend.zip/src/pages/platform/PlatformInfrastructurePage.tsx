import React, { useState } from "react";

import { platformApi, type PlatformCommandJob } from "../../services/platformControl";
import { DataTable, EmptyState, ErrorState, MetricCard, PlatformShell, StatusBadge } from "./components/PlatformShared";
import { usePlatformData } from "./components/usePlatformData";

type InfrastructureSummary = {
  status?: string;
  workers?: number;
  latest_snapshot?: {
    cpu_percent?: number;
    memory_percent?: number;
    db_connections_active?: number;
    api_requests_per_minute?: number;
  } | null;
};

type FeatureFlag = {
  id: string;
  key: string;
  name: string;
  scope?: string;
  enabled: boolean;
};

type MaintenanceWindow = {
  id: string;
  status?: string;
  title?: string;
};

export default function PlatformInfrastructurePage() {
  const [key, setKey] = useState("new_feature_flag");
  const [reason, setReason] = useState("Critical infrastructure command requested by platform owner");
  const infra = usePlatformData(() => platformApi.infrastructureSummary(), []);
  const flags = usePlatformData(() => platformApi.featureFlags(), []);
  const windows = usePlatformData(() => platformApi.maintenanceWindows(), []);
  const commands = usePlatformData(() => platformApi.commands(), []);
  const summary = (infra.data ?? {}) as InfrastructureSummary;
  const snapshot = summary.latest_snapshot ?? {};
  const featureFlags = (flags.data?.items ?? []) as FeatureFlag[];
  const maintenanceWindows = (windows.data?.items ?? []) as MaintenanceWindow[];

  return (
    <PlatformShell
      title="System Infrastructure"
      subtitle="Feature flags, maintenance windows, worker heartbeat, storage/SMTP/API health and critical command jobs."
      actions={<button className="platform-btn primary" onClick={() => platformApi.runDiagnostics("Infrastructure probe").then(infra.reload)}>Run diagnostics</button>}
    >
      {infra.error ? <ErrorState error={infra.error} retry={infra.reload} /> : null}
      <section className="platform-grid">
        <MetricCard label="Status" value={<StatusBadge value={summary.status} />} />
        <MetricCard label="CPU" value={snapshot.cpu_percent ?? "N/A"} />
        <MetricCard label="RAM" value={snapshot.memory_percent ?? "N/A"} />
        <MetricCard label="DB connections" value={snapshot.db_connections_active ?? "N/A"} />
        <MetricCard label="API RPM" value={snapshot.api_requests_per_minute ?? "N/A"} />
        <MetricCard label="Workers" value={summary.workers ?? 0} />
      </section>
      <section className="platform-two">
        <div className="platform-card">
          <h2>Feature flags</h2>
          <div className="platform-form" style={{ gridTemplateColumns: "1fr auto", marginBottom: 12 }}><input value={key} onChange={(event) => setKey(event.target.value)} /><button className="platform-btn primary" onClick={() => platformApi.createFeatureFlag({ key, name: key, enabled: false, scope: "GLOBAL" }).then(flags.reload)}>Create flag</button></div>
          {featureFlags.length ? <DataTable><thead><tr><th>Flag</th><th>Scope</th><th>Status</th><th>Action</th></tr></thead><tbody>{featureFlags.map((flag) => <tr key={flag.id}><td>{flag.name}<br /><small>{flag.key}</small></td><td>{flag.scope ?? "GLOBAL"}</td><td><StatusBadge value={flag.enabled ? "ENABLED" : "DISABLED"} /></td><td><button className="platform-btn" onClick={() => platformApi.toggleFeatureFlag(flag.id, !flag.enabled).then(flags.reload)}>Toggle</button></td></tr>)}</tbody></DataTable> : <EmptyState label="No feature flags yet." />}
        </div>
        <div className="platform-card">
          <h2>Critical controls</h2>
          <textarea value={reason} onChange={(event) => setReason(event.target.value)} style={{ width: "100%", minHeight: 70 }} />
          <div className="platform-actions"><button className="platform-btn danger" onClick={() => platformApi.resetApiTokens(reason).then(commands.reload)}>Reset global API tokens</button><button className="platform-btn danger" onClick={() => platformApi.failoverDatabase(reason).then(commands.reload)}>Request DB failover</button></div>
          <h2>Maintenance windows</h2>
          {maintenanceWindows.length ? maintenanceWindows.map((window) => <p key={window.id}><StatusBadge value={window.status} /> {window.title ?? "Maintenance"}</p>) : <EmptyState label="No maintenance windows." />}
          <h2>Recent jobs</h2>
          {(commands.data?.items ?? []).slice(0, 5).map((job: PlatformCommandJob) => <p key={job.id}><StatusBadge value={job.status} /> {job.command_name}</p>)}
        </div>
      </section>
    </PlatformShell>
  );
}
